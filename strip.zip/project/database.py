# database.py - Compatibility wrapper (Cleaned & Blinded)
"""Compatibility wrapper for the legacy root-level `database` import.

Several modules in this project still do:
    import database as db

The real implementation lives at bot/routers/database.py, so we re-export it here
for backward compatibility.
"""

from bot.routers.database import *  # noqa: F401,F403

# Re-export the public API explicitly so imports like `import database as db` continue to work.
from bot.routers.database import (
    initialize_db,
    load_db,
    save_db,
    verify_user,
    get_rank_weight,
    get_user_rank,
    get_user_info,
    db_manager,
)

__all__ = [
    "initialize_db",
    "load_db",
    "save_db",
    "verify_user",
    "get_rank_weight",
    "get_user_rank",
    "get_user_info",
    "db_manager",
]