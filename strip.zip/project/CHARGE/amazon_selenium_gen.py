import asyncio
import os
import random
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from fake_useragent import UserAgent
from utils.logging_setup import get_logger
from CHARGE.amazon_db import save_cookie, load_cookie

logger = get_logger(__name__)

REGION_DOMAINS = {
    'US': 'amazon.com',  'MX': 'amazon.com.mx', 'ES': 'amazon.es',
    'CA': 'amazon.ca',   'CO': 'amazon.com.co',  'BR': 'amazon.com.br',
    'DE': 'amazon.de',   'FR': 'amazon.fr',       'GB': 'amazon.co.uk',
    'IT': 'amazon.it',
}

# Proxy Rotator Loader
def get_random_proxy():
    proxies = []
    proxy_file = os.path.join(os.path.dirname(__file__), "..", "proxies.txt")
    if os.path.exists(proxy_file):
        with open(proxy_file, "r") as f:
            proxies = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    if proxies:
        return random.choice(proxies)
    return None

async def generate_amazon_cookie_selenium(region: str):
    """
    Usa Selenium para obtener cookies reales de Amazon con fake_useragent y proxy.
    Implementación requerida por el protocolo Blackbox (Depuración Profunda).
    """
    domain = REGION_DOMAINS.get(region, 'amazon.com')
    url = f"https://www.{domain}/"
    
    ua = UserAgent()
    user_agent = ua.random
    proxy = get_random_proxy()
    
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument(f"user-agent={user_agent}")
    options.add_argument("--window-size=1920,1080")
    
    if proxy:
        # Simplificación de proxy asumiendo http://ip:port
        clean_proxy = proxy.replace("http://", "").replace("https://", "")
        options.add_argument(f"--proxy-server={clean_proxy}")
        
    # Selenium es sincrónico, lo ejecutamos en un thread pool
    loop = asyncio.get_running_loop()
    
    def _run_selenium():
        driver = None
        try:
            driver = webdriver.Chrome(options=options)
            driver.set_page_load_timeout(20)
            driver.get(url)
            # Extraer cookies
            cookies = driver.get_cookies()
            return cookies, user_agent, proxy
        except Exception as e:
            logger.error(f"Selenium Error en {region}: {e}")
            return None, user_agent, proxy
        finally:
            if driver:
                driver.quit()
                
    cookies, final_ua, final_proxy = await loop.run_in_executor(None, _run_selenium)
    
    if cookies:
        # Persistir en SQLite con cifrado
        save_cookie(region, cookies, final_ua, final_proxy or "None")
        return cookies, final_ua, final_proxy
    return None, final_ua, final_proxy

def cookies_to_netscape(cookies_list, domain):
    lines = ["# Netscape HTTP Cookie File", "# https://curl.haxx.se/docs/http-cookies.html", ""]
    for cookie in cookies_list:
        c_domain = cookie.get('domain', f".{domain}")
        c_flag = "TRUE" if c_domain.startswith(".") else "FALSE"
        c_path = cookie.get('path', "/")
        c_secure = "TRUE" if cookie.get('secure', False) else "FALSE"
        c_expiry = str(cookie.get('expiry', 2147483647))
        c_name = cookie.get('name', '')
        c_value = cookie.get('value', '')
        lines.append(f"{c_domain}\t{c_flag}\t{c_path}\t{c_secure}\t{c_expiry}\t{c_name}\t{c_value}")
    return "\n".join(lines)
