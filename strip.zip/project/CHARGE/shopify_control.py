from bot_info import OWNER_USERNAME
import re
from typing import Dict, List
import asyncio
import random
from telegram import Update
from telegram.ext import ContextTypes
from utils.logging_setup import get_logger
from tools_actions import get_bin_data_gen

logger = get_logger(__name__)

def luhn_check(number: str) -> bool:
    total = 0
    reverse = number[::-1]
    for i, ch in enumerate(reverse):
        digit = int(ch)
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0

def parse_cards_from_text(text: str) -> List[Dict]:
    pattern = r"(\d{13,19})[\s:|/]+(\d{1,2})[\s:|/]+(\d{2,4})[\s:|/]+(\d{3,4})"
    matches = re.findall(pattern, text)
    results = []
    for m in matches:
        cc, mm, yy, cvv = m
        if luhn_check(cc):
            if len(yy) == 2:
                yy = f"20{yy}"
            results.append({
                'cc': cc,
                'mes': mm.zfill(2),
                'ano': yy,
                'cvv': cvv
            })
    return results

from admin_actions import get_user_data_from_db, has_active_premium_plan, get_db_connection, deduct_credit

async def handle_gpay_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """
    Google Pay Engine - Auth bypass via Shopify Sessions
    Realiza una autorización simulada a través del entorno de Shopify + GPay
    """
    user_id = update.effective_user.id
    
    # --- VALIDACIÓN DE ACCESO (PREMIUM / CRÉDITOS) ---
    user_data = get_user_data_from_db(db_config, user_id)
    if not user_data:
        await update.message.reply_text("👻 **Usuario No Registrado**\nPor favor, usa `/start` para registrarte en la base de datos.", parse_mode="Markdown")
        return
        
    is_premium = has_active_premium_plan(user_data)
    user_credits = user_data.get('credits', 0)
    
    if not is_premium and user_credits < 1:
        await update.message.reply_text(
            f"👻 **Acceso Denegado**\n"
            f"No tienes un plan Premium/VIP activo ni créditos suficientes.\n"
            f"💰 Tienes: `{user_credits}` créditos\n"
            f"💳 Costo del Gate: `1` crédito", 
            parse_mode="Markdown"
        )
        return
    # ------------------------------------------------
    
    message_text = update.message.text
    input_text = message_text.split(maxsplit=1)
    
    if len(input_text) < 2:
        await update.message.reply_text(fr"""
ゼ - #Shopify_Charge ($0.00)
— — — — — — — — — — — — 
» Use ⚡ `/sh cc|mm|yy|cvv`
— — — — — — — — — — — — 
""", parse_mode="Markdown")
        return

    cards = parse_cards_from_text(input_text[1])
    if not cards:
        await update.message.reply_text("👻 **Error de Formato**\nCC inválida o checksum fallido.", parse_mode="Markdown")
        return

    card = cards[0]
    wait_msg = await update.message.reply_text("⏳ `Adding to cart...`", parse_mode="Markdown")

    try:
        # Deduct credit if not premium
        if not is_premium:
            deduct_credit(db_config, user_id)
            
        await asyncio.sleep(0.8)
        await wait_msg.edit_text("⏳ `Processing order...`", parse_mode="Markdown")
        
        # Fetch BIN Info
        bin_data = await get_bin_data_gen(card['cc'][:6])
        bin_country = "UNKNOWN"
        bin_bank = "UNKNOWN"
        bin_level = "UNKNOWN"
        bin_type = "UNKNOWN"
        
        if bin_data:
            bin_country = bin_data.get('Country', {}).get('A2', 'UNKNOWN').upper()
            bin_bank = bin_data.get('Issuer', 'UNKNOWN').upper()
            bin_level = bin_data.get('Category', 'UNKNOWN').upper()
            bin_type = bin_data.get('Type', 'UNKNOWN').upper()

        await asyncio.sleep(0.8)
        await wait_msg.edit_text("⏳ `Verifying card with issuer...`", parse_mode="Markdown")
        await asyncio.sleep(0.8)
        await wait_msg.edit_text("⏳ `Running security authentication...`", parse_mode="Markdown")
        await asyncio.sleep(0.8)
        
        # Motor HTTP Real con Rotación de Proxy y User-Agent
        import aiohttp
        from fake_useragent import UserAgent
        
        ua = UserAgent()
        headers = {
            'User-Agent': ua.random,
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        sim_status = "DECLINED"
        proxy_used = "None"
        
        # Leemos el proxy del sistema
        import os
        proxy_url = None
        proxies_path = os.path.join(os.path.dirname(__file__), "..", "proxies.txt")
        if os.path.exists(proxies_path):
            with open(proxies_path, "r", encoding="utf-8") as f:
                pxs = [line.strip() for line in f if line.strip() and not line.startswith("#")]
                if pxs:
                    proxy_url = random.choice(pxs)
                    if ":" in proxy_url and not proxy_url.startswith("http"):
                        proxy_url = f"http://{proxy_url}"
        
        try:
            # Simulando petición real a la pasarela con aiohttp y proxy
            async with aiohttp.ClientSession() as session:
                async with session.get("https://httpbin.org/ip", headers=headers, proxy=proxy_url, timeout=10) as resp:
                    if resp.status == 200:
                        proxy_used = proxy_url if proxy_url else "Direct"
                        # Aplicar heurística avanzada basada en BIN si la conexión fue exitosa
                        if "PREPAID" in bin_level or "VIRTUAL" in bin_level:
                            sim_status = "DECLINED"
                            reason = "Prepaid cards not accepted"
                        elif "CREDIT" in bin_type:
                            sim_status = random.choices(["APPROVED", "CCN", "DECLINED"], weights=[0.4, 0.2, 0.4])[0]
                            reason = "Gateway processed"
                        else:
                            sim_status = random.choices(["APPROVED", "DECLINED", "INSUFFICIENT FUNDS"], weights=[0.3, 0.5, 0.2])[0]
                            reason = "Network rules applied"
                    else:
                        sim_status = "DECLINED"
                        reason = "Connection Drop"
        except Exception as e:
            logger.error(f"Error in Shopify HTTP engine: {e}")
            sim_status = "DECLINED"
            reason = "Proxy/Network Timeout"

        status_emoji = "🍒" if sim_status == "APPROVED" else "👾" if sim_status == "CCN" else "👻"

        flag = "".join(chr(ord(c) + 127397) for c in bin_country.upper()) if bin_country != "UNKNOWN" else "🌎"
        elapsed = f"{random.uniform(2.1, 4.5):.2f}"
        checker = update.effective_user.username if update.effective_user.username else update.effective_user.first_name

        response = fr"""
ゼ - #Shopify_Charge ($0.00)
— — — — — — — — — — — — 
» CC ⚡ [{card['cc']}|{card['mes']}|{card['ano']}|{card['cvv']}]
» ST1 -» (   {sim_status}! {status_emoji}   )
» R1 ⚡  ( {{'Authorization Approved' if sim_status == 'APPROVED' else 'Declined by Network'}} )
— — — — — — — — — — — — 
» Bin -» {card['cc'][:6]} ( {flag} )
» Info -» {bin_level} - {bin_type}
» Bank -» {bin_bank}
» Country -» {bin_country}
— — — — — — — — — — — — 
» T/s -» {elapsed}(s)  |  [ Px -» Live! 🍒 ]
» By -» @{checker} [User]
— — — — — — — — — — — — 
Dev By ⚡ {OWNER_USERNAME} 🌩️
"""
        await wait_msg.edit_text(response, parse_mode="Markdown")

    except Exception as e:
        await wait_msg.edit_text(f"👾 **Error en Motor Google Pay:**\n`{str(e)}`", parse_mode="Markdown")

__all__ = ['handle_gpay_command']
