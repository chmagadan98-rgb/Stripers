# amazon_db.py - Encrypted SQLite storage for Amazon sessions (Cleaned & Blinded)
import sqlite3
import os
import json
from cryptography.fernet import Fernet
from utils.logging_setup import get_logger

logger = get_logger(__name__)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "amazon_sessions.db")
KEY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".amazon_db_key")

def _get_or_create_key():
    if not os.path.exists(KEY_PATH):
        key = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(key)
        return key
    with open(KEY_PATH, "rb") as f:
        return f.read()

cipher = Fernet(_get_or_create_key())

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA cache_size=-2000;")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS amazon_cookies (
            region TEXT PRIMARY KEY,
            cookie_data TEXT,
            user_agent TEXT,
            proxy_used TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def save_cookie(region: str, cookie_list: list, user_agent: str, proxy: str):
    try:
        raw_data = json.dumps(cookie_list).encode('utf-8')
        encrypted_data = cipher.encrypt(raw_data).decode('utf-8')
        
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO amazon_cookies (region, cookie_data, user_agent, proxy_used, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(region) DO UPDATE SET 
                cookie_data=excluded.cookie_data,
                user_agent=excluded.user_agent,
                proxy_used=excluded.proxy_used,
                updated_at=CURRENT_TIMESTAMP
        ''', (region, encrypted_data, user_agent, proxy))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error saving cookie to DB: {e}")
        return False

def load_cookie(region: str):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL;")
        cursor = conn.cursor()
        cursor.execute("SELECT cookie_data, user_agent FROM amazon_cookies WHERE region=?", (region,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            encrypted_data, user_agent = row
            decrypted_data = cipher.decrypt(encrypted_data.encode('utf-8')).decode('utf-8')
            cookie_list = json.loads(decrypted_data)
            return cookie_list, user_agent
        return None, None
    except Exception as e:
        logger.error(f"Error loading cookie from DB: {e}")
        return None, None

init_db()