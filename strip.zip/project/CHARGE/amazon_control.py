"""
AMAZON GATE HANDLER
Integración completa de Amazon: /amz (checker) y /gencookie (generador de sesión)
"""
import os
import re
import asyncio
import random
import string
import aiohttp
from datetime import datetime
from typing import Dict, List

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from admin_actions import get_user_data_from_db, has_active_premium_plan, deduct_credit
from bot_info import OWNER_USERNAME, LINK_ONYKAFREE, BOT_NAME
from utils.logging_setup import get_logger

from CHARGE.amazon_selenium_gen import generate_amazon_cookie_selenium, cookies_to_netscape
from CHARGE.amazon_db import load_cookie

logger = get_logger(__name__)

# ─── VALID REGIONS ────────────────────────────────────────────────────────────
REGIONS = ['US', 'MX', 'ES', 'CA', 'CO', 'BR', 'DE', 'FR', 'GB', 'IT']

REGION_DOMAINS = {
    'US': 'amazon.com',  'MX': 'amazon.com.mx', 'ES': 'amazon.es',
    'CA': 'amazon.ca',   'CO': 'amazon.com.co',  'BR': 'amazon.com.br',
    'DE': 'amazon.de',   'FR': 'amazon.fr',         'GB': 'amazon.co.uk',
    'IT': 'amazon.it',
}

# ─── HELPERS ──────────────────────────────────────────────────────────────────
from utils.bin_api import get_bin_info

async def get_bin_data(bin_number: str) -> dict:
    return await get_bin_info(bin_number) or {}

def get_flag(code: str) -> str:
    try:
        return ''.join(chr(ord(c) + 127397) for c in code.upper())
    except Exception:
        return ''

def luhn_check(number: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(number)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0

def parse_card(text: str):
    """Extract first cc|mm|yy|cvv from text."""
    pattern = r'(\d{13,19})[\s:|/]+(\d{1,2})[\s:|/]+(\d{2,4})[\s:|/]+(\d{3,4})'
    m = re.search(pattern, text)
    if m:
        cc, mm, yy, cvv = m.groups()
        if luhn_check(cc):
            yy = f"20{yy}" if len(yy) == 2 else yy
            return cc, mm.zfill(2), yy, cvv
    return None

import time
import base64
import secrets

def fake_session_id() -> str:
    part1 = random.randint(100, 999)
    part2 = random.randint(1000000, 9999999)
    part3 = random.randint(1000000, 9999999)
    return f"{part1}-{part2}-{part3}"

def generate_at_main() -> str:
    timestamp = int(time.time())
    random_data = secrets.token_bytes(256)
    payload = timestamp.to_bytes(8, 'big') + random_data
    encrypted = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip('=')
    return f"enc_gAAAAAB{encrypted}"

def generate_ubid_main() -> str:
    timestamp = int(time.time())
    random_data = secrets.token_bytes(64)
    payload = timestamp.to_bytes(8, 'big') + random_data
    encrypted = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip('=')
    return f"enc_gAAAAAB{encrypted}"

def generate_x_main() -> str:
    parts = [secrets.token_hex(16), secrets.token_hex(24), secrets.token_hex(32)]
    return f'"{parts[0]}{parts[1]}?{parts[2]}"'

def generate_csm_hit() -> str:
    random_id = secrets.token_hex(12).upper()
    timestamp1 = int(time.time() * 1000)
    timestamp2 = timestamp1 + random.randint(100, 500)
    return f"tb:s-{random_id}|{timestamp1}&t:{timestamp2}&adb:adblk_no"

def generate_cookie_string(region: str) -> str:
    """Generate a highly realistic Amazon-style session cookie string with regional location integration."""
    sid = fake_session_id()
    domain = REGION_DOMAINS.get(region, 'amazon.com')
    expiry = str(int(time.time()) + (86400 * 30))
    domain_lc = domain.replace('.', '-')
    
    regional_locations = {
        'US': {'zip': '10001', 'address': 'New York, NY', 'country_code': 'US'},
        'MX': {'zip': '01000', 'address': 'Ciudad de Mexico, CDMX', 'country_code': 'MX'},
        'ES': {'zip': '28001', 'address': 'Madrid, Madrid', 'country_code': 'ES'},
        'CA': {'zip': 'M5V2T6', 'address': 'Toronto, ON', 'country_code': 'CA'},
        'CO': {'zip': '110111', 'address': 'Bogota, D.C.', 'country_code': 'CO'},
        'BR': {'zip': '01001-000', 'address': 'Sao Paulo, SP', 'country_code': 'BR'},
        'DE': {'zip': '10115', 'address': 'Berlin', 'country_code': 'DE'},
        'FR': {'zip': '75001', 'address': 'Paris', 'country_code': 'FR'},
        'GB': {'zip': 'SW1A1AA', 'address': 'London', 'country_code': 'GB'},
        'IT': {'zip': '00124', 'address': 'Roma', 'country_code': 'IT'}
    }
    
    loc = regional_locations.get(region, {'zip': '10001', 'address': 'New York', 'country_code': 'US'})
    
    cookies_data = {
        'session-id': sid,
        'session-id-time': expiry + 'l',
        'i18n-prefs': 'USD' if region == 'US' else region,
        f'lc-{domain_lc}': f'en_{region}',
        f'ubid-{domain_lc}': generate_ubid_main(),
        'x-main': generate_x_main(),
        'at-main': generate_at_main(),
        'sess-at-main': generate_at_main(),
        'sst-main': generate_at_main(),
        'csm-hit': generate_csm_hit(),
        'session-address-selected': f"zip={loc['zip']}&country={loc['country_code']}",
        'sp-cdn': f"LXT={loc['country_code']}:{loc['zip']}:delivery-zip",
        'session-address-zip': loc['zip']
    }
    
    lines = ["# Netscape HTTP Cookie File", "# https://curl.haxx.se/docs/http-cookies.html", ""]
    for name, value in cookies_data.items():
        secure = "TRUE" if name in ['at-main', 'sess-at-main', 'sst-main', 'x-main'] else "FALSE"
        lines.append(f".{domain}\tTRUE\t/\t{secure}\t{expiry}\t{name}\t{value}")
        
    return "\n".join(lines)

def decide_result(bin_data: dict, region: str):
    """Simulate Amazon card verification logic based on BIN data."""
    scheme    = bin_data.get('Scheme', '').upper()
    card_type = bin_data.get('Type', '').upper()
    category  = bin_data.get('Category', '').upper()
    country   = bin_data.get('Country', {}).get('A2', 'XX').upper()

    if any(k in category for k in ['PREPAID', 'VIRTUAL', 'GIFT']):
        return 'DECLINED', 'Payment method not accepted'

    if country not in [region, 'US'] and region not in ['US', 'CO', 'BR']:
        if random.random() < 0.4:
            return 'DECLINED', f'AVS Mismatch — Card country ({country}) vs Region ({region})'

    if scheme in ['VISA', 'MASTERCARD', 'AMERICAN EXPRESS']:
        roll = random.random()
        if roll < 0.75:
            return 'APPROVED', 'Payment method added successfully'
        elif roll < 0.88:
            return 'CCN', 'Insufficient funds'
        else:
            return 'DECLINED', 'Your card was declined'

    if random.random() < 0.5:
        return 'APPROVED', 'Payment method added successfully'
    return 'DECLINED', 'Unable to process card'


# ─── /gencookie ───────────────────────────────────────────────────────────────

async def handle_gencookie_command_amazon(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Comando /gencookie [region] — genera sesión Amazon."""
    user_id = update.effective_user.id

    user_data = get_user_data_from_db(db_config, user_id)
    if not user_data:
        await update.message.reply_text("👻 Usa `/start` para registrarte.", parse_mode=ParseMode.MARKDOWN)
        return

    is_premium = has_active_premium_plan(user_data)
    user_credits = user_data.get('credits', 0)
    if not is_premium and user_credits < 1:
        await update.message.reply_text(
            fr"\[[👾]({LINK_ONYKAFREE})\] *Acceso Denegado* — Sin créditos disponibles\.",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    args   = context.args or []
    region = args[0].upper() if args else 'US'
    if region not in REGIONS:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(r, callback_data=f"amz_gen_{r}") for r in REGIONS[:5]
        ], [
            InlineKeyboardButton(r, callback_data=f"amz_gen_{r}") for r in REGIONS[5:]
        ]])
        await update.message.reply_text(
            f"👾 Región `{region}` inválida. Selecciona una:",
            reply_markup=kb, parse_mode=ParseMode.MARKDOWN
        )
        return

    wait_msg = await update.message.reply_text(
        "⏳ `Initializing secure session...`", parse_mode=ParseMode.MARKDOWN
    )
    await asyncio.sleep(0.9)
    await wait_msg.edit_text("⏳ `Authenticating with regional server...`", parse_mode=ParseMode.MARKDOWN)
    await asyncio.sleep(0.9)
    await wait_msg.edit_text("⏳ `Generating session tokens...`", parse_mode=ParseMode.MARKDOWN)
    await asyncio.sleep(0.9)

    try:
        if not is_premium:
            deduct_credit(db_config, user_id)

        cookies_list, used_ua, used_proxy = await generate_amazon_cookie_selenium(region)
        domain = REGION_DOMAINS.get(region, 'amazon.com')
        
        if cookies_list:
            cookie_str = cookies_to_netscape(cookies_list, domain)
            gen_method = "Selenium (Real Browser) + SQLite"
        else:
            cookie_str = generate_cookie_string(region)
            gen_method = "Fake Generator (Fallback)"
            used_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            used_proxy = "None"

        checker = update.effective_user.username or update.effective_user.first_name

        context.user_data[f'amz_cookie_{region}'] = {
            'cookie_string': cookie_str,
            'checks_count':  0,
            'region':        region,
            'timestamp':     datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🔄 Regenerar", callback_data=f"amz_gen_{region}"),
            InlineKeyboardButton("📊 Ver Netscape", callback_data=f"amz_copy_{region}"),
        ]])

        import html
        
        cookie_lines = [line.split('\t') for line in cookie_str.split('\n') if '\t' in line]
        inline_cookie = "; ".join([f"{parts[5]}={parts[6]}" for parts in cookie_lines if len(parts) > 6])
        if len(inline_cookie) > 64:
            inline_cookie = inline_cookie[:64] + "..."
            
        flag_map = {'US': '🇺🇸', 'MX': '🇲🇽', 'ES': '🇪🇸', 'CA': '🇨🇦', 'CO': '🇨🇴'}
        flag = flag_map.get(region, '🌎')
        timestamp_now = context.user_data[f'amz_cookie_{region}']['timestamp']

        response = (
            f"<b>[👾] {html.escape(BOT_NAME)} | Amazon GenCookie</b>\n"
            f"━━━━━━━━━━━━\n"
            f"🍪 <b>Cookie generada exitosamente!</b>\n\n"
            f"<b>Tipo:</b> Amazon {flag}\n"
            f"<b>Método:</b> {gen_method}\n"
            f"<b>Proxy:</b> <code>{html.escape(str(used_proxy))}</code>\n"
            f"<b>User-Agent:</b> <code>{html.escape(used_ua)}</code>\n\n"
            f"<b>Cookie Preview:</b>\n"
            f"<code>{html.escape(inline_cookie)}</code>\n\n"
            f"✅ <b>Procesado a las:</b> {timestamp_now}\n"
            f"━━━━━━━━━━━━\n"
            f"<b>Generated by:</b> @{html.escape(checker)}"
        )
        
        await wait_msg.edit_text(response, reply_markup=kb, parse_mode=ParseMode.HTML)

    except Exception as e:
        logger.error(f"GenCookie error: {e}")
        await wait_msg.edit_text(f"👻 Error generando sesión: <code>{html.escape(str(e))}</code>", parse_mode=ParseMode.HTML)


# ─── /amz ─────────────────────────────────────────────────────────────────────

async def handle_amz_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Comando /amz cc|mm|yy|cvv [region] — verifica tarjeta vía Amazon."""
    user_id  = update.effective_user.id
    msg_text = update.message.text.strip()

    user_data = get_user_data_from_db(db_config, user_id)
    if not user_data:
        await update.message.reply_text("👻 Usa `/start` para registrarte.", parse_mode=ParseMode.MARKDOWN)
        return

    is_premium   = has_active_premium_plan(user_data)
    user_credits = user_data.get('credits', 0)
    if not is_premium and user_credits < 1:
        await update.message.reply_text(
            fr"\[[👾]({LINK_ONYKAFREE})\] *Acceso Denegado* — Sin créditos disponibles\.",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    region = 'US'
    for r in REGIONS:
        if re.search(rf'\b{r}\b', msg_text, re.IGNORECASE):
            region = r
            break

    parsed = parse_card(msg_text)
    if not parsed:
        await update.message.reply_text(
            fr"""
ゼ - #Amazon_Gate ($0.00)
— — — — — — — — — — — — 
» Use ⚡ `/amz cc|mm|yy|cvv [region]`
» Regions ⚡ `US MX ES CA CO BR DE FR GB IT`
— — — — — — — — — — — — 
""", parse_mode=ParseMode.MARKDOWN)
        return

    cc, mm, yy, cvv = parsed
    bin_number = cc[:6]
    domain     = REGION_DOMAINS.get(region, 'amazon.com')

    wait_msg = await update.message.reply_text(
        "⏳ `Connecting to regional server...`", parse_mode=ParseMode.MARKDOWN
    )
    await asyncio.sleep(0.9)

    cookie_data = context.user_data.get(f'amz_cookie_{region}')
    if not cookie_data or cookie_data.get('checks_count', 0) >= 5:
        cookie_str = generate_cookie_string(region)
        context.user_data[f'amz_cookie_{region}'] = {
            'cookie_string': cookie_str, 'checks_count': 0, 'region': region,
            'timestamp': datetime.now().isoformat()
        }
    cookie_data = context.user_data[f'amz_cookie_{region}']

    await wait_msg.edit_text("⏳ `Validating session credentials...`", parse_mode=ParseMode.MARKDOWN)

    bin_task = asyncio.create_task(get_bin_data(bin_number))
    await asyncio.sleep(0.9)

    await wait_msg.edit_text("⏳ `Submitting payment details...`", parse_mode=ParseMode.MARKDOWN)
    await asyncio.sleep(0.9)

    await wait_msg.edit_text("⏳ `Running issuer verification...`", parse_mode=ParseMode.MARKDOWN)
    await asyncio.sleep(0.8)

    bin_data = await bin_task

    scheme     = bin_data.get('Scheme', 'UNKNOWN').upper()
    card_type  = bin_data.get('Type', 'UNKNOWN').upper()
    issuer     = bin_data.get('Issuer', 'UNKNOWN').upper()
    category   = bin_data.get('Category', 'UNKNOWN').upper()
    country    = bin_data.get('Country', {})
    country_a2 = country.get('A2', 'XX')
    country_nm = country.get('Name', 'Unknown').upper()
    flag       = get_flag(country_a2)

    status = 'DECLINED'
    response_msg = 'Unable to process card'
    
    import sys
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parent_dir = os.path.dirname(base_dir)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
        
    checker = None
    try:
        from amazon_cookie_checker import CookieManagerChecker
        cookies_path = os.path.join(parent_dir, "cookies_generadas.txt")
        if not os.path.exists(cookies_path):
            cookies_path = "cookies_generadas.txt"
        manager = CookieManagerChecker(cookies_path)
        checker = manager.get_checker(region)
    except Exception as e:
        logger.error(f"Failed to init real Amazon checker: {e}")

    if checker:
        card_data = {'cc': cc, 'month': mm, 'year': yy, 'cvv': cvv}
        try:
            res = await checker.check_card(card_data)
            status = res.get('status', 'DECLINED').upper()
            response_msg = res.get('message', 'DECLINED').strip()
            if status == 'INSUFFICIENT': status = 'CCN'
        except Exception as e:
            status = 'DECLINED'
            response_msg = f'Checker error: {str(e)}'
    else:
        status, response_msg = decide_result(bin_data, region)

    emoji = {'APPROVED': '🍒', 'CCN': '👾', 'DECLINED': '👻'}.get(status, '👻')

    cookie_data['checks_count'] = cookie_data.get('checks_count', 0) + 1
    context.user_data[f'amz_cookie_{region}'] = cookie_data

    if not is_premium:
        deduct_credit(db_config, user_id, 1)

    checker = update.effective_user.username or update.effective_user.first_name

    result_text = fr"""
ゼ - #Amazon_Gate_({region}) ($0.00)
— — — — — — — — — — — — 
» CC ⚡ [{cc}|{mm}|{yy}|{cvv}]
» ST1 -» (    {status}! {emoji}    )
» R1 ⚡  ( {response_msg} )
— — — — — — — — — — — — 
» Bin -» {bin_number} ( {flag} )
» Info -» {card_type} - {category}
» Bank -» {issuer}
» Country -» {country_nm} - {region}
— — — — — — — — — — — — 
» T/s -» 5.00(s)  |  [ Px -» Live! 🍒 ]
» By -» @{checker} [User]
— — — — — — — — — — — — 
Dev By ⚡ {OWNER_USERNAME} 🌩️
"""
    await wait_msg.edit_text(result_text, parse_mode=ParseMode.MARKDOWN)
    logger.info(f"[AMAZON] User={user_id} Status={status} BIN={bin_number} Region={region}")


# ─── CALLBACK HANDLER ─────────────────────────────────────────────────────────

async def amazon_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles inline button callbacks from Amazon commands."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data.startswith('amz_gen_'):
        region = data.replace('amz_gen_', '')
        cookie_str = generate_cookie_string(region)
        domain = REGION_DOMAINS.get(region, 'amazon.com')
        
        if f'amz_cookie_{region}' in context.user_data:
            del context.user_data[f'amz_cookie_{region}']
            
        cookies_list, used_ua, used_proxy = await generate_amazon_cookie_selenium(region)
        if cookies_list:
            cookie_str = cookies_to_netscape(cookies_list, domain)
            gen_method = "Selenium + SQLite"
        else:
            cookie_str = generate_cookie_string(region)
            gen_method = "Fake Generator (Fallback)"
            used_ua = "Mozilla/5.0"
            used_proxy = "None"
            
        context.user_data[f'amz_cookie_{region}'] = {
            'cookie_string': cookie_str,
            'checks_count': 0,
            'region': region,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🔄 Regenerar", callback_data=f"amz_gen_{region}"),
            InlineKeyboardButton("📊 Ver Netscape", callback_data=f"amz_copy_{region}"),
        ], [
            InlineKeyboardButton("💾 Guardar en DB", callback_data=f"amz_save_{region}")
        ]])
        
        checker = query.from_user.username or query.from_user.first_name
        import html
        
        cookie_lines = [line.split('\t') for line in cookie_str.split('\n') if '\t' in line]
        inline_cookie = "; ".join([f"{parts[5]}={parts[6]}" for parts in cookie_lines if len(parts) > 6])
        if len(inline_cookie) > 64:
            inline_cookie = inline_cookie[:64] + "..."
        
        flag_map = {'US': '🇺🇸', 'MX': '🇲🇽', 'ES': '🇪🇸', 'CA': '🇨🇦', 'CO': '🇨🇴'}
        flag = flag_map.get(region, '🌎')
        timestamp_now = context.user_data[f'amz_cookie_{region}']['timestamp']

        response = (
            f"<b>[👾] {html.escape(BOT_NAME)} | Amazon GenCookie</b>\n"
            f"━━━━━━━━━━━━\n"
            f"🍪 <b>Cookie generada exitosamente!</b>\n\n"
            f"<b>Tipo:</b> Amazon {flag}\n"
            f"<b>Método:</b> {gen_method}\n"
            f"<b>Proxy:</b> <code>{html.escape(str(used_proxy))}</code>\n\n"
            f"<b>Cookie Preview:</b>\n"
            f"<code>{html.escape(inline_cookie)}</code>\n\n"
            f"✅ <b>Procesado a las:</b> {timestamp_now}\n"
            f"━━━━━━━━━━━━\n"
            f"<b>Generated by:</b> @{html.escape(checker)}"
        )
        await query.edit_message_text(response, reply_markup=kb, parse_mode=ParseMode.HTML)

    elif data.startswith('amz_copy_'):
        region = data.replace('amz_copy_', '')
        cookie_data = context.user_data.get(f'amz_cookie_{region}')
        if cookie_data:
            import html
            raw_cookie = html.escape(cookie_data['cookie_string'])
            
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Volver", callback_data=f"amz_gen_{region}")
            ]])
            
            text_html = (
                f"<b>[👾] Session Cookie Preview (Netscape)</b>\n"
                f"━━━━━━━━━━━━\n"
                f"<pre>{raw_cookie}</pre>\n"
                f"━━━━━━━━━━━━\n"
                f"<b>[👾] Uses:</b> {cookie_data.get('checks_count', 0)}/5"
            )
            await query.edit_message_text(text_html, reply_markup=kb, parse_mode=ParseMode.HTML)
        else:
            await query.edit_message_text("👻 No hay sesión guardada. Usa `/gencookie`.", parse_mode=ParseMode.MARKDOWN)

    elif data.startswith('amz_save_'):
        region = data.replace('amz_save_', '')
        cookie_data = context.user_data.get(f'amz_cookie_{region}')
        if cookie_data:
            import os
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            cookies_path = os.path.join(os.path.dirname(base_dir), "cookies_generadas.txt")
            if not os.path.exists(cookies_path):
                cookies_path = "cookies_generadas.txt"
                
            try:
                with open(cookies_path, 'a', encoding='utf-8') as f:
                    f.write("\n" + "="*60 + "\n")
                    f.write(f"🍪 Amazon {region}\n")
                    f.write(f"📅 {cookie_data['timestamp']}\n")
                    f.write(f"👤 Auto-Generated via Bot\n")
                    f.write("-" * 60 + "\n")
                    f.write(cookie_data['cookie_string'])
                    f.write("\n" + "="*60 + "\n")
                    
                await query.answer("💾 Cookie guardada para el checker y Amazon mass!", show_alert=True)
            except Exception as e:
                logger.error(f"Error saving cookie: {e}")
                await query.answer("❌ Error al guardar cookie", show_alert=True)
        else:
            await query.answer("❌ No hay cookie en memoria para guardar", show_alert=True)

    elif data == 'amz_help':
        await query.edit_message_text(
            fr"""
ゼ - #Amazon_Gate_Ayuda ($0.00)
— — — — — — — — — — — — 
» Check ⚡ `/amz cc|mm|yy|cvv [region]`
» Session ⚡ `/gencookie [region]`
» Regions ⚡ `US MX ES CA CO BR DE FR GB IT`
— — — — — — — — — — — — 
""",
            parse_mode=ParseMode.MARKDOWN
        )

handle_amzchk_command = handle_amz_command

__all__ = [
    'handle_gencookie_command_amazon',
    'handle_amz_command',
    'handle_amzchk_command',
    'amazon_callback_handler'
]