from utils.bin_api import get_bin_info as fetch_bin_info
# paypal_charge_control.py - VERSIÓN EXCLUSIVA PARA USUARIOS PREMIUM
import re
from CHARGE.charge_gateways import require_individual_premium_access, validate_cc_format, get_user_data_from_db, check_antispam, update_user_last_check
from CHARGE.paypalcharge import Niggas  # Importar el checker de PayPal
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
import asyncio
from telegram import Update, ReplyParameters
from telegram.ext import ContextTypes
import time
import aiohttp
import concurrent.futures
from utils.logging_setup import get_logger
logger = get_logger(__name__)

# 🔥 SEMÁFORO GLOBAL para control de concurrencia por usuario (separado de br y py)
paypal_charge_semaphores = {}

# 🔥 THREAD POOL para ejecutar código síncrono sin bloquear
paypal_charge_thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=10)

def escape_markdown_v2(text):
    """Escapa caracteres especiales para el formato MarkdownV2 de Telegram."""
    if text is None:
        return 'N/A'
    import re
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

def escape_inside_backticks(text):
    if text is None:
        return 'N/A'
    return str(text).replace('\\', '\\\\').replace('`', '\\`')

async def get_bin_info(bin_number: str) -> dict:
    return await fetch_bin_info(bin_number)

def get_user_plan_display(db_config, user_id):
    """Obtiene el plan del usuario para mostrar"""
    user_data = get_user_data_from_db(db_config, user_id)
    if not user_data:
        return 'FREE'
    plan = user_data.get('plan', 'FREE').upper()
    role = user_data.get('role', 'user').upper()
    if role in ['OWNER', 'CO OWNER', 'DEV', 'SELLER']:
        return f'{role}'
    return plan

def get_country_emoji(country_code: str) -> str:
    """Convierte un código de país A2 a emoji de bandera."""
    if not country_code or country_code == 'N/A':
        return '🏳️'
    offset = 127397
    try:
        return ''.join(chr(ord(char) + offset) for char in country_code.upper())
    except Exception:
        return '🏳️'

def format_bin_info_for_pc(bin_number: str, bin_data: dict) -> tuple:
    """Formatea la información del BIN para el comando /pc."""
    if not bin_data:
        info = f"\[[👾]({LINK_ONYKAFREE})\] *Info:* Unknown \- Unknown"
        bank = f"\[[👾]({LINK_ONYKAFREE})\] *Bank:* `Unknown`"
        country = f"\[[👾]({LINK_ONYKAFREE})\] *Country:* `Unknown`"
        return info, bank, country
    scheme = escape_inside_backticks(bin_data.get('Scheme', 'Unknown'))
    card_type = escape_inside_backticks(bin_data.get('Type', 'Unknown').upper())
    issuer = escape_inside_backticks(bin_data.get('Issuer', 'Unknown'))
    country_data = bin_data.get('Country', {})
    country_name = escape_inside_backticks(country_data.get('Name', 'Unknown'))
    country_code = country_data.get('A2', 'Unknown')
    country_emoji = get_country_emoji(country_code)
    info = f"\[[👾]({LINK_ONYKAFREE})\] *Info:* `{scheme}` \- `{card_type}`"
    bank = f"\[[👾]({LINK_ONYKAFREE})\] *Bank:* `{issuer}`"
    country = f"\[[👾]({LINK_ONYKAFREE})\] *Country:* `{country_name}` {country_emoji}"
    return info, bank, country

def get_thread_id(update: Update):
    """Obtiene el thread_id solo si el chat es un foro"""
    if update.effective_chat.is_forum and getattr(update.effective_message, 'message_thread_id', None):
        return update.effective_message.message_thread_id
    return None

async def send_message_safe(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, parse_mode: ParseMode = None):
    """Envía un mensaje de forma segura manejando thread_id y responde al mensaje original"""
    thread_id = get_thread_id(update)
    try:
        if thread_id is not None:
            try:
                return await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text=text,
                    parse_mode=parse_mode,
                    message_thread_id=thread_id,
                    reply_parameters=ReplyParameters(message_id=update.message.message_id)
                )
            except Exception as thread_error:
                logger.error(f"Error sending to thread {thread_id}: {thread_error}")
                return await update.message.reply_text(text, parse_mode=parse_mode, reply_to_message_id=update.message.message_id)
        else:
            return await update.message.reply_text(text, parse_mode=parse_mode, reply_to_message_id=update.message.message_id)
    except Exception as e:
        logger.error(f"Error in send_message_safe: {e}")
        return await update.message.reply_text(text, parse_mode=parse_mode, reply_to_message_id=update.message.message_id)

async def edit_message_safe(message, text: str, parse_mode: ParseMode = None):
    """Edita un mensaje de forma segura"""
    try:
        await message.edit_text(text, parse_mode=parse_mode)
    except Exception as e:
        logger.error(f"Error editing message: {e}")
        try:
            if hasattr(message, 'chat') and hasattr(message, 'bot'):
                await message.bot.send_message(chat_id=message.chat.id, text=text, parse_mode=parse_mode)
        except Exception as send_error:
            logger.error(f"Error sending new message after edit failed: {send_error}")

def extract_cc_from_text(text: str) -> str:
    """Extrae datos de tarjeta de crédito del texto."""
    if not text:
        return None
    patterns = [
        r'\b\d{13,19}\s*[\|:/]\s*\d{1,2}\s*[\|:/]\s*\d{2,4}\s*[\|:/]\s*\d{3,4}\b',
        r'\b\d{13,19}\s*[\|:/]\s*\d{1,2}\s*[\|:/]\s*\d{2,4}\s*[\|:/]\s*\d{3,4}\b',
        r'\b\d{13,19}\b'
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text)
        if matches:
            cc_data = matches[0].strip()
            cc_data = re.sub(r'[\s:/]+', '|', cc_data)
            return cc_data
    return None

def run_paypal_charge_sync(cc_formatted: str):
    """Ejecuta el checker de Paypal $2 [/pc] en un thread separado"""
    try:
        checker = Niggas()
        result = checker.main(cc_formatted)
        return result
    except Exception as e:
        return 'Declined! 👻', f'Error: {str(e)}'

async def process_paypal_charge(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict, cc_data: str, processing_msg, user_id):
    try:
        is_valid, message, cc_parts = validate_cc_format(cc_data)
        if not is_valid:
            response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Use:* `/pc cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
            await edit_message_safe(processing_msg, response, ParseMode.MARKDOWN_V2)
            return
        user_data = get_user_data_from_db(db_config, user_id)
        username = user_data.get('username', 'N/A') if user_data else 'N/A'
        user_plan = get_user_plan_display(db_config, user_id)
        start_time = time.time()
        cc_formatted = f"{cc_parts[0]}|{cc_parts[1]}|{cc_parts[2]}|{cc_parts[3]}"
        cc_formatted_display = f"{cc_parts[0]}|{cc_parts[1]}|{cc_parts[2][-2:]}|{cc_parts[3]}"
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(paypal_charge_thread_pool, run_paypal_charge_sync, cc_formatted)
        bin_number = cc_parts[0][:6]
        bin_data = await get_bin_info(bin_number)
        update_user_last_check(db_config, user_id)
        processing_time = round(time.time() - start_time, 2)
        if isinstance(result, tuple) and len(result) >= 2:
            status, repose = result[0], result[1]
            extra_info = result[2] if len(result) > 2 else ""
        else:
            status, repose, extra_info = "Error", "Respuesta inesperada", ""
        info_line, bank_line, country_line = format_bin_info_for_pc(bin_number, bin_data)
        status_escaped = escape_inside_backticks(status)
        repose_escaped = escape_inside_backticks(repose)
        extra_info_escaped = escape_inside_backticks(extra_info)
        username_escaped = escape_markdown_v2(username)
        user_plan = escape_markdown_v2(user_plan)
        response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Card:* `{cc_formatted_display}`
\[[👾]({LINK_ONYKAFREE})\] *Status:* `{status_escaped}`
\[[👾]({LINK_ONYKAFREE})\] *Response:* `{repose_escaped}`
"""
        response += f"""
━━━━━━━━━━━━
{info_line}
{bank_line}
{country_line}
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Checked by:* @{username_escaped} » {user_plan}
\[[👾]({LINK_ONYKAFREE})\] *Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
        await edit_message_safe(processing_msg, response, ParseMode.MARKDOWN_V2)
    except Exception as e:
        end_time = time.time()
        processing_time = round(end_time - start_time, 2)
        if 'cc_parts' in locals() and len(cc_parts) >= 4:
            bin_number = cc_parts[0][:6]
            cc_formatted_display = f"{cc_parts[0]}|{cc_parts[1]}|{cc_parts[2][-2:]}|{cc_parts[3]}"
        else:
            bin_number = "000000"
            cc_formatted_display = "N/A"
        info_line, bank_line, country_line = format_bin_info_for_pc(bin_number, None)
        safe_error_response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Card:* `{cc_formatted_display}`
\[[👾]({LINK_ONYKAFREE})\] *Status:* `Error en el procesamiento`
━━━━━━━━━━━━
{info_line}
{bank_line}
{country_line}
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Checked by:* @{escape_markdown_v2(username)} » {escape_markdown_v2(user_plan)}
\[[👾]({LINK_ONYKAFREE})\] *Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
        await edit_message_safe(processing_msg, safe_error_response, ParseMode.MARKDOWN_V2)
    finally:
        if user_id in paypal_charge_semaphores:
            paypal_charge_semaphores[user_id].release()

@require_individual_premium_access
@check_antispam("normal")
async def handle_pc_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict):
    user_id = update.effective_user.id
    cc_data = None
    if context.args:
        cc_data = ' '.join(context.args)
    elif update.message.reply_to_message:
        replied_text = update.message.reply_to_message.text or update.message.reply_to_message.caption or ""
        cc_data = extract_cc_from_text(replied_text)
        if not cc_data:
            response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Use:* `/pc cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
            await send_message_safe(update, context, response, ParseMode.MARKDOWN_V2)
            return
    if not cc_data:
        response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Use:* `/pc cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
        await send_message_safe(update, context, response, ParseMode.MARKDOWN_V2)
        return
    if user_id not in paypal_charge_semaphores:
        paypal_charge_semaphores[user_id] = asyncio.Semaphore(1)
    if paypal_charge_semaphores[user_id].locked():
        response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Stop:* _Wait for the current check to finish_.
━━━━━━━━━━━━
"""
        await send_message_safe(update, context, response, ParseMode.MARKDOWN_V2)
        return
    cc_parts_temp = cc_data.replace('|', ' ').replace(':', ' ').split()
    if len(cc_parts_temp) >= 4:
        cc_formatted_display = f"{cc_parts_temp[0]}|{cc_parts_temp[1]}|{cc_parts_temp[2][-2:]}|{cc_parts_temp[3]}"
    else:
        cc_formatted_display = cc_data
    processing_response = f"""
\[[👾]({LINK_ONYKAFREE})\] *Checking Card* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Card:* `{cc_formatted_display}`
━━━━━━━━━━━━
"""
    processing_msg = await send_message_safe(update, context, processing_response, ParseMode.MARKDOWN_V2)
    try:
        await paypal_charge_semaphores[user_id].acquire()
        asyncio.create_task(process_paypal_charge(update, context, db_config, cc_data, processing_msg, user_id))
    except Exception as e:
        if user_id in paypal_charge_semaphores:
            paypal_charge_semaphores[user_id].release()
        error_response = f"""
\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| *Paypal $2 \[[/pc]\]*
━━━━━━━━━━━━
\[[👾]({LINK_ONYKAFREE})\] *Error starting processing*
━━━━━━━━━━━━
"""
        await edit_message_safe(processing_msg, error_response, ParseMode.MARKDOWN_V2)
