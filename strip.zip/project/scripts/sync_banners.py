"""Upload local banners once and cache Telegram file IDs."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path

from aiogram import Bot
from aiogram.types import FSInputFile
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]
CACHE_FILE = PROJECT_ROOT / ".banner_file_ids.json"
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}


def get_banner_files() -> list[Path]:
    for directory_name in ("Banners", "banners"):
        directory = PROJECT_ROOT / directory_name
        if directory.is_dir():
            return sorted(
                path for path in directory.iterdir()
                if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
            )
    return []


async def sync_banners(chat_id: int) -> None:
    load_dotenv(PROJECT_ROOT / ".env")
    token = os.getenv("TELEGRAM_BOT_TOKEN") or os.getenv("BOT_TOKEN") or os.getenv("TG_TOKEN")
    if not token:
        raise RuntimeError("No Telegram bot token was found in .env")

    banner_files = get_banner_files()
    if not banner_files:
        raise RuntimeError("No banner images were found in Banners/ or banners/")

    file_ids: dict[str, str] = {}
    async with Bot(token=token) as bot:
        for banner_file in banner_files:
            message = await bot.send_photo(
                chat_id=chat_id,
                photo=FSInputFile(banner_file),
                caption=f"Noxus banner: {banner_file.name}",
            )
            file_ids[banner_file.name] = message.photo[-1].file_id
            print(f"Synced {len(file_ids)}/{len(banner_files)}")
            await asyncio.sleep(0.35)

    CACHE_FILE.write_text(
        json.dumps(file_ids, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Saved {len(file_ids)} Telegram file IDs to {CACHE_FILE.name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync local banners to Telegram")
    parser.add_argument("--chat-id", type=int, required=True, help="Destination Telegram chat ID")
    args = parser.parse_args()
    asyncio.run(sync_banners(args.chat_id))


if __name__ == "__main__":
    main()
