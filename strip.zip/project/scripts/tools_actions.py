import os
from utils.logging_setup import get_logger
logger = get_logger(__name__)

def fix_tools_actions():
    filepath = '/home/elit3signal/Documentos/BOT/tools_actions.py'
    if not os.path.exists(filepath):
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    marker = "    await processing_msg.edit_text(response, parse_mode='MarkdownV2')\n    \"\"\"\n    Manejador para el comando /extras"
    if marker in content:
        parts = content.split(marker)
        clean_content = parts[0] + "    await processing_msg.edit_text(response, parse_mode='MarkdownV2')\n"
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(clean_content)
        logger.info("🍒 tools_actions.py limpiado correctamente.")

if __name__ == '__main__':
    fix_tools_actions()
