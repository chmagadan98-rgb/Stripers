from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from datetime import datetime, timedelta
import random
import pytz

from admin_actions import get_db_connection, get_user_data_from_db
from bot_info import BOT_NAME, BOT_FREE

MEXICO_TIMEZONE = pytz.timezone('America/Mexico_City')

async def handle_checking_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    thread_id = update.effective_message.message_thread_id if update.effective_chat.is_forum else None
    
    # 1. Validar que sea en el grupo específico
    TARGET_GROUP_ID = -1003736571509
    if chat_id != TARGET_GROUP_ID:
        # Silencioso si se usa fuera del grupo o mensaje de error
        await update.message.reply_text("👻 Este comando solo está disponible en el grupo VIP oficial.", parse_mode="Markdown", message_thread_id=thread_id)
        return
        
    user_data = get_user_data_from_db(db_config, user_id)
    if not user_data:
        await update.message.reply_text("👻 No estás registrado. Usa /start en el bot privado primero.", parse_mode="Markdown", message_thread_id=thread_id)
        return
        
    conn = get_db_connection(db_config)
    if not conn: return
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("SELECT last_claim FROM users WHERE telegram_id = %s", (user_id,))
        res = cursor.fetchone()
        last_claim = res.get('last_claim') if res else None
        
        now = datetime.now()
        if last_claim:
            time_diff = now - last_claim
            if time_diff < timedelta(hours=24):
                remaining = timedelta(hours=24) - time_diff
                hours, remainder = divmod(remaining.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                await update.message.reply_text(
                    f"⏳ **Recompensa en enfriamiento**\n"
                    f"Vuelve en: `{hours}h {minutes}m {seconds}s` para reclamar más créditos.", 
                    parse_mode="Markdown",
                    message_thread_id=thread_id
                )
                return
                
        # Otorgar créditos (1 a 5)
        reward = random.randint(1, 5)
        cursor.execute("UPDATE users SET credits = credits + %s, last_claim = %s WHERE telegram_id = %s", (reward, now, user_id))
        conn.commit()
        
        new_credits = user_data.get('credits', 0) + reward
        
        # Escape markdown chars for V2
        import re
        def escape_md(text):
            if not text: return 'N/A'
            return re.sub(r'([_*[\]()~`>#+\-=|{}.!])', r'\\\1', str(text))
            
        username = escape_md(update.effective_user.username or str(user_id))
        reward_str = escape_md(f"+{reward}")
        total_str = escape_md(str(new_credits))
        
        response = f"""
\\[[👾]({BOT_FREE})\\] *{BOT_NAME}* \\| *Daily Reward*
━━━━━━━━━━━━
\\[[👾]({BOT_FREE})\\] *User:* @{username}
\\[[👾]({BOT_FREE})\\] *Reward:* `{reward_str}` credits 🎁
\\[[👾]({BOT_FREE})\\] *Total:* `{total_str}` credits
━━━━━━━━━━━━
_Gracias por tu actividad en el grupo\\!_
"""
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2, message_thread_id=thread_id)
    except Exception as e:
        print(f"Error in checking command: {e}")
        await update.message.reply_text("👻 Ocurrió un error al procesar la recompensa.", message_thread_id=thread_id)
    finally:
        cursor.close()
        conn.close()

__all__ = ['handle_checking_command']
