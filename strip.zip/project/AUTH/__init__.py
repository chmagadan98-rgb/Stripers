# AUTH/__init__.py - Corregido
import sys
import importlib
import logging
import warnings
import asyncio
from typing import Optional, List, Dict, Any, Callable
from types import ModuleType
from functools import wraps

# Configuración de logging
logger = logging.getLogger(__name__)

# Mapeo de módulos legacy a nuevos
_MODULE_MAP: Dict[str, str] = {
    'AUTH.auth_factory': 'bot.auth_factory',
    'AUTH.adyen_auth': 'bot.adyen_auth',
    'AUTH.auth_control': 'bot.auth_control',
    'AUTH.utils': 'bot.utils',
    'AUTH.config': 'bot.config',
}

# Módulos ya cargados
_loaded_modules: Dict[str, ModuleType] = {}

class AuthCompatWarning(DeprecationWarning):
    """Warning específico para deprecaciones del paquete AUTH."""
    pass

def _resolve_module_path(module_name: str) -> Optional[str]:
    """Resuelve la ruta del módulo legacy a la nueva."""
    return _MODULE_MAP.get(module_name)

def _load_module(module_name: str) -> Optional[ModuleType]:
    """Carga un módulo y lo cachea."""
    if module_name in _loaded_modules:
        return _loaded_modules[module_name]
    
    try:
        module = importlib.import_module(module_name)
        _loaded_modules[module_name] = module
        return module
    except ImportError as e:
        logger.error(f"Error importando módulo {module_name}: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Error inesperado importando {module_name}: {str(e)}")
        return None

def __getattr__(name: str) -> Any:
    """
    Intercepta acceso a atributos del paquete AUTH.
    
    Args:
        name: Nombre del atributo o submódulo solicitado
        
    Returns:
        El módulo o atributo correspondiente
        
    Raises:
        AttributeError: Si no se encuentra el atributo
    """
    # Emitir warning de deprecación
    warnings.warn(
        "El paquete 'AUTH' está deprecado. Use 'bot' en su lugar.",
        AuthCompatWarning,
        stacklevel=2
    )
    
    # Intentar resolver como módulo
    legacy_module = f"AUTH.{name}"
    if legacy_module in _MODULE_MAP:
        new_module = _resolve_module_path(legacy_module)
        if new_module:
            module = _load_module(new_module)
            if module:
                return module
    
    # Intentar importar directamente
    try:
        return importlib.import_module(f"AUTH.{name}")
    except ImportError:
        pass
    
    # Si no encontramos nada, lanzar error
    raise AttributeError(f"Módulo 'AUTH.{name}' no encontrado")

def __dir__() -> List[str]:
    """Lista los módulos disponibles en el paquete AUTH."""
    return list(_MODULE_MAP.keys()) + list(_loaded_modules.keys())

def register_module(legacy_path: str, new_path: str) -> None:
    """
    Registra un nuevo mapeo de módulo legacy a nuevo.
    
    Args:
        legacy_path: Ruta legacy (ej: 'AUTH.old_module')
        new_path: Nueva ruta (ej: 'bot.new_module')
    """
    _MODULE_MAP[legacy_path] = new_path
    logger.info(f"Registrado mapeo: {legacy_path} -> {new_path}")

def _verify_imports() -> bool:
    """Verifica que todos los módulos mapeados sean importables."""
    success = True
    for legacy, new in _MODULE_MAP.items():
        if not _load_module(new):
            logger.warning(f"Módulo no disponible: {new} (para {legacy})")
            success = False
    return success

def _cleanup_loaded_modules() -> None:
    """Limpia módulos cargados para evitar memory leak."""
    _loaded_modules.clear()
    logger.info("Módulos cargados limpiados")

# Ejecutar verificación al importar
_verify_imports()

__all__ = [
    'register_module',
    'AuthCompatWarning',
    '__getattr__',
    '__dir__',
    '_cleanup_loaded_modules',
]
