import time
import re
import asyncio
import random
import logging
import threading
from typing import Optional, Tuple, Dict, Any, List
from functools import wraps
from collections import defaultdict
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from datetime import datetime

from CHARGE.charge_gateways import (
    validate_cc_format,
    get_user_data_from_db,
    update_user_last_check
)
from utils.bin_api import get_bin_info
from utils.helpers import get_country_emoji
from bot_info import LINK_ONYKAFREE, BOT_NAME

# Configuración de logging
logger = logging.getLogger(__name__)

# Constantes
MAX_CARD_LENGTH = 19
MIN_CARD_LENGTH = 13
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos

# ============================================
# 1. MEJORA: Rate limiter thread-safe
# ============================================
class RateLimiter:
    """Rate limiter thread-safe."""
    
    def __init__(self, max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
        self.max_attempts = max_attempts
        self.window = window
        self.attempts = defaultdict(list)
        self.lock = threading.Lock()
    
    def check_and_add(self, user_id: int) -> Tuple[bool, int]:
        """Verifica y registra intento."""
        with self.lock:
            now = time.time()
            self.attempts[user_id] = [
                t for t in self.attempts[user_id] 
                if now - t < self.window
            ]
            
            if len(self.attempts[user_id]) >= self.max_attempts:
                wait_time = int(self.window - (now - self.attempts[user_id][0]))
                return False, wait_time
            
            self.attempts[user_id].append(now)
            return True, 0

# Instancia global
rate_limiter = RateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        
        return total % 10 == 0
    except Exception as e:
        logger.error(f"Error en validación Luhn: {str(e)}")
        return False

# ============================================
# 3. MEJORA: Funciones de escape
# ============================================
def escape_markdown_v2(text: Optional[str]) -> str:
    """Escapa texto para MarkdownV2 de forma segura."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!\\])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

def escape_inside_backticks(text: Optional[str]) -> str:
    """Escapa texto dentro de backticks."""
    if text is None:
        return 'N/A'
    return str(text).replace('\\', '\\\\').replace('`', '\\`')

# ============================================
# 4. MEJORA: Validación de tarjeta con Luhn
# ============================================
def validate_card_data(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida y parsea datos de tarjeta."""
    if not cc_data or len(cc_data) > MAX_CARD_LENGTH + 15:
        return False, "Formato inválido", None
    
    parts = cc_data.replace('|', ' ').split()
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    if not cc.isdigit() or not (MIN_CARD_LENGTH <= len(cc) <= MAX_CARD_LENGTH):
        return False, "Número de tarjeta inválido", None
    
    # Validar Luhn
    if not luhn_check(cc):
        return False, "Número de tarjeta no válido (fallo Luhn)", None
    
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    # Verificar fecha de expiración
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    
    if int(yy) < current_year or (int(yy) == current_year and int(mm) < current_month):
        return False, "Tarjeta expirada", None
    
    return True, None, (cc, mm, yy, cvv)

# ============================================
# 5. MEJORA: Análisis de respuesta corregido
# ============================================
def analyze_braintree_response(result: dict) -> Tuple[str, str]:
    """Analiza respuesta de Braintree con heurísticas mejoradas."""
    if not isinstance(result, dict):
        return "Error! 💥", "Respuesta no válida del procesador"

    if result.get('success'):
        return "Approved! 🍒", "1000: Approved (Charged $0.10)"
    
    error_text = result.get('message', 'Unknown Error')
    lower_err = error_text.lower()
    
    live_indicators = [
        "insufficient funds",
        "cvv mismatch",
        "card declined",
        "transaction not allowed",
        "do not honor",
        "invalid transaction",
        "card issuer declined"
    ]
    
    dead_indicators = [
        "invalid card number",
        "card type not accepted",
        "expired card",
        "invalid cvv",
        "card not supported"
    ]
    
    if any(indicator in lower_err for indicator in dead_indicators):
        return "Declined! 👻", error_text
    
    if any(indicator in lower_err for indicator in live_indicators):
        return "Approved! 🍒", f"Live: {error_text}"
    
    return "Declined! 👻", error_text

# ============================================
# 6. MEJORA: Handler corregido
# ============================================
async def handle_br_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Maneja el comando /br con mejoras de seguridad."""
    user_id = update.effective_user.id
    
    allowed, wait_time = rate_limiter.check_and_add(user_id)
    if not allowed:
        await update.message.reply_text(
            f"⚠️ *Rate limit excedido.*\n"
            f"Espera {wait_time} segundos antes de intentar de nuevo.",
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return
    
    if not context.args:
        response = f"""
\\[[👾]({LINK_ONYKAFREE})\\] *{BOT_NAME}* \\| *Braintree Auth \\[/br\\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\] *Use:* `/br cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return
    
    is_valid, error_msg, cc_parts = validate_card_data(context.args[0])
    if not is_valid:
        response = f"""
\\[[👾]({LINK_ONYKAFREE})\\] *{BOT_NAME}* \\| *Braintree Auth \\[/br\\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\] *Error:* `{escape_inside_backticks(error_msg)}`
\\[[👾]({LINK_ONYKAFREE})\\] *Use:* `/br cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return
    
    try:
        user_data = get_user_data_from_db(db_config, user_id) or {}
        username = user_data.get('username', 'N/A')
        role = user_data.get('role', 'user').upper()
        plan = user_data.get('plan', 'FREE').upper()
    except Exception as e:
        logger.error(f"Error obteniendo datos del usuario: {str(e)}")
        username, role, plan = 'N/A', 'USER', 'FREE'
    
    allowed_roles = ['OWNER', 'CO OWNER', 'DEV', 'SELLER']
    if role not in allowed_roles and plan not in ['PREMIUM', 'VIP']:
        response = f"\\[[👾]({LINK_ONYKAFREE})\\] *Acceso Denegado:* Requiere plan PREMIUM o VIP\\."
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return
    
    processing_msgs = [
        "⏳ `[+] POST /merchants/{id}/client_api/v1/payment_methods`",
        "⏳ `[+] POST /merchants/{id}/client_api/v1/payment_methods/{token}/three_d_secure/lookup`",
        "⏳ `[+] Procesando transacción...`"
    ]
    
    processing_msg = await update.message.reply_text(
        processing_msgs[0], 
        parse_mode=ParseMode.MARKDOWN
    )
    
    for msg in processing_msgs[1:]:
        await asyncio.sleep(0.8)
        try:
            await processing_msg.edit_text(msg, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logger.warning(f"Error editando mensaje: {str(e)}")
    
    start_time = time.time()
    cc, mm, yy, cvv = cc_parts
    cc_formatted_display = f"{cc}|{mm}|{yy[-2:]}|{cvv}"
    
    try:
        from utils.braintree_client import sale_transaction_raw
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, sale_transaction_raw, "0.10", cc, mm, yy, cvv)
        status, response_msg = analyze_braintree_response(result)
    except Exception as e:
        logger.error(f"Error procesando transacción: {str(e)}")
        status = "Error! 💥"
        response_msg = "Error interno al procesar"
    
    processing_time = round(time.time() - start_time, 2)
    
    bin_number = cc[:6]
    try:
        bin_data = await get_bin_info(bin_number)
    except Exception as e:
        logger.error(f"Error obteniendo BIN info: {str(e)}")
        bin_data = None
    
    info_line, bank_line, country_line = format_bin_info(bin_number, bin_data)
    
    try:
        update_user_last_check(db_config, user_id)
    except Exception as e:
        logger.error(f"Error actualizando último check: {str(e)}")
    
    status_escaped = escape_inside_backticks(status)
    response_escaped = escape_inside_backticks(response_msg)
    username_escaped = escape_markdown_v2(username)
    user_plan_display = escape_markdown_v2(role if role in allowed_roles else plan)
    
    output_msg = f"""
\\[[👾]({LINK_ONYKAFREE})\\] *{BOT_NAME}* \\| *Braintree Auth \\[/br\\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\] *Card:* `{cc_formatted_display}`
\\[[👾]({LINK_ONYKAFREE})\\] *Status:* `{status_escaped}`
\\[[👾]({LINK_ONYKAFREE})\\] *Response:* `{response_escaped}`
━━━━━━━━━━━━
{info_line}
{bank_line}
{country_line}
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\] *Checked by:* @{username_escaped} » {user_plan_display}
\\[[👾]({LINK_ONYKAFREE})\\] *Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    
    await processing_msg.edit_text(output_msg, parse_mode=ParseMode.MARKDOWN_V2)

# ============================================
# 7. MEJORA: Función de formateo BIN
# ============================================
def format_bin_info(bin_number: str, bin_data: dict) -> Tuple[str, str, str]:
    """Formatea información BIN con manejo robusto."""
    if not bin_data:
        return (
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Info:* Unknown \\- Unknown",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Bank:* `Unknown`",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Country:* `Unknown`"
        )
    
    try:
        scheme = escape_inside_backticks(bin_data.get('Scheme', 'Unknown'))
        card_type = escape_inside_backticks(bin_data.get('Type', 'Unknown').upper())
        issuer = escape_inside_backticks(bin_data.get('Issuer', 'Unknown'))
        country_data = bin_data.get('Country', {})
        country_name = escape_inside_backticks(country_data.get('Name', 'Unknown'))
        country_code = country_data.get('A2', 'Unknown')
        country_emoji = get_country_emoji(country_code)
        
        info = f"\\[[👾]({LINK_ONYKAFREE})\\] *Info:* `{scheme}` \\- `{card_type}`"
        bank = f"\\[[👾]({LINK_ONYKAFREE})\\] *Bank:* `{issuer}`"
        country = f"\\[[👾]({LINK_ONYKAFREE})\\] *Country:* `{country_name}` {country_emoji}"
        return info, bank, country
    except Exception as e:
        logger.error(f"Error formateando BIN info: {str(e)}")
        return (
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Info:* Error",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Bank:* Error",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Country:* Error"
        )