# stripe_auth.py – expose Stripe gateway functions for AUTH layer
# pyrefly: ignore [missing-import]
import logging
import sys
import asyncio
from typing import Any, Callable, Dict, Optional, Union
from functools import wraps

# Configurar logging
logger = logging.getLogger(__name__)

# ============================================
# 1. MEJORA: Importación segura con manejo de errores
# ============================================
try:
    from CHARGE.stripe_gateways import (
        require_individual_premium_access,
        check_antispam,
        validate_cc_format,
        get_user_data_from_db,
        update_user_last_check,
    )
    _IMPORT_SUCCESS = True
except ImportError as e:
    logger.error(f"Error importando CHARGE.stripe_gateways: {str(e)}")
    _IMPORT_SUCCESS = False
    # Definir funciones placeholder para evitar errores en tiempo de ejecución
    require_individual_premium_access = None
    check_antispam = None
    validate_cc_format = None
    get_user_data_from_db = None
    update_user_last_check = None
except Exception as e:
    logger.critical(f"Error inesperado importando stripe_gateways: {str(e)}")
    _IMPORT_SUCCESS = False
    require_individual_premium_access = None
    check_antispam = None
    validate_cc_format = None
    get_user_data_from_db = None
    update_user_last_check = None

# ============================================
# 2. MEJORA: Verificación de funciones importadas
# ============================================
def _verify_imports() -> bool:
    """Verifica que todas las funciones requeridas estén disponibles."""
    required_funcs = [
        "require_individual_premium_access",
        "check_antispam",
        "validate_cc_format",
        "get_user_data_from_db",
        "update_user_last_check"
    ]
    
    for func_name in required_funcs:
        func = globals().get(func_name)
        if func is None or not callable(func):
            logger.error(f"Función requerida no disponible: {func_name}")
            return False
    
    return True

# ============================================
# 3. MEJORA: Wrappers con logging y manejo de errores
# ============================================
def _wrap_function(func_name: str, func: Callable) -> Callable:
    """Envuelve una función para agregar logging y manejo de errores."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            logger.debug(f"Llamando a {func_name} con args={args}, kwargs={kwargs}")
            # CORRECCIÓN: Verificar si la función es async
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            logger.debug(f"{func_name} retornó: {result}")
            return result
        except Exception as e:
            logger.error(f"Error en {func_name}: {str(e)}")
            raise
    return wrapper

# ============================================
# 4. MEJORA: Funciones públicas con type hints
# ============================================
async def require_individual_premium_access_wrapper(user_id: Union[int, str], *args, **kwargs) -> bool:
    """
    Verifica si un usuario tiene acceso premium individual.
    
    Args:
        user_id: ID del usuario a verificar
        *args, **kwargs: Argumentos adicionales para la función original
    
    Returns:
        bool: True si el usuario tiene acceso premium, False en caso contrario
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if require_individual_premium_access is None:
        logger.error("require_individual_premium_access no está disponible")
        raise ImportError("Función no disponible: require_individual_premium_access")
    
    try:
        # CORRECCIÓN: Manejar tanto funciones async como síncronas
        if asyncio.iscoroutinefunction(require_individual_premium_access):
            result = await require_individual_premium_access(user_id, *args, **kwargs)
        else:
            result = require_individual_premium_access(user_id, *args, **kwargs)
        logger.info(f"Verificación de acceso premium para usuario {user_id}: {result}")
        return bool(result)
    except Exception as e:
        logger.error(f"Error verificando acceso premium para usuario {user_id}: {str(e)}")
        return False

async def check_antispam_wrapper(user_id: Union[int, str], *args, **kwargs) -> bool:
    """
    Verifica si un usuario está sujeto a restricciones antispam.
    
    Args:
        user_id: ID del usuario a verificar
        *args, **kwargs: Argumentos adicionales para la función original
    
    Returns:
        bool: True si el usuario está permitido, False si está bloqueado
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if check_antispam is None:
        logger.error("check_antispam no está disponible")
        raise ImportError("Función no disponible: check_antispam")
    
    try:
        # CORRECCIÓN: Manejar tanto funciones async como síncronas
        if asyncio.iscoroutinefunction(check_antispam):
            result = await check_antispam(user_id, *args, **kwargs)
        else:
            result = check_antispam(user_id, *args, **kwargs)
        logger.debug(f"Antispam para usuario {user_id}: {result}")
        return bool(result)
    except Exception as e:
        logger.error(f"Error en antispam para usuario {user_id}: {str(e)}")
        return False

async def validate_cc_format_wrapper(cc_data: str, *args, **kwargs) -> Dict[str, Any]:
    """
    Valida el formato de una tarjeta de crédito.
    
    Args:
        cc_data: Datos de la tarjeta en formato string
        *args, **kwargs: Argumentos adicionales para la función original
    
    Returns:
        Dict: Resultado de la validación con formato estandarizado
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if validate_cc_format is None:
        logger.error("validate_cc_format no está disponible")
        raise ImportError("Función no disponible: validate_cc_format")
    
    try:
        # CORRECCIÓN: Manejar tanto funciones async como síncronas
        if asyncio.iscoroutinefunction(validate_cc_format):
            result = await validate_cc_format(cc_data, *args, **kwargs)
        else:
            result = validate_cc_format(cc_data, *args, **kwargs)
        
        # Estandarizar el resultado
        if isinstance(result, tuple) and len(result) >= 2:
            is_valid, error_msg = result[0], result[1]
            return {
                "valid": bool(is_valid),
                "error": error_msg if not is_valid else None,
                "data": result[2] if len(result) > 2 else None
            }
        elif isinstance(result, dict):
            return result
        else:
            return {"valid": bool(result), "error": None, "data": None}
            
    except Exception as e:
        logger.error(f"Error validando formato de tarjeta: {str(e)}")
        return {"valid": False, "error": str(e), "data": None}

async def get_user_data_from_db_wrapper(user_id: Union[int, str], *args, **kwargs) -> Optional[Dict[str, Any]]:
    """
    Obtiene datos del usuario desde la base de datos.
    
    Args:
        user_id: ID del usuario
        *args, **kwargs: Argumentos adicionales para la función original
    
    Returns:
        Optional[Dict]: Datos del usuario o None si no existe
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if get_user_data_from_db is None:
        logger.error("get_user_data_from_db no está disponible")
        raise ImportError("Función no disponible: get_user_data_from_db")
    
    try:
        # CORRECCIÓN: Manejar tanto funciones async como síncronas
        if asyncio.iscoroutinefunction(get_user_data_from_db):
            result = await get_user_data_from_db(user_id, *args, **kwargs)
        else:
            result = get_user_data_from_db(user_id, *args, **kwargs)
        logger.debug(f"Datos de usuario {user_id} obtenidos: {bool(result)}")
        return result
    except Exception as e:
        logger.error(f"Error obteniendo datos de usuario {user_id}: {str(e)}")
        return None

async def update_user_last_check_wrapper(user_id: Union[int, str], *args, **kwargs) -> bool:
    """
    Actualiza el timestamp del último chequeo del usuario.
    
    Args:
        user_id: ID del usuario
        *args, **kwargs: Argumentos adicionales para la función original
    
    Returns:
        bool: True si se actualizó correctamente, False en caso contrario
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if update_user_last_check is None:
        logger.error("update_user_last_check no está disponible")
        raise ImportError("Función no disponible: update_user_last_check")
    
    try:
        # CORRECCIÓN: Manejar tanto funciones async como síncronas
        if asyncio.iscoroutinefunction(update_user_last_check):
            result = await update_user_last_check(user_id, *args, **kwargs)
        else:
            result = update_user_last_check(user_id, *args, **kwargs)
        logger.debug(f"Último chequeo actualizado para usuario {user_id}")
        return bool(result)
    except Exception as e:
        logger.error(f"Error actualizando último chequeo para usuario {user_id}: {str(e)}")
        return False

# ============================================
# 5. MEJORA: Clase AuthManager para manejo centralizado
# ============================================
class StripeAuthManager:
    """
    Gestor centralizado de autenticación para el gateway de Stripe.
    """
    
    def __init__(self):
        self.import_success = _IMPORT_SUCCESS
        self.verified = _verify_imports()
        
        if not self.verified:
            logger.warning("StripeAuthManager inicializado con importaciones incompletas")
    
    async def check_access(self, user_id: Union[int, str]) -> Dict[str, Any]:
        """
        Verifica el acceso completo de un usuario.
        
        Args:
            user_id: ID del usuario
        
        Returns:
            Dict con el estado de acceso del usuario
        """
        result = {
            "premium_access": False,
            "antispam_ok": False,
            "user_data": None,
            "can_proceed": False
        }
        
        try:
            # Verificar acceso premium
            result["premium_access"] = await require_individual_premium_access_wrapper(user_id)
            
            # Verificar antispam
            result["antispam_ok"] = await check_antispam_wrapper(user_id)
            
            # Obtener datos del usuario
            result["user_data"] = await get_user_data_from_db_wrapper(user_id)
            
            # Determinar si puede proceder
            result["can_proceed"] = result["premium_access"] and result["antispam_ok"]
            
            logger.info(f"Verificación de acceso para usuario {user_id}: {result}")
            
        except Exception as e:
            logger.error(f"Error en verificación de acceso para usuario {user_id}: {str(e)}")
        
        return result
    
    async def validate_and_process(self, user_id: Union[int, str], cc_data: str) -> Dict[str, Any]:
        """
        Valida una tarjeta y procesa el chequeo.
        
        Args:
            user_id: ID del usuario
            cc_data: Datos de la tarjeta
        
        Returns:
            Dict con el resultado de la validación y procesamiento
        """
        result = {
            "valid": False,
            "error": None,
            "can_proceed": False
        }
        
        # Primero verificar acceso
        access = await self.check_access(user_id)
        if not access["can_proceed"]:
            result["error"] = "Usuario no autorizado"
            return result
        
        # Validar formato de tarjeta
        validation = await validate_cc_format_wrapper(cc_data)
        result.update(validation)
        
        if validation["valid"]:
            # Actualizar último chequeo
            await update_user_last_check_wrapper(user_id)
            result["can_proceed"] = True
        
        return result

# ============================================
# 6. MEJORA: Función de inicialización
# ============================================
def init_stripe_auth() -> bool:
    """
    Inicializa el módulo de autenticación de Stripe.
    
    Returns:
        bool: True si la inicialización fue exitosa
    """
    logger.info("Inicializando StripeAuthManager...")
    
    manager = StripeAuthManager()
    
    if manager.import_success and manager.verified:
        logger.info("StripeAuthManager inicializado correctamente")
        return True
    else:
        logger.error("StripeAuthManager no se pudo inicializar correctamente")
        return False

# ============================================
# 7. MEJORA: Instancia global del manager
# ============================================
auth_manager = StripeAuthManager()

# ============================================
# 8. MEJORA: Exportaciones actualizadas
# ============================================
__all__ = [
    # Funciones originales (si están disponibles)
    "require_individual_premium_access",
    "check_antispam",
    "validate_cc_format",
    "get_user_data_from_db",
    "update_user_last_check",
    
    # Wrappers mejorados
    "require_individual_premium_access_wrapper",
    "check_antispam_wrapper",
    "validate_cc_format_wrapper",
    "get_user_data_from_db_wrapper",
    "update_user_last_check_wrapper",
    
    # Clase gestora
    "StripeAuthManager",
    "auth_manager",
    
    # Utilidades
    "init_stripe_auth",
    "verify_imports",
]

# ============================================
# 9. MEJORA: Función de verificación pública
# ============================================
def verify_imports() -> bool:
    """
    Verifica públicamente que todas las importaciones sean correctas.
    
    Returns:
        bool: True si todas las funciones están disponibles
    """
    return _verify_imports()

# ============================================
# 10. MEJORA: Decorador para uso en handlers
# ============================================
def require_auth(func: Callable) -> Callable:
    """
    Decorador para requerir autenticación en handlers.
    
    Uso:
        @require_auth
        async def my_handler(update, context):
            ...
    """
    @wraps(func)
    async def wrapper(*args, **kwargs):
        # Extraer update y context
        update = args[0] if args else kwargs.get('update')
        
        if update and hasattr(update, 'effective_user'):
            user_id = update.effective_user.id
            
            # Verificar acceso
            access = await auth_manager.check_access(user_id)
            
            if not access["can_proceed"]:
                if hasattr(update, 'message'):
                    await update.message.reply_text(
                        "❌ *Acceso denegado.*\n"
                        "Necesitas acceso premium para usar este comando.",
                        parse_mode='Markdown'
                    )
                return
            
            # Actualizar último chequeo
            await update_user_last_check_wrapper(user_id)
        
        return await func(*args, **kwargs)
    
    return wrapper