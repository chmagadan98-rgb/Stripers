# b3_premium_control.py - Corregido y Blindado
import asyncio
import random
import time
import logging
import re
import threading
from typing import Optional, Tuple, Dict, Any
from functools import wraps
from collections import defaultdict
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from tools_actions import get_bin_data_gen

# Configuración de logging
logger = logging.getLogger(__name__)

# Constantes
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos

# ============================================
# 1. MEJORA: Rate limiter thread-safe
# ============================================
class RateLimiter:
    """Rate limiter thread-safe."""
    
    def __init__(self, max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
        self.max_attempts = max_attempts
        self.window = window
        self.attempts = defaultdict(list)
        self.lock = threading.Lock()
    
    def check_and_add(self, user_id: int) -> Tuple[bool, int]:
        """Verifica y registra intento."""
        with self.lock:
            now = time.time()
            self.attempts[user_id] = [
                t for t in self.attempts[user_id] 
                if now - t < self.window
            ]
            
            if len(self.attempts[user_id]) >= self.max_attempts:
                wait_time = int(self.window - (now - self.attempts[user_id][0]))
                return False, wait_time
            
            self.attempts[user_id].append(now)
            return True, 0

# Instancia global
rate_limiter = RateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        
        return total % 10 == 0
    except Exception as e:
        logger.error(f"Error en validación Luhn: {str(e)}")
        return False

# ============================================
# 3. MEJORA: Validación de tarjeta
# ============================================
def validate_card_format(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta de crédito."""
    if not cc_data or len(cc_data) > 19 + 15:
        return False, "Formato inválido", None
    
    parts = cc_data.replace('|', ' ').split()
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    # Validar Luhn
    if not luhn_check(cc):
        return False, "Número de tarjeta no válido (fallo Luhn)", None
    
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    # Verificar fecha de expiración
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    
    if int(yy) < current_year or (int(yy) == current_year and int(mm) < current_month):
        return False, "Tarjeta expirada", None
    
    return True, None, (cc, mm, yy, cvv)

# ============================================
# 4. MEJORA: Escape de Markdown
# ============================================
def escape_markdown(text: Optional[str]) -> str:
    """Escapa texto para Markdown de forma segura."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!\\])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

# ============================================
# 5. MEJORA: Handler corregido
# ============================================
async def handle_ba_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Maneja el comando /ba con mejoras de seguridad."""
    user_id = update.effective_user.id
    
    # Verificar rate limit
    allowed, wait_time = rate_limiter.check_and_add(user_id)
    if not allowed:
        await update.message.reply_text(
            f"⚠️ *Rate limit excedido.*\n"
            f"Espera {wait_time} segundos antes de intentar de nuevo.",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    text = update.message.text
    cc_parts = text.split()[1] if len(text.split()) > 1 else None
    
    if not cc_parts:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *B3 Premium Auth \[[/ba]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/ba cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN)
        return
    
    # Validar formato de tarjeta
    is_valid, error_msg, cc_data = validate_card_format(cc_parts)
    if not is_valid:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *B3 Premium Auth \[[/ba]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Error:* `{error_msg}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/ba cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN)
        return
    
    # Iniciar mensaje de procesamiento
    wait_msg = await update.message.reply_text(
        f"⏳ `Initializing security check...`", 
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Mensajes de procesamiento
    processing_steps = [
        "Contacting issuing bank...",
        "Running fraud detection...",
        "Verifying transaction..."
    ]
    
    for step in processing_steps:
        await asyncio.sleep(0.8)
        try:
            await wait_msg.edit_text(f"⏳ `{step}`", parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logger.warning(f"Error editando mensaje: {str(e)}")
    
    # Obtener información BIN
    cc, mm, yy, cvv = cc_data
    
    # Obtener BIN info de forma segura
    bin_info = get_bin_info_safe(cc[:6])
    
    # Simular verificación con lógica mejorada
    start_time = time.time()
    await asyncio.sleep(0.5)
    
    # Lógica de simulación más realista
    first_digit = int(cc[0])
    sim_status = "Approved" if first_digit in [4, 5, 6] else "Declined"
    
    # Considerar otros factores
    if sim_status == "Approved" and (int(mm) > 12 or int(yy) < 20):
        sim_status = "Declined"
    
    status_emoji = "🍒" if sim_status == "Approved" else "👻"
    response_text = "Transaction successful" if sim_status == "Approved" else "Declined by Network"
    
    processing_time = round(time.time() - start_time, 2)
    
    # Formatear respuesta
    username = update.effective_user.username if update.effective_user.username else update.effective_user.first_name
    username_escaped = escape_markdown(username)
    
    response = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *B3 Premium Auth \[[/ba]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Card:* `{cc}|{mm}|{yy[-2:]}|{cvv}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Bank Info:* `{bin_info['bank']} - {bin_info['level']} {bin_info['type']} ({bin_info['country']})`
\\[[👾]({LINK_ONYKAFREE})\\]
*Status:* {sim_status}! {status_emoji}
\\[[👾]({LINK_ONYKAFREE})\\]
*Response:* `{response_text}`
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Checked by:* @{username_escaped}
\\[[👾]({LINK_ONYKAFREE})\\]
*Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    await wait_msg.edit_text(response, parse_mode=ParseMode.MARKDOWN)

# ============================================
# 6. MEJORA: Función BIN segura
# ============================================
def get_bin_info_safe(bin_number: str) -> Dict[str, Any]:
    """Obtiene información BIN con manejo de errores."""
    try:
        bin_data = get_bin_data_gen(bin_number)
        if bin_data:
            return {
                'country': bin_data.get('Country', {}).get('A2', 'UNKNOWN').upper(),
                'bank': bin_data.get('Issuer', 'UNKNOWN').upper(),
                'level': bin_data.get('Category', 'UNKNOWN').upper(),
                'type': bin_data.get('Type', 'UNKNOWN').upper()
            }
    except Exception as e:
        logger.error(f"Error obteniendo BIN info: {str(e)}")
    
    return {
        'country': 'UNKNOWN',
        'bank': 'UNKNOWN',
        'level': 'UNKNOWN',
        'type': 'UNKNOWN'
    }