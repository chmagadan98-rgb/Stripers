"""Wrapper module exposing the synchronous Stripe checker.
Provides ``check_stripe_card`` for legacy imports.
"""

import logging
from typing import Any, Optional, Tuple, Dict
from functools import wraps

# Configurar logging
logger = logging.getLogger(__name__)

# ============================================
# 1. MEJORA: Importación segura
# ============================================
try:
    from utils.stripe_check_sync import check_stripe_card as _original_check_stripe_card
    
    if not callable(_original_check_stripe_card):
        raise ImportError("check_stripe_card no es una función llamable")
    
    _IMPORT_SUCCESS = True
    logger.info("Importación exitosa de utils.stripe_check_sync.check_stripe_card")
    
except ImportError as e:
    logger.error(f"Error importando utils.stripe_check_sync: {str(e)}")
    _IMPORT_SUCCESS = False
    _original_check_stripe_card = None
    
except Exception as e:
    logger.critical(f"Error inesperado importando stripe_check_sync: {str(e)}")
    _IMPORT_SUCCESS = False
    _original_check_stripe_card = None

# ============================================
# 2. MEJORA: Wrapper con verificación
# ============================================
def check_stripe_card(card_data: str, *args: Any, **kwargs: Any) -> Tuple[str, str, Optional[Dict]]:
    """
    Verifica una tarjeta de crédito usando Stripe de forma síncrona.
    
    Args:
        card_data: Datos de la tarjeta en formato "cc|mm|yy|cvv"
        *args: Argumentos adicionales
        **kwargs: Keyword arguments adicionales
    
    Returns:
        Tuple[str, str, Optional[Dict]]: (status, message, extra_info)
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    if not _IMPORT_SUCCESS or not callable(_original_check_stripe_card):
        logger.error("check_stripe_card no está disponible")
        raise ImportError("check_stripe_card no está disponible")
    
    try:
        logger.debug(f"Llamando a check_stripe_card con tarjeta: {card_data[:6]}...")
        result = _original_check_stripe_card(card_data, *args, **kwargs)
        logger.info(f"check_stripe_card completado: {result[0] if isinstance(result, tuple) else result}")
        return result
    except Exception as e:
        logger.error(f"Error en check_stripe_card: {str(e)}")
        return "Error", str(e), None

# ============================================
# 3. MEJORA: Función de verificación
# ============================================
def verify_import() -> bool:
    """Verifica si la importación fue exitosa."""
    return _IMPORT_SUCCESS and callable(_original_check_stripe_card)

# ============================================
# 4. MEJORA: Exportaciones
# ============================================
__all__ = ["check_stripe_card", "verify_import"]