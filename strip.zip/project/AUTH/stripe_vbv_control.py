# svbv_handler.py - Stripe 3D Secure (VBV) check handler (Cleaned & Blinded)
import asyncio
import re
import time
import logging
from typing import Optional, Tuple, Dict, Any
from collections import defaultdict
from datetime import datetime
from functools import wraps

from aiogram import Router, types
from aiogram.filters import Command

from utils.stripe_check_sync import check_stripe_card
from utils.logging_setup import get_logger

logger = get_logger(__name__)

router = Router()

# ============================================
# 1. MEJORA: Rate limiter para comando SVBV
# ============================================
class SVBVRateLimiter:
    """Rate limiter específico para el comando /svbv."""
    
    def __init__(self, max_attempts: int = 8, window_seconds: int = 60):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self.attempts = defaultdict(list)
    
    def is_allowed(self, user_id: int) -> Tuple[bool, int]:
        """Verifica si el usuario puede hacer una solicitud."""
        now = time.time()
        self.attempts[user_id] = [
            t for t in self.attempts[user_id] 
            if now - t < self.window_seconds
        ]
        
        if len(self.attempts[user_id]) >= self.max_attempts:
            wait_time = int(self.window_seconds - (now - self.attempts[user_id][0]))
            return False, wait_time
        
        self.attempts[user_id].append(now)
        return True, 0

# Instancia global
svbv_rate_limiter = SVBVRateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        
        return total % 10 == 0
    except Exception as e:
        logger.error(f"Error en validación Luhn: {str(e)}")
        return False

# ============================================
# 3. MEJORA: Validación completa de tarjeta
# ============================================
def validate_card_data(card_data_raw: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta con verificación Luhn."""
    card_parts = card_data_raw.split('|')
    
    if len(card_parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mes, ano, cvv = card_parts
    
    # Validar número
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    # Validar Luhn
    if not luhn_check(cc):
        return False, "Número de tarjeta no válido (fallo Luhn)", None
    
    # Validar mes
    if not mes.isdigit() or not (1 <= int(mes) <= 12):
        return False, "Mes inválido", None
    
    # Validar año
    if not ano.isdigit() or len(ano) not in [2, 4]:
        return False, "Año inválido", None
    
    # Validar CVV
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    # Verificar fecha de expiración
    full_ano = f"20{ano}" if len(ano) == 2 else ano
    current_year = int(time.strftime("%Y"))
    current_month = int(time.strftime("%m"))
    
    if int(full_ano) < current_year or (int(full_ano) == current_year and int(mes) < current_month):
        return False, "Tarjeta expirada", None
    
    return True, None, (cc, mes, full_ano, cvv)

# ============================================
# 4. MEJORA: Interpretación de resultados más robusta
# ============================================
def interpret_result(status: str, message_text: str, extra_info: dict) -> str:
    """Interpreta el resultado de check_stripe_card de manera robusta."""
    
    # Normalizar status
    status_lower = status.lower()
    
    if "approved" in status_lower or "live" in status_lower:
        # Caso aprobado
        three_ds = extra_info.get("3ds_status", "UNKNOWN")
        
        if three_ds == "AUTHENTICATED":
            return (
                "<b>Estado 3DS:</b> ✅ Autenticado (Frictionless)\n"
                f"<b>Mensaje:</b> {message_text}\n"
                "<b>Detalles:</b> <code>Tarjeta verificada y lista para transacción.</code>"
            )
        elif three_ds == "UNKNOWN_3DS_STATUS":
            return (
                "<b>Estado 3DS:</b> ✅ Aprobado (Estado 3DS desconocido)\n"
                f"<b>Mensaje:</b> {message_text}\n"
                "<b>Detalles:</b> <code>Transacción aprobada, pero sin información explícita de 3DS.</code>"
            )
        else:
            return (
                "<b>Estado 3DS:</b> ✅ Aprobado\n"
                f"<b>Mensaje:</b> {message_text}\n"
                "<b>Detalles:</b> <code>Transacción aprobada.</code>"
            )
    
    elif "declined" in status_lower or "dead" in status_lower:
        # Caso rechazado
        three_ds = extra_info.get("3ds_status", "UNKNOWN")
        
        if three_ds == "CHALLENGE_REQUIRED":
            return (
                "<b>Estado 3DS:</b> ⚠️ Desafío Requerido\n"
                f"<b>Mensaje:</b> {message_text}\n"
                "<b>Detalles:</b> <code>Se requiere interacción del usuario para completar la autenticación 3DS.</code>"
            )
        else:
            return (
                "<b>Estado 3DS:</b> ❌ Rechazado\n"
                f"<b>Mensaje:</b> {message_text}\n"
                "<b>Detalles:</b> <code>La tarjeta fue rechazada por el emisor o el servicio 3DS.</code>"
            )
    
    else:
        # Caso error
        return (
            "<b>Estado 3DS:</b> 🚫 Error\n"
            f"<b>Mensaje:</b> {message_text}\n"
            "<b>Detalles:</b> <code>Ocurrió un error inesperado durante la verificación 3DS.</code>"
        )

# ============================================
# 5. MEJORA: Handler principal mejorado
# ============================================
@router.message(Command("svbv"))
async def handle_svbv_command(message: types.Message):
    """
    Handler for Stripe 3D Secure (VBV) check.
    Versión mejorada con validación Luhn, rate limiting y manejo robusto.
    """
    user_id = message.from_user.id
    logger.info(f"User {user_id} inició comando Stripe VBV Auth.")
    
    # Verificar rate limit
    allowed, wait_time = svbv_rate_limiter.is_allowed(user_id)
    if not allowed:
        await message.reply(
            f"<b>⚠️ Rate limit excedido.</b>\n"
            f"Espera {wait_time} segundos antes de intentar de nuevo.",
            parse_mode='HTML'
        )
        return
    
    # Extraer datos de tarjeta
    command_args = message.text.split(maxsplit=1)
    if len(command_args) < 2:
        await message.reply(
            "<b>👻 Formato inválido.</b> Usa: <code>/svbv cc|mm|yy|cvv</code>",
            parse_mode='HTML'
        )
        return
    
    card_data_raw = command_args[1].strip()
    
    # Validar formato de tarjeta
    is_valid, error_msg, card_data = validate_card_data(card_data_raw)
    if not is_valid:
        await message.reply(
            f"<b>👻 {error_msg}</b>\n"
            "<b>Uso:</b> <code>/svbv cc|mm|yy|cvv</code>",
            parse_mode='HTML'
        )
        return
    
    cc, mes, full_ano, cvv = card_data
    
    # Mensaje de procesamiento
    processing_msg = await message.reply(
        "⏳ <code>Iniciando verificación 3D Secure con Stripe...</code>",
        parse_mode='HTML'
    )
    
    loop = asyncio.get_event_loop()
    start_time = time.time()
    
    try:
        # Ejecutar verificación
        status, message_text, extra_info = await loop.run_in_executor(
            None,
            lambda: check_stripe_card(f"{cc}|{mes}|{full_ano}|{cvv}")
        )
        
        # Calcular tiempo de procesamiento
        processing_time = round(time.time() - start_time, 2)
        
        # Interpretar resultado
        result_3ds = interpret_result(status, message_text, extra_info or {})
        
        # Formatear respuesta
        response_output = (
            f"<b>Tarjeta:</b> <code>{cc}|{mes}|{full_ano[2:]}|{cvv}</code>\n"
            f"{result_3ds}\n"
            f"<b>Tiempo:</b> <code>{processing_time}s</code>"
        )
        
        await processing_msg.edit_text(response_output, parse_mode='HTML')
        
        # Logging
        logger.info(f"SVBV check completado: User={user_id} Status={status} Card={cc[:6]}...")
        
    except Exception as e:
        logger.error(f"Error durante verificación SVBV para usuario {user_id}: {e}", exc_info=True)
        await processing_msg.edit_text(
            f"<b>🚫 Ocurrió un error inesperado:</b> <code>{str(e)}</code>",
            parse_mode='HTML'
        )

# ============================================
# 6. MEJORA: Decorador para logging
# ============================================
def log_command(func):
    """Decorador para logging de comandos."""
    @wraps(func)
    async def wrapper(message: types.Message, *args, **kwargs):
        user_id = message.from_user.id if message.from_user else 'Unknown'
        command = message.text.split()[0] if message.text else 'Unknown'
        
        logger.info(f"[COMMAND] User={user_id} Command={command}")
        
        start_time = time.time()
        result = await func(message, *args, **kwargs)
        elapsed = round(time.time() - start_time, 2)
        
        logger.info(f"[COMMAND] User={user_id} Command={command} Time={elapsed}s")
        return result
    
    return wrapper

# Aplicar decorador al handler
handle_svbv_command = log_command(handle_svbv_command)

# ============================================
# 7. MEJORA: Exportaciones
# ============================================
__all__ = [
    "router",
    "handle_svbv_command",
    "validate_card_data",
    "luhn_check",
    "svbv_rate_limiter"
]