# -*- coding: utf-8 -*-
from aiogram import types
from aiogram.filters import Command
import logging
import asyncio
import time
import re
from typing import Optional, Tuple, Dict, Any
from functools import wraps

# Configuración de logging
logger = logging.getLogger(__name__)

# Constantes
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos

# Decorador para rate limiting
def rate_limit(max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
    """Limita intentos por usuario."""
    attempts = {}
    
    def decorator(func):
        @wraps(func)
        async def wrapper(message: types.Message, *args, **kwargs):
            user_id = message.from_user.id
            now = time.time()
            
            # Limpiar intentos antiguos
            if user_id in attempts:
                attempts[user_id] = [t for t in attempts[user_id] if now - t < window]
            else:
                attempts[user_id] = []
            
            # Verificar límite
            if len(attempts[user_id]) >= max_attempts:
                wait_time = int(window - (now - attempts[user_id][0]))
                await message.reply(
                    f"⚠️ Rate limit excedido. Espera {wait_time} segundos.",
                    parse_mode='Markdown'
                )
                return
            
            attempts[user_id].append(now)
            return await func(message, *args, **kwargs)
        return wrapper
    return decorator

def validate_card_format(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta de crédito."""
    if not cc_data or len(cc_data) > 19 + 15:
        return False, "Formato inválido", None
    
    parts = cc_data.replace('|', ' ').split()
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    return True, None, (cc, mm, yy, cvv)

def escape_markdown(text: Optional[str]) -> str:
    """Escapa texto para Markdown de forma segura."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

async def get_bin_info(bin_number: str) -> Dict[str, Any]:
    """Obtiene información BIN de forma segura."""
    try:
        from tools_actions import get_bin_data_gen
        bin_data = await get_bin_data_gen(bin_number)
        if bin_data:
            return {
                'scheme': bin_data.get('Scheme', 'UNKNOWN').upper(),
                'type': bin_data.get('Type', 'UNKNOWN').upper(),
                'bank': bin_data.get('Issuer', 'UNKNOWN').upper(),
                'country': bin_data.get('Country', {}).get('Name', 'UNKNOWN').upper(),
                'country_code': bin_data.get('Country', {}).get('A2', 'UNKNOWN').upper()
            }
    except Exception as e:
        logger.error(f"Error obteniendo BIN info: {str(e)}")
    
    return {
        'scheme': 'UNKNOWN',
        'type': 'UNKNOWN',
        'bank': 'UNKNOWN',
        'country': 'UNKNOWN',
        'country_code': 'UNKNOWN'
    }

@rate_limit()
async def handle_vbv_command(message: types.Message):
    """
    Handler for VBV Auth - Verified by Visa.
    """
    user_id = message.from_user.id
    logger.info(f"User {user_id} initiated VBV Auth command.")
    
    # Parsear argumentos
    text = message.text
    args = text.split()[1:] if len(text.split()) > 1 else []
    
    if not args:
        await message.reply(
            "[👾] *VBV Auth* \\| *Verified by Visa*\n"
            "━━━━━━━━━━━━\n"
            "[👾] *Use:* `/vbv cc|mm|yy|cvv`\n"
            "━━━━━━━━━━━━",
            parse_mode='MarkdownV2'
        )
        return
    
    # Validar formato de tarjeta
    is_valid, error_msg, cc_data = validate_card_format(args[0])
    if not is_valid:
        await message.reply(
            f"[👾] *VBV Auth* \\| *Verified by Visa*\n"
            f"━━━━━━━━━━━━\n"
            f"[👾] *Error:* `{escape_markdown(error_msg)}`\n"
            f"[👾] *Use:* `/vbv cc|mm|yy|cvv`\n"
            f"━━━━━━━━━━━━",
            parse_mode='MarkdownV2'
        )
        return
    
    # Mensaje de procesamiento
    processing_msg = await message.reply(
        "⏳ `[+] Initializing VBV verification...`",
        parse_mode='Markdown'
    )
    
    # Simular pasos de procesamiento
    steps = [
        "Contacting Visa network...",
        "Verifying 3D Secure...",
        "Processing authentication..."
    ]
    
    for step in steps:
        await asyncio.sleep(0.8)
        try:
            await processing_msg.edit_text(
                f"⏳ `[+] {step}`",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.warning(f"Error editando mensaje: {str(e)}")
    
    # Obtener datos de la tarjeta
    cc, mm, yy, cvv = cc_data
    cc_display = f"{cc}|{mm}|{yy[-2:]}|{cvv}"
    
    # Obtener información BIN
    bin_data = await get_bin_info(cc[:6])
    
    # Simular resultado VBV
    start_time = time.time()
    await asyncio.sleep(0.5)
    
    # Lógica de simulación
    first_digit = int(cc[0])
    is_vbv_enrolled = first_digit in [4, 5]  # Visa/Mastercard
    
    if is_vbv_enrolled:
        # Simular resultado
        if first_digit == 4:  # Visa
            sim_status = "Enrolled" if int(cc[-1]) % 2 == 0 else "Not Enrolled"
            sim_response = "3D Secure verification successful" if sim_status == "Enrolled" else "Card not enrolled in VBV"
        else:  # Mastercard
            sim_status = "Enrolled" if int(cc[-1]) % 3 == 0 else "Not Enrolled"
            sim_response = "SecureCode verification successful" if sim_status == "Enrolled" else "Card not enrolled in SecureCode"
    else:
        sim_status = "Not Supported"
        sim_response = "Card type not supported for VBV"
    
    processing_time = round(time.time() - start_time, 2)
    
    # Formatear respuesta
    username = message.from_user.username if message.from_user.username else message.from_user.first_name
    username_escaped = escape_markdown(username)
    
    response = (
        f"[👾](https://t.me/yourbot) *VBV Auth* \\| *Verified by Visa*\n"
        f"━━━━━━━━━━━━\n"
        f"[👾](https://t.me/yourbot) *Card:* `{cc_display}`\n"
        f"[👾](https://t.me/yourbot) *Bank:* `{bin_data['bank']}`\n"
        f"[👾](https://t.me/yourbot) *Type:* `{bin_data['scheme']} - {bin_data['type']}`\n"
        f"[👾](https://t.me/yourbot) *Country:* `{bin_data['country']} ({bin_data['country_code']})`\n"
        f"━━━━━━━━━━━━\n"
        f"[👾](https://t.me/yourbot) *Status:* `{sim_status}`\n"
        f"[👾](https://t.me/yourbot) *Response:* `{sim_response}`\n"
        f"━━━━━━━━━━━━\n"
        f"[👾](https://t.me/yourbot) *Checked by:* @{username_escaped}\n"
        f"[👾](https://t.me/yourbot) *Time:* `{processing_time}s`\n"
        f"━━━━━━━━━━━━"
    )
    
    await processing_msg.edit_text(response, parse_mode='MarkdownV2')

# Registrar comando
def register_vbv_handler(router):
    """Registra el handler VBV en el router."""
    router.message.register(handle_vbv_command, Command("vbv"))
    logger.info("Handler VBV registrado")