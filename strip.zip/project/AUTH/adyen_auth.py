import logging
import time
import threading
from typing import Optional, Dict, Any, Union, Tuple
from collections import defaultdict

# Importar funciones originales con alias para evitar recursión
from bot.adyen_es_gateways import (
    require_individual_premium_access as _original_premium_access,
    check_antispam as _original_check_antispam,
    validate_cc_format as _original_validate_cc,
    get_user_data_from_db as _original_get_user_data,
    update_user_last_check as _original_update_last_check,
)

# Configuración de logging
logger = logging.getLogger(__name__)

# ============================================
# 1. MEJORA: Rate limiter thread-safe
# ============================================
class RateLimiter:
    """Rate limiter thread-safe para entornos concurrentes."""
    def __init__(self, max_attempts: int = 5, window_seconds: int = 60):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self.attempts = defaultdict(list)
        self.lock = threading.Lock()
    
    def check_and_add(self, identifier: str) -> Tuple[bool, int]:
        """Verifica y registra intento."""
        with self.lock:
            now = time.time()
            
            # Limpiar intentos que ya caducaron fuera de la ventana
            self.attempts[identifier] = [
                t for t in self.attempts[identifier] 
                if now - t < self.window_seconds
            ]
            
            # Verificar si excede el límite
            if len(self.attempts[identifier]) >= self.max_attempts:
                wait_time = int(self.window_seconds - (now - self.attempts[identifier][0]))
                return False, wait_time
            
            # Registrar nuevo intento
            self.attempts[identifier].append(now)
            return True, 0

# Instancia global
rate_limiter = RateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        
        return total % 10 == 0
    except Exception as e:
        logger.error(f"Error en validación Luhn: {str(e)}")
        return False

# ============================================
# 3. MEJORA: Funciones corregidas
# ============================================
async def require_individual_premium_access(user_id: Union[int, str], ip: str = None) -> Dict[str, Any]:
    """Verifica acceso premium individual con rate limiting."""
    identifier = str(ip or user_id)
    
    # Verificar rate limit
    allowed, wait_time = rate_limiter.check_and_add(identifier)
    if not allowed:
        return {"success": False, "error": f"Rate limit excedido. Espera {wait_time}s"}
    
    try:
        result = await _original_premium_access(user_id)
        logger.info(f"Acceso premium verificado para usuario: {user_id}")
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Error verificando acceso premium: {str(e)}")
        return {"success": False, "error": "Error interno"}

def check_antispam_safe(user_input: str, ip: str = None) -> bool:
    """Sanitiza y verifica contenido anti-spam."""
    if not user_input or len(user_input) > 500:
        logger.warning("Input inválido o demasiado largo")
        return False
    
    # Sanitización básica
    sanitized = user_input.strip()
    if any(char in sanitized for char in ['<', '>', ';', '"']):
        logger.warning("Posible inyección detectada")
        return False
    
    try:
        return _original_check_antispam(sanitized)
    except Exception as e:
        logger.error(f"Error en check_antispam: {str(e)}")
        return False

def validate_cc_format_safe(cc_number: str) -> bool:
    """Valida formato de tarjeta combinando Luhn y el checker original."""
    if not cc_number:
        return False
        
    digits = cc_number.replace(' ', '').replace('-', '')
    
    if not digits.isdigit() or not (13 <= len(digits) <= 19):
        return False
    
    # Validar Luhn nativo
    if not luhn_check(digits):
        return False
        
    # Validar usando el checker original del bot (reintegrado)
    try:
        return _original_validate_cc(cc_number)
    except Exception as e:
        logger.warning(f"El validador original falló, usando resultado Luhn local: {e}")
        return True

def get_user_data_secure(user_id: str) -> Optional[Dict]:
    """Obtiene datos de usuario eliminando variables críticas con tipado seguro."""
    try:
        data = _original_get_user_data(user_id)
        # Prevención de crash: Asegurarnos de que "data" realmente es un diccionario iterativo
        if data and isinstance(data, dict):
            return {k: v for k, v in data.items() if k not in ['password', 'token', 'secret']}
        return None
    except Exception as e:
        logger.error(f"Error obteniendo datos del usuario: {str(e)}")
        return None

async def update_user_last_check_wrapper(user_id: Union[int, str]) -> bool:
    """Actualiza el timestamp del último chequeo."""
    try:
        result = await _original_update_last_check(user_id)
        return bool(result)
    except Exception as e:
        logger.error(f"Error actualizando último chequeo: {str(e)}")
        return False

__all__ = [
    "require_individual_premium_access",
    "check_antispam_safe",
    "validate_cc_format_safe",
    "get_user_data_secure",
    "update_user_last_check_wrapper",
    "luhn_check",
]