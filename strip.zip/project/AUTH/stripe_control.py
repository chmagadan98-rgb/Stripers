# stripe_control.py - Stripe auth command logic (Cleaned & Blinded)
import time
import re
import asyncio
import concurrent.futures
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from CHARGE.charge_gateways import (
    validate_cc_format,
    get_user_data_from_db,
    update_user_last_check
)
from utils.bin_api import get_bin_info
from utils.helpers import get_country_emoji
from utils.response_utils import categorize_response
import os

# Use the real Stripe Sync Checker which bypasses through WooCommerce sites
from utils.stripe_check_sync import check_stripe_card
from bot_info import LINK_ONYKAFREE, BOT_NAME

# Logging
from utils.logging_setup import get_logger
logger = get_logger(__name__)

# Thread pool for synchronous requests
stripe_thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=10)

def escape_markdown_v2(text):
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

def escape_inside_backticks(text):
    if text is None:
        return 'N/A'
    return str(text).replace('\\', '\\\\').replace('`', '\\`')

def format_bin_info(bin_number: str, bin_data: dict) -> tuple:
    if not bin_data:
        return (
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Info:* Unknown \\- Unknown",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Bank:* `Unknown`",
            f"\\[[👾]({LINK_ONYKAFREE})\\] *Country:* `Unknown`"
        )
    scheme = escape_inside_backticks(bin_data.get('Scheme', 'Unknown'))
    card_type = escape_inside_backticks(bin_data.get('Type', 'Unknown').upper())
    issuer = escape_inside_backticks(bin_data.get('Issuer', 'Unknown'))
    country_data = bin_data.get('Country', {})
    country_name = escape_inside_backticks(country_data.get('Name', 'Unknown'))
    country_code = country_data.get('A2', 'Unknown')
    country_emoji = get_country_emoji(country_code)
    
    info = f"\\[[👾]({LINK_ONYKAFREE})\\] *Info:* `{scheme}` \\- `{card_type}`"
    bank = f"\\[[👾]({LINK_ONYKAFREE})\\] *Bank:* `{issuer}`"
    country = f"\\[[👾]({LINK_ONYKAFREE})\\] *Country:* `{country_name}` {country_emoji}"
    return info, bank, country

async def run_stripe_check_async(cc_formatted: str):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(stripe_thread_pool, check_stripe_card, cc_formatted)

async def handle_st_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    user_id = update.effective_user.id
    if not context.args:
        response = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Auth \[[/st]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/st cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return

    cc_data = context.args[0].strip()
    is_valid, message, cc_parts = validate_cc_format(cc_data)
    if not is_valid:
        response = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Auth \[[/st]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/st cc|mm|yy|cvv`
━━━━━━━━━━━━
"""
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return

    user_data = get_user_data_from_db(db_config, user_id)
    username = user_data.get('username', 'N/A') if user_data else 'N/A'
    role = user_data.get('role', 'user').upper() if user_data else 'USER'
    plan = user_data.get('plan', 'FREE').upper() if user_data else 'FREE'
    
    if role not in ['OWNER', 'CO OWNER', 'DEV', 'SELLER'] and plan != 'PREMIUM' and plan != 'VIP':
        response = f"\\[[👾]({LINK_ONYKAFREE})\\] *Acceso Denegado:* Requiere plan PREMIUM o VIP\\."
        await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        return

    import random, string
    fake_req_id = 'req_' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=14))
    fake_si_id  = 'seti_' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=24))

    processing_msg = await update.message.reply_text(
        "\u23f3 `Connecting to payment network...`", parse_mode=ParseMode.MARKDOWN
    )
    await asyncio.sleep(0.9)
    await processing_msg.edit_text(
        "\u23f3 `Verifying card with issuer...`", parse_mode=ParseMode.MARKDOWN
    )
    await asyncio.sleep(0.9)
    await processing_msg.edit_text(
        f"\u23f3 `Running security authentication...`", parse_mode=ParseMode.MARKDOWN
    )
    await asyncio.sleep(0.9)

    start_time = time.time()
    cc_formatted = f"{cc_parts[0]}|{cc_parts[1]}|{cc_parts[2]}|{cc_parts[3]}"
    cc_formatted_display = f"{cc_parts[0]}|{cc_parts[1]}|{cc_parts[2][-2:]}|{cc_parts[3]}"

    try:
        status, response_msg, extra_info = await run_stripe_check_async(cc_formatted)
    except Exception as e:
        status, response_msg, extra_info = "Error", str(e), ""

    processing_time = round(time.time() - start_time, 2)

    logger.info(f"[STRIPE CHK] User={user_id} Status={status} Card={cc_parts[0][:6]}...")

    bin_number = cc_parts[0][:6]
    bin_data = await get_bin_info(bin_number)
    info_line, bank_line, country_line = format_bin_info(bin_number, bin_data)

    update_user_last_check(db_config, user_id)

    final_status, final_response, emoji = categorize_response(status, response_msg)
    status_escaped = escape_inside_backticks(f"{final_status}! {emoji}")
    repose_escaped = escape_inside_backticks(final_response)
    username_escaped = escape_markdown_v2(username)
    user_plan_display = escape_markdown_v2(f"{role}" if role in ['OWNER', 'CO OWNER', 'DEV', 'SELLER'] else plan)

    output_msg = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Auth \[[/st]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Card:* `{cc_formatted_display}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Status:* `{status_escaped}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Response:* `{repose_escaped}`
━━━━━━━━━━━━
{info_line}
{bank_line}
{country_line}
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Checked by:* @{username_escaped} » {user_plan_display}
\\[[👾]({LINK_ONYKAFREE})\\]
*Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    await processing_msg.edit_text(output_msg, parse_mode=ParseMode.MARKDOWN_V2)