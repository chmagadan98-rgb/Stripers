# paypal_auth.py – expose PayPal gateway functions for AUTH layer
# pyrefly: ignore [missing-import]
import logging
from typing import Any, Callable, Dict, Optional, Tuple
from functools import wraps

from CHARGE.paypal_gateways import (
    require_individual_premium_access,
    check_antispam,
    validate_cc_format,
    get_user_data_from_db,
    update_user_last_check,
)

# Configuración de logging
logger = logging.getLogger(__name__)

# Mapeo de funciones expuestas
__all__ = [
    "require_individual_premium_access",
    "check_antispam",
    "validate_cc_format",
    "get_user_data_from_db",
    "update_user_last_check",
    "PayPalAuthError",
    "PayPalAuthResult",
    "validate_paypal_payment",
    "get_paypal_balance",
    "process_paypal_refund",
]

# Excepciones personalizadas
class PayPalAuthError(Exception):
    """Excepción base para errores de autenticación PayPal."""
    pass

class PayPalAuthResult:
    """Clase para resultados de autenticación PayPal."""
    
    def __init__(self, success: bool, message: str, data: Optional[Dict[str, Any]] = None):
        self.success = success
        self.message = message
        self.data = data or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el resultado a diccionario."""
        return {
            'success': self.success,
            'message': self.message,
            'data': self.data
        }
    
    def __str__(self) -> str:
        return f"PayPalAuthResult(success={self.success}, message='{self.message}')"

# Decorador para logging de funciones
def log_paypal_operation(func: Callable) -> Callable:
    """Decora funciones para logging de operaciones."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        func_name = func.__name__
        try:
            logger.info(f"Iniciando operación PayPal: {func_name}")
            result = await func(*args, **kwargs)
            logger.info(f"Operación PayPal completada: {func_name}")
            return result
        except Exception as e:
            logger.error(f"Error en operación PayPal {func_name}: {str(e)}")
            raise
    return wrapper

# Funciones wrapper mejoradas
@log_paypal_operation
async def validate_paypal_payment(payment_data: Dict[str, Any]) -> PayPalAuthResult:
    """
    Valida un pago PayPal.
    
    Args:
        payment_data: Diccionario con datos del pago
        
    Returns:
        PayPalAuthResult con el resultado de la validación
    """
    try:
        # Validar estructura del pago
        required_fields = ['amount', 'currency', 'payment_method']
        missing_fields = [f for f in required_fields if f not in payment_data]
        
        if missing_fields:
            return PayPalAuthResult(
                success=False,
                message=f"Campos requeridos faltantes: {', '.join(missing_fields)}"
            )
        
        # Validar monto
        amount = payment_data.get('amount', 0)
        if not isinstance(amount, (int, float)) or amount <= 0:
            return PayPalAuthResult(
                success=False,
                message="Monto inválido"
            )
        
        # Validar moneda
        currency = payment_data.get('currency', 'USD').upper()
        valid_currencies = ['USD', 'EUR', 'GBP', 'MXN', 'CAD']
        if currency not in valid_currencies:
            return PayPalAuthResult(
                success=False,
                message=f"Moneda no soportada: {currency}"
            )
        
        # Validar tarjeta si existe
        if 'card' in payment_data:
            card_valid, card_error = validate_cc_format(payment_data['card'])
            if not card_valid:
                return PayPalAuthResult(
                    success=False,
                    message=f"Tarjeta inválida: {card_error}"
                )
        
        return PayPalAuthResult(
            success=True,
            message="Pago PayPal validado correctamente",
            data={
                'amount': amount,
                'currency': currency,
                'payment_method': payment_data.get('payment_method')
            }
        )
        
    except Exception as e:
        logger.error(f"Error validando pago PayPal: {str(e)}")
        return PayPalAuthResult(
            success=False,
            message=f"Error interno: {str(e)}"
        )

@log_paypal_operation
async def get_paypal_balance(user_id: str) -> PayPalAuthResult:
    """
    Obtiene el balance de una cuenta PayPal.
    
    Args:
        user_id: ID del usuario
        
    Returns:
        PayPalAuthResult con el balance
    """
    try:
        # Obtener datos del usuario
        user_data = await get_user_data_from_db(user_id)
        
        if not user_data:
            return PayPalAuthResult(
                success=False,
                message=f"Usuario no encontrado: {user_id}"
            )
        
        # Simular balance (en producción, conectar con API PayPal)
        balance = {
            'available': 1250.50,
            'currency': 'USD',
            'pending': 100.00
        }
        
        return PayPalAuthResult(
            success=True,
            message="Balance obtenido correctamente",
            data=balance
        )
        
    except Exception as e:
        logger.error(f"Error obteniendo balance PayPal: {str(e)}")
        return PayPalAuthResult(
            success=False,
            message=f"Error interno: {str(e)}"
        )

@log_paypal_operation
async def process_paypal_refund(transaction_id: str, amount: float, reason: str = "") -> PayPalAuthResult:
    """
    Procesa un reembolso PayPal.
    
    Args:
        transaction_id: ID de la transacción
        amount: Monto a reembolsar
        reason: Razón del reembolso
        
    Returns:
        PayPalAuthResult con el resultado del reembolso
    """
    try:
        # Validar parámetros
        if not transaction_id:
            return PayPalAuthResult(
                success=False,
                message="ID de transacción requerido"
            )
        
        if not isinstance(amount, (int, float)) or amount <= 0:
            return PayPalAuthResult(
                success=False,
                message="Monto inválido para reembolso"
            )
        
        # Verificar permisos premium
        has_access = await require_individual_premium_access(user_id="admin")
        if not has_access:
            return PayPalAuthResult(
                success=False,
                message="Acceso premium requerido para reembolsos"
            )
        
        # Simular procesamiento de reembolso
        refund_data = {
            'transaction_id': transaction_id,
            'refund_id': f"RF{transaction_id[-6:]}",
            'amount': amount,
            'status': 'COMPLETED',
            'reason': reason or 'Customer request'
        }
        
        return PayPalAuthResult(
            success=True,
            message="Reembolso procesado correctamente",
            data=refund_data
        )
        
    except Exception as e:
        logger.error(f"Error procesando reembolso PayPal: {str(e)}")
        return PayPalAuthResult(
            success=False,
            message=f"Error interno: {str(e)}"
        )

# Mantener compatibilidad con funciones originales
async def require_individual_premium_access_wrapper(*args, **kwargs):
    """Wrapper para require_individual_premium_access con logging."""
    try:
        result = await require_individual_premium_access(*args, **kwargs)
        logger.info(f"Premium access check: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en premium access check: {str(e)}")
        raise

async def check_antispam_wrapper(*args, **kwargs):
    """Wrapper para check_antispam con logging."""
    try:
        result = await check_antispam(*args, **kwargs)
        logger.info(f"Antispam check: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en antispam check: {str(e)}")
        raise

# Re-exportar funciones con wrappers
require_individual_premium_access = require_individual_premium_access_wrapper
check_antispam = check_antispam_wrapper