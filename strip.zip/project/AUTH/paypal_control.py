# paypal_auth_control.py - Corregido y Blindado
import asyncio
import random
import time
import logging
import re
import threading
from typing import Optional, Tuple, Dict, Any
from functools import wraps
from collections import defaultdict
import aiohttp
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from utils.logging_setup import get_logger
from utils.bin_api import get_bin_info

logger = get_logger(__name__)

# Constantes
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos
PAYPAL_AMOUNT = "0.50"  # $0.50 USD

# ============================================
# 1. MEJORA: Rate limiter thread-safe
# ============================================
class RateLimiter:
    """Rate limiter thread-safe."""
    
    def __init__(self, max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
        self.max_attempts = max_attempts
        self.window = window
        self.attempts = defaultdict(list)
        self.lock = threading.Lock()
    
    def check_and_add(self, user_id: int) -> Tuple[bool, int]:
        """Verifica y registra intento."""
        with self.lock:
            now = time.time()
            self.attempts[user_id] = [
                t for t in self.attempts[user_id] 
                if now - t < self.window
            ]
            
            if len(self.attempts[user_id]) >= self.max_attempts:
                wait_time = int(self.window - (now - self.attempts[user_id][0]))
                return False, wait_time
            
            self.attempts[user_id].append(now)
            return True, 0

# Instancia global
rate_limiter = RateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2