# AUTH/stripe_premium.py – Cleaned & Blinded
"""Thin wrapper to expose the Stripe card checker to the AUTH package.

This module provides a robust interface to the Stripe card checker,
allowing existing imports like `from AUTH.stripe_premium import check_stripe_card`
to work with the new Python implementation located in utils.stripe_checker.
"""

import logging
import asyncio
from typing import Any, Optional, Tuple, Dict, Union, Callable
from functools import wraps

# Configurar logging
logger = logging.getLogger(__name__)

# ============================================
# 1. MEJORA: Importación segura con verificación
# ============================================
try:
    from utils.stripe_checker import check_stripe_card as _original_check_stripe_card
    
    # Verificar que sea una función llamable
    if not callable(_original_check_stripe_card):
        raise ImportError("check_stripe_card no es una función llamable")
    
    _IMPORT_SUCCESS = True
    logger.info("Importación exitosa de utils.stripe_checker.check_stripe_card")
    
except ImportError as e:
    logger.error(f"Error importando utils.stripe_checker: {str(e)}")
    _IMPORT_SUCCESS = False
    _original_check_stripe_card = None
    
except Exception as e:
    logger.critical(f"Error inesperado importando stripe_checker: {str(e)}")
    _IMPORT_SUCCESS = False
    _original_check_stripe_card = None

# ============================================
# 2. MEJORA: Función de verificación de importación
# ============================================
def verify_import() -> bool:
    """
    Verifica si la importación de check_stripe_card fue exitosa.
    
    Returns:
        bool: True si la función está disponible y es llamable
    """
    return _IMPORT_SUCCESS and callable(_original_check_stripe_card)

# ============================================
# 3. MEJORA: Wrapper con manejo de errores y logging
# ============================================
async def check_stripe_card(
    cc_number: str,
    exp_month: Optional[str] = None,
    exp_year: Optional[str] = None,
    cvv: Optional[str] = None,
    *args: Any,
    **kwargs: Any
) -> Tuple[str, str, Optional[str]]:
    """
    Verifica una tarjeta de crédito usando el checker de Stripe.
    
    Args:
        cc_number: Número de tarjeta de crédito (formato: "4111111111111111" o "4111111111111111|12|25|123")
        exp_month: Mes de expiración (opcional si se proporciona en cc_number)
        exp_year: Año de expiración (opcional si se proporciona en cc_number)
        cvv: Código de seguridad (opcional si se proporciona en cc_number)
        *args: Argumentos adicionales para la función original
        **kwargs: Keyword arguments adicionales para la función original
    
    Returns:
        Tuple[str, str, Optional[str]]: (status, response, extra_info)
            - status: "Approved", "Declined", "Error", etc.
            - response: Mensaje de respuesta
            - extra_info: Información adicional o None
    
    Raises:
        ImportError: Si la función original no está disponible
        ValueError: Si los datos de la tarjeta son inválidos
    """
    
    # Verificar que la función original esté disponible
    if not verify_import():
        logger.error("check_stripe_card no está disponible")
        raise ImportError("check_stripe_card no está disponible. Verifica la instalación de utils.stripe_checker")
    
    # Preparar datos de entrada
    try:
        # Si se proporciona el formato completo en cc_number
        if '|' in cc_number:
            parts = cc_number.split('|')
            if len(parts) >= 1:
                cc_number = parts[0]
            if len(parts) >= 3:
                exp_month = exp_month or parts[1]
                exp_year = exp_year or parts[2]
            if len(parts) >= 4:
                cvv = cvv or parts[3]
        
        # Validar datos mínimos
        if not cc_number:
            raise ValueError("Número de tarjeta requerido")
        
        if not exp_month or not exp_year:
            # Si no hay fecha, intentar extraer del número completo
            if '|' in cc_number:
                parts = cc_number.split('|')
                if len(parts) >= 3:
                    exp_month = parts[1]
                    exp_year = parts[2]
                if len(parts) >= 4:
                    cvv = parts[3]
        
        # Formatear entrada para la función original
        if exp_month and exp_year and cvv:
            formatted_input = f"{cc_number}|{exp_month}|{exp_year}|{cvv}"
        else:
            formatted_input = cc_number
        
        logger.debug(f"Llamando a check_stripe_card con tarjeta: {cc_number[:6]}...{cc_number[-4:]}")
        
        # Llamar a la función original
        result = await _original_check_stripe_card(formatted_input, *args, **kwargs)
        
        # Procesar resultado
        if isinstance(result, tuple):
            if len(result) == 2:
                status, response = result
                extra_info = None
            elif len(result) >= 3:
                status, response, extra_info = result[:3]
            else:
                status, response = result[0], "Unknown response"
                extra_info = None
        else:
            # Si no es tuple, asumir que es el status
            status = str(result)
            response = "Unknown response"
            extra_info = None
        
        logger.info(f"Resultado check_stripe_card: Status={status}, Card={cc_number[:6]}...")
        
        return status, response, extra_info
        
    except ValueError as e:
        logger.error(f"Error de validación: {str(e)}")
        return "Error", str(e), None
        
    except Exception as e:
        logger.error(f"Error en check_stripe_card: {str(e)}")
        return "Error", str(e), None

# ============================================
# 4. MEJORA: Función síncrona wrapper
# ============================================
def check_stripe_card_sync(
    cc_number: str,
    exp_month: Optional[str] = None,
    exp_year: Optional[str] = None,
    cvv: Optional[str] = None,
    *args: Any,
    **kwargs: Any
) -> Tuple[str, str, Optional[str]]:
    """
    Versión síncrona de check_stripe_card para uso en contextos no async.
    
    Args:
        cc_number: Número de tarjeta de crédito
        exp_month: Mes de expiración (opcional)
        exp_year: Año de expiración (opcional)
        cvv: Código de seguridad (opcional)
        *args: Argumentos adicionales
        **kwargs: Keyword arguments adicionales
    
    Returns:
        Tuple[str, str, Optional[str]]: (status, response, extra_info)
    
    Raises:
        ImportError: Si la función original no está disponible
    """
    try:
        # Crear y ejecutar el coroutine
        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(
                check_stripe_card(cc_number, exp_month, exp_year, cvv, *args, **kwargs)
            )
            return result
        finally:
            loop.close()
    except Exception as e:
        logger.error(f"Error en check_stripe_card_sync: {str(e)}")
        return "Error", str(e), None

# ============================================
# 5. MEJORA: Función de diagnóstico
# ============================================
def diagnose() -> Dict[str, Any]:
    """
    Diagnostica el estado del módulo y la función importada.
    
    Returns:
        Dict con información de diagnóstico
    """
    info = {
        "import_success": _IMPORT_SUCCESS,
        "function_available": callable(_original_check_stripe_card),
        "function_name": getattr(_original_check_stripe_card, "__name__", "Unknown"),
        "function_module": getattr(_original_check_stripe_card, "__module__", "Unknown"),
        "is_async": asyncio.iscoroutinefunction(_original_check_stripe_card) if _original_check_stripe_card else False,
    }
    
    # Intentar obtener firma de la función
    try:
        import inspect
        if _original_check_stripe_card:
            info["signature"] = str(inspect.signature(_original_check_stripe_card))
    except Exception as e:
        info["signature_error"] = str(e)
    
    return info

# ============================================
# 6. MEJORA: Decorador para logging de llamadas
# ============================================
def log_check(func: Callable) -> Callable:
    """
    Decorador para logging detallado de llamadas a check_stripe_card.
    """
    @wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Extraer información de la tarjeta para logging (sin datos sensibles)
        card_info = "Unknown"
        if args:
            first_arg = str(args[0])
            if '|' in first_arg:
                parts = first_arg.split('|')
                if parts:
                    card_info = f"{parts[0][:6]}...{parts[0][-4:]}" if len(parts[0]) > 10 else parts[0]
            else:
                card_info = f"{first_arg[:6]}...{first_arg[-4:]}" if len(first_arg) > 10 else first_arg
        
        start_time = __import__('time').time()
        logger.info(f"Iniciando check_stripe_card: Card={card_info}")
        
        try:
            result = await func(*args, **kwargs)
            elapsed = round(__import__('time').time() - start_time, 2)
            
            if isinstance(result, tuple):
                status = result[0] if result else "Unknown"
                logger.info(f"check_stripe_card completado: Status={status}, Time={elapsed}s")
            else:
                logger.info(f"check_stripe_card completado: Result={result}, Time={elapsed}s")
            
            return result
        except Exception as e:
            elapsed = round(__import__('time').time() - start_time, 2)
            logger.error(f"check_stripe_card falló: {str(e)}, Time={elapsed}s")
            raise
    
    return wrapper

# ============================================
# 7. MEJORA: Aplicar decorador al wrapper principal
# ============================================
check_stripe_card = log_check(check_stripe_card)

# ============================================
# 8. MEJORA: Función de inicialización
# ============================================
def init_stripe_premium() -> bool:
    """
    Inicializa el módulo stripe_premium.
    
    Returns:
        bool: True si la inicialización fue exitosa
    """
    logger.info("Inicializando AUTH.stripe_premium...")
    
    if verify_import():
        logger.info("AUTH.stripe_premium inicializado correctamente")
        return True
    else:
        logger.error("AUTH.stripe_premium no se pudo inicializar correctamente")
        return False

# ============================================
# 9. MEJORA: Función de limpieza
# ============================================
def cleanup() -> None:
    """
    Limpia recursos del módulo.
    """
    logger.info("Limpiando recursos de AUTH.stripe_premium...")
    logger.info("Limpieza completada")

# ============================================
# 10. MEJORA: Exportaciones
# ============================================
__all__ = [
    "check_stripe_card",
    "check_stripe_card_sync",
    "verify_import",
    "diagnose",
    "init_stripe_premium",
    "cleanup",
    "log_check"
]

# ============================================
# 11. MEJORA: Inicialización automática
# ============================================
if __name__ != "__main__":
    _diag = diagnose()
    if _diag["function_available"]:
        logger.info(f"Módulo AUTH.stripe_premium cargado. Función: {_diag['function_name']} de {_diag['function_module']}")
    else:
        logger.warning("Módulo AUTH.stripe_premium cargado sin función check_stripe_card disponible")