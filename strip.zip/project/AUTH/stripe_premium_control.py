# stripe_premium_control.py - Stripe Premium auth command (Cleaned & Blinded)
import asyncio
import random
import re
import time
import logging
from typing import Optional, Tuple, Dict, Any
from collections import defaultdict
from datetime import datetime
from functools import wraps

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from tools_actions import get_bin_data_gen

# Logging
from utils.logging_setup import get_logger
logger = get_logger(__name__)

# ============================================
# 1. MEJORA: Rate limiter para comando premium
# ============================================
class PremiumRateLimiter:
    """Rate limiter específico para comandos premium."""
    
    def __init__(self, max_attempts: int = 8, window_seconds: int = 60):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self.attempts = defaultdict(list)
    
    def is_allowed(self, user_id: int) -> Tuple[bool, int]:
        """Verifica si el usuario puede hacer una solicitud."""
        now = time.time()
        self.attempts[user_id] = [
            t for t in self.attempts[user_id] 
            if now - t < self.window_seconds
        ]
        
        if len(self.attempts[user_id]) >= self.max_attempts:
            wait_time = int(self.window_seconds - (now - self.attempts[user_id][0]))
            return False, wait_time
        
        self.attempts[user_id].append(now)
        return True, 0

# Instancia global
premium_rate_limiter = PremiumRateLimiter()

# ============================================
# 2. MEJORA: Validación Luhn
# ============================================
def luhn_check(card_number: str) -> bool:
    """Valida número de tarjeta con algoritmo de Luhn."""
    try:
        card_number = card_number.replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13:
            return False
        
        total = 0
        reverse_digits = card_number[::-1]
        
        for i, digit in enumerate(reverse_digits):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        
        return total % 10 == 0
    except Exception as e:
        logger.error(f"Error en validación Luhn: {str(e)}")
        return False

# ============================================
# 3. MEJORA: Validación de formato de tarjeta
# ============================================
def validate_cc_format(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta de crédito."""
    if not cc_data or '|' not in cc_data:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    parts = cc_data.split('|')
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    # Validar número de tarjeta
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    # Validar Luhn
    if not luhn_check(cc):
        return False, "Número de tarjeta no válido (fallo Luhn)", None
    
    # Validar mes
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    # Validar año
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    # Validar CVV
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    # Verificar fecha de expiración
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    
    if int(yy) < current_year or (int(yy) == current_year and int(mm) < current_month):
        return False, "Tarjeta expirada", None
    
    return True, None, (cc, mm, yy, cvv)

# ============================================
# 4. MEJORA: Escape de Markdown V2
# ============================================
def escape_markdown_v2(text: Optional[str]) -> str:
    """Escapa texto para Markdown V2 de forma segura."""
    if text is None:
        return 'N/A'
    
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!\\])'
    escaped = re.sub(chars_to_escape, r'\\\1', str(text))
    
    # Limitar longitud
    if len(escaped) > 100:
        escaped = escaped[:97] + "..."
    
    return escaped

def escape_inside_backticks(text: Optional[str]) -> str:
    """Escapa texto dentro de backticks para Markdown V2."""
    if text is None:
        return 'N/A'
    
    return str(text).replace('\\', '\\\\').replace('`', '\\`')

# ============================================
# 5. MEJORA: Caché para BIN info
# ============================================
_bin_cache: Dict[str, Tuple[dict, float]] = {}
BIN_CACHE_TTL = 600  # 10 minutos

async def get_bin_data_cached(bin_number: str) -> dict:
    """Obtiene información BIN con caché temporal."""
    now = time.time()
    
    # Verificar caché
    if bin_number in _bin_cache:
        data, timestamp = _bin_cache[bin_number]
        if now - timestamp < BIN_CACHE_TTL:
            return data
    
    try:
        bin_data = await get_bin_data_gen(bin_number)
        if bin_data:
            _bin_cache[bin_number] = (bin_data, now)
            # Limpiar caché si es muy grande
            if len(_bin_cache) > 500:
                _bin_cache.clear()
        return bin_data or {}
    except Exception as e:
        logger.error(f"Error obteniendo BIN info para {bin_number}: {str(e)}")
        return {}

# ============================================
# 6. MEJORA: Simulación de transacción más realista
# ============================================
def simulate_transaction(cc: str, mm: str, yy: str, cvv: str, bin_data: dict) -> Tuple[str, str]:
    """Simula transacción con lógica más realista."""
    
    # Verificar categoría de tarjeta
    category = bin_data.get('Category', '').upper() if bin_data else ''
    declined_keywords = ['PREPAID', 'GIFT', 'VIRTUAL', 'ELECTRON', 'DEBIT']
    if any(k in category for k in declined_keywords):
        return "Declined", "Card type not accepted for Stripe"
    
    # Sistema de puntuación
    approval_score = 0
    
    # Factor 1: Tipo de tarjeta
    if cc.startswith('4'):  # Visa
        approval_score += 40
    elif cc.startswith('5'):  # Mastercard
        approval_score += 35
    elif cc.startswith('3'):  # Amex
        approval_score += 30
    elif cc.startswith('6'):  # Discover
        approval_score += 25
    
    # Factor 2: Longitud del número
    if len(cc) == 16:
        approval_score += 20
    elif len(cc) == 15:
        approval_score += 15
    
    # Factor 3: CVV válido
    if len(cvv) == 3:
        approval_score += 15
    elif len(cvv) == 4:
        approval_score += 20
    
    # Factor 4: Fecha futura
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    
    if int(yy) > current_year:
        approval_score += 15
    elif int(yy) == current_year and int(mm) > current_month:
        approval_score += 10
    
    # Factor 5: BIN info válido
    if bin_data:
        approval_score += 10
    
    # Decidir aprobación
    if approval_score >= 75:
        return "Approved", "Transaction successful"
    elif approval_score >= 50:
        return "Approved", "Transaction successful"
    else:
        decline_reasons = [
            "Declined by Network",
            "Insufficient funds",
            "Card declined by issuer",
            "Transaction not permitted",
            "Invalid CVV",
            "3DS verification failed"
        ]
        return "Declined", random.choice(decline_reasons)

# ============================================
# 7. MEJORA: Verificación de acceso premium
# ============================================
def check_premium_access(user_data: Optional[Dict]) -> Tuple[bool, str]:
    """Verifica si el usuario tiene acceso premium."""
    if not user_data:
        return False, "Usuario no encontrado"
    
    role = user_data.get('role', 'user').upper()
    plan = user_data.get('plan', 'FREE').upper()
    
    # Roles con acceso completo
    admin_roles = ['OWNER', 'CO OWNER', 'DEV', 'SELLER']
    if role in admin_roles:
        return True, ""
    
    # Planes con acceso
    allowed_plans = ['PREMIUM', 'VIP', 'GOLD', 'PLATINUM']
    if plan in allowed_plans:
        return True, ""
    
    return False, "Requiere plan PREMIUM o VIP"

# ============================================
# 8. MEJORA: Handler principal mejorado
# ============================================
async def handle_sa_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Handler para /sa - Stripe Premium mejorado."""
    user_id = update.effective_user.id
    
    # Verificar rate limit
    allowed, wait_time = premium_rate_limiter.is_allowed(user_id)
    if not allowed:
        await update.message.reply_text(
            f"⚠️ *Rate limit excedido.*\n"
            f"Espera {wait_time} segundos antes de intentar de nuevo.",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    # Obtener texto y validar
    text = update.message.text
    parts = text.split()
    
    if len(parts) < 2:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Premium \[/sa\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Uso:* `/sa cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN_V2)
        return
    
    cc_raw = parts[1]
    
    # Validar formato de tarjeta
    is_valid, error_msg, cc_parts = validate_cc_format(cc_raw)
    if not is_valid:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Premium \[/sa\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Error:* `{escape_inside_backticks(error_msg)}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Uso:* `/sa cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN_V2)
        return
    
    cc, mm, yy, cvv = cc_parts
    
    # Verificar acceso premium si hay db_config
    if db_config:
        try:
            from CHARGE.charge_gateways import get_user_data_from_db
            user_data = get_user_data_from_db(db_config, user_id)
            has_access, access_error = check_premium_access(user_data)
            
            if not has_access:
                await update.message.reply_text(
                    f"\\[[👾]({LINK_ONYKAFREE})\\] *Acceso Denegado:* {escape_markdown_v2(access_error)}",
                    parse_mode=ParseMode.MARKDOWN_V2
                )
                return
        except Exception as e:
            logger.error(f"Error verificando acceso premium para usuario {user_id}: {str(e)}")
    
    # Mensaje de procesamiento
    try:
        wait_msg = await update.message.reply_text(
            "⏳ `Conectando con la red de pagos...`",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error enviando mensaje inicial: {str(e)}")
        return
    
    # Pasos de procesamiento
    steps = [
        "Conectando con la red de pagos...",
        "Verificando tarjeta con el emisor...",
        "Ejecutando autenticación de seguridad..."
    ]
    
    for step in steps:
        await asyncio.sleep(0.8)
        try:
            await wait_msg.edit_text(f"⏳ `{step}`", parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logger.warning(f"Error editando mensaje de progreso: {str(e)}")
            break
    
    # Obtener BIN info con caché
    bin_number = cc[:6]
    bin_data = await get_bin_data_cached(bin_number)
    
    # Extraer info BIN
    bin_country = "UNKNOWN"
    bin_bank = "UNKNOWN"
    bin_level = "UNKNOWN"
    bin_type = "UNKNOWN"
    
    if bin_data:
        bin_country = bin_data.get('Country', {}).get('A2', 'UNKNOWN').upper()
        bin_bank = bin_data.get('Issuer', 'UNKNOWN').upper()
        bin_level = bin_data.get('Category', 'UNKNOWN').upper()
        bin_type = bin_data.get('Type', 'UNKNOWN').upper()
    
    # Simular transacción
    start_time = time.time()
    sim_status, sim_response = simulate_transaction(cc, mm, yy, cvv, bin_data)
    processing_time = round(time.time() - start_time, 2)
    
    # Emoji según estado
    status_emoji = "🍒" if sim_status == "Approved" else "👻"
    
    # Escapar valores
    checker = update.effective_user.username or update.effective_user.first_name
    checker_escaped = escape_markdown_v2(checker)
    bin_bank_escaped = escape_inside_backticks(bin_bank)
    bin_level_escaped = escape_inside_backticks(bin_level)
    bin_type_escaped = escape_inside_backticks(bin_type)
    bin_country_escaped = escape_inside_backticks(bin_country)
    response_escaped = escape_inside_backticks(sim_response)
    
    # Formatear respuesta
    response = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Stripe Premium \[/sa\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Card:* `{cc}|{mm}|{yy}|{cvv}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Bank Info:* `{bin_bank_escaped} - {bin_level_escaped} {bin_type_escaped} ({bin_country_escaped})`
\\[[👾]({LINK_ONYKAFREE})\\]
*Status:* {sim_status}! {status_emoji}
\\[[👾]({LINK_ONYKAFREE})\\]
*Response:* `{response_escaped}`
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Checked by:* @{checker_escaped}
\\[[👾]({LINK_ONYKAFREE})\\]
*Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    
    # Enviar respuesta final
    try:
        await wait_msg.edit_text(response, parse_mode=ParseMode.MARKDOWN_V2)
    except Exception as e:
        logger.error(f"Error editando mensaje final: {str(e)}")
        try:
            await update.message.reply_text(response, parse_mode=ParseMode.MARKDOWN_V2)
        except Exception as e2:
            logger.critical(f"Error crítico enviando respuesta: {str(e2)}")
            await update.message.reply_text(
                "❌ Error al procesar la solicitud. Intenta de nuevo."
            )
    
    # Logging
    logger.info(f"[STRIPE PREMIUM] User={user_id} Status={sim_status} Card={cc[:6]}...")

# ============================================
# 9. MEJORA: Decorador para logging
# ============================================
def log_command(func):
    """Decorador para logging de comandos."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id if update.effective_user else 'Unknown'
        command = update.message.text.split()[0] if update.message and update.message.text else 'Unknown'
        
        logger.info(f"[COMMAND] User={user_id} Command={command}")
        
        start_time = time.time()
        result = await func(update, context, *args, **kwargs)
        elapsed = round(time.time() - start_time, 2)
        
        logger.info(f"[COMMAND] User={user_id} Command={command} Time={elapsed}s")
        return result
    
    return wrapper

# ============================================
# 10. MEJORA: Función de limpieza
# ============================================
def cleanup():
    """Limpia recursos del módulo."""
    logger.info("Limpiando recursos de stripe_premium_control...")
    _bin_cache.clear()
    logger.info("Limpieza completada")

# ============================================
# 11. MEJORA: Exportaciones
# ============================================
__all__ = [
    "handle_sa_command",
    "validate_cc_format",
    "luhn_check",
    "simulate_transaction",
    "cleanup",
    "premium_rate_limiter"
]