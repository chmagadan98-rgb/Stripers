# braintree_auth_control.py - Braintree auth command (Cleaned & Blinded)
import asyncio
import random
import string
import time
import logging
import re
from typing import Optional, Tuple, Dict, Any
from functools import wraps
import aiohttp
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from utils.logging_setup import get_logger
from utils import proxy_rotator
from utils.bin_api import get_bin_info

logger = get_logger(__name__)

# Constantes
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos
BRAINTREE_AMOUNT = "0.10"  # $0.10 USD

# Decorador para rate limiting
def rate_limit(max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
    """Limita intentos por usuario."""
    attempts = {}
    
    def decorator(func):
        @wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = update.effective_user.id
            now = time.time()
            
            # Limpiar intentos antiguos
            if user_id in attempts:
                attempts[user_id] = [t for t in attempts[user_id] if now - t < window]
            else:
                attempts[user_id] = []
            
            # Verificar límite
            if len(attempts[user_id]) >= max_attempts:
                wait_time = int(window - (now - attempts[user_id][0]))
                await update.message.reply_text(
                    f"⚠️ Rate limit excedido. Espera {wait_time} segundos.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            attempts[user_id].append(now)
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator

def validate_card_format(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta de crédito."""
    if not cc_data or len(cc_data) > 19 + 15:
        return False, "Formato inválido", None
    
    parts = cc_data.replace('|', ' ').split()
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    return True, None, (cc, mm, yy, cvv)

def escape_markdown(text: Optional[str]) -> str:
    """Escapa texto para Markdown de forma segura."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

async def get_bin_data(bin_number: str) -> dict:
    """Fetch BIN info de HandyAPI con manejo de errores."""
    try:
        bin_data = await get_bin_info(bin_number)
        return bin_data or {}
    except Exception as e:
        logger.error(f"Error obteniendo BIN info para {bin_number}: {str(e)}")
        return {}

def get_flag(code: str) -> str:
    """Obtiene emoji de bandera para código de país."""
    try:
        if not code or len(code) != 2:
            return ''
        return ''.join(chr(ord(c) + 127397) for c in code.upper())
    except Exception:
        return ''

def generate_braintree_ids() -> Dict[str, str]:
    """Genera IDs realistas de Braintree."""
    client_token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
    
    # Generar UUID válido
    nonce_id = '-'.join([
        ''.join(random.choices(string.hexdigits.lower(), k=8)),
        ''.join(random.choices(string.hexdigits.lower(), k=4)),
        '4' + ''.join(random.choices(string.hexdigits.lower(), k=3)),  # UUID v4
        random.choice(['8', '9', 'a', 'b']) + ''.join(random.choices(string.hexdigits.lower(), k=3)),
        ''.join(random.choices(string.hexdigits.lower(), k=12))
    ])
    
    txn_id = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    
    return {
        'client_token': client_token,
        'nonce_id': nonce_id,
        'txn_id': txn_id
    }

def determine_card_status(bin_data: Dict[str, Any], cc_last_digit: str) -> Tuple[str, str]:
    """Determina estado de la tarjeta basado en datos BIN."""
    scheme = bin_data.get('Scheme', 'UNKNOWN').upper()
    category = bin_data.get('Category', 'UNKNOWN').upper()
    card_type = bin_data.get('Type', 'UNKNOWN').upper()
    
    # Palabras clave para declinación
    declined_keywords = ['PREPAID', 'VIRTUAL', 'GIFT']
    approved_schemes = ['VISA', 'MASTERCARD', 'AMERICAN EXPRESS']
    
    if any(k in category for k in declined_keywords):
        return 'Declined', 'Payment method type not accepted'
    elif scheme in approved_schemes:
        # Simular respuesta basada en último dígito
        if int(cc_last_digit) % 2 == 0:
            return 'Approved', 'Authorized (3DS frictionless)'
        else:
            return 'Declined', 'Processor Declined: 2001'
    else:
        # Para otros esquemas, decisión aleatoria
        if random.random() > 0.3:
            return 'Approved', 'Authorized (3DS frictionless)'
        else:
            return 'Declined', 'Processor Declined: 2001'

@rate_limit()
async def handle_br_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Handler para /br - Braintree Auth Gate mejorado."""
    text = update.message.text.strip()
    parts = text.split()
    cc_raw = parts[1] if len(parts) > 1 else None
    
    if not cc_raw or '|' not in cc_raw:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Braintree Auth \[/br\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/br cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN)
        return
    
    # Validar formato
    is_valid, error_msg, cc_data = validate_card_format(cc_raw)
    if not is_valid:
        await update.message.reply_text(
            f"👻 *Error:* `{escape_markdown(error_msg)}`\n"
            f"👻 *Use:* `/br cc|mm|yy|cvv`",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    cc, mm, yy, cvv = cc_data
    bin_number = cc[:6]
    
    # Generar IDs realistas de Braintree
    braintree_ids = generate_braintree_ids()
    client_token = braintree_ids['client_token']
    nonce_id = braintree_ids['nonce_id']
    txn_id = braintree_ids['txn_id']
    
    # Iniciar mensaje de procesamiento
    wait_msg = await update.message.reply_text(
        f"⏳ `[+] POST /merchants/{{id}}/client_token`",
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Pasos de procesamiento con logs realistas
    processing_steps = [
        f"⏳ `[+] POST /merchants/{{id}}/client_token`",
        f"⏳ `[+] POST /merchants/{{id}}/transactions (3D Secure)`",
        f"⏳ `[+] GET /merchants/{{id}}/transactions/{txn_id}`",
        f"⏳ `[+] Verifying payment method nonce: {nonce_id[:8]}...`",
        f"⏳ `[+] Charging $0.10 USD to card ending in {cc[-4:]}`"
    ]
    
    for step in processing_steps:
        await asyncio.sleep(0.8)
        try:
            await wait_msg.edit_text(step, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logger.warning(f"Error editando mensaje: {str(e)}")
    
    # Obtener datos BIN en paralelo
    bin_task = asyncio.create_task(get_bin_data(bin_number))
    await asyncio.sleep(0.5)
    
    # Procesar transacción
    start_time = time.time()
    bin_data = await bin_task
    
    # Extraer info BIN
    scheme = bin_data.get('Scheme', 'UNKNOWN').upper()
    card_type = bin_data.get('Type', 'UNKNOWN').upper()
    issuer = bin_data.get('Issuer', 'UNKNOWN').upper()
    category = bin_data.get('Category', 'UNKNOWN').upper()
    country = bin_data.get('Country', {})
    country_a2 = country.get('A2', 'XX')
    country_nm = country.get('Name', 'Unknown').upper()
    flag = get_flag(country_a2)
    
    # Determinar estado
    status, response_msg = determine_card_status(bin_data, cc[-1])
    
    # Si no hay datos BIN, simular
    if not bin_data:
        status = random.choice(['Approved', 'Declined'])
        response_msg = 'Authorized (3DS frictionless)' if status == 'Approved' else 'Processor Declined: 2001'
    
    processing_time = round(time.time() - start_time, 2)
    
    # Formatear respuesta
    emoji = '🍒' if status == 'Approved' else '👻'
    checker = update.effective_user.username or update.effective_user.first_name
    checker_escaped = escape_markdown(checker)
    
    result = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Braintree Auth \[/br\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Card:* `{cc}|{mm}|{yy}|{cvv}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Status:* {status}! {emoji}
\\[[👾]({LINK_ONYKAFREE})\\]
*Response:* `{response_msg}`
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*BIN:* `{bin_number}` | `{scheme} {card_type} {category}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Bank:* `{issuer}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Country:* `{country_nm}` {flag}
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Checked by:* @{checker_escaped}
\\[[👾]({LINK_ONYKAFREE})\\]
*Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    await wait_msg.edit_text(result, parse_mode=ParseMode.MARKDOWN)