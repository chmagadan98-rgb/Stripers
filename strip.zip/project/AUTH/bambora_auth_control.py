# bambora_auth_control.py - Bambora auth command (Improved & Cleaned)
import asyncio
import time
import logging
import re
from typing import Optional, Tuple, Dict, Any
from functools import wraps
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from utils.bambora_client import BamboraClient, BamboraAPIError
from tools_actions import get_bin_data_gen

# Configuración de logging
logger = logging.getLogger(__name__)

# Constantes
RATE_LIMIT_ATTEMPTS = 5
RATE_LIMIT_WINDOW = 60  # segundos
BAMBORA_AMOUNT = "0.10"  # $0.10 USD

# Decorador para rate limiting
def rate_limit(max_attempts: int = RATE_LIMIT_ATTEMPTS, window: int = RATE_LIMIT_WINDOW):
    """Limita intentos por usuario."""
    attempts = {}
    
    def decorator(func):
        @wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = update.effective_user.id
            now = time.time()
            
            # Limpiar intentos antiguos
            if user_id in attempts:
                attempts[user_id] = [t for t in attempts[user_id] if now - t < window]
            else:
                attempts[user_id] = []
            
            # Verificar límite
            if len(attempts[user_id]) >= max_attempts:
                wait_time = int(window - (now - attempts[user_id][0]))
                await update.message.reply_text(
                    f"⚠️ Rate limit excedido. Espera {wait_time} segundos.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            attempts[user_id].append(now)
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator

def validate_card_format(cc_data: str) -> Tuple[bool, Optional[str], Optional[Tuple[str, str, str, str]]]:
    """Valida formato de tarjeta de crédito."""
    if not cc_data or len(cc_data) > 19 + 15:
        return False, "Formato inválido", None
    
    parts = cc_data.replace('|', ' ').split()
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", None
    
    cc, mm, yy, cvv = parts
    
    if not cc.isdigit() or not (13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", None
    
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return False, "Mes inválido", None
    
    if not yy.isdigit() or len(yy) != 2:
        return False, "Año inválido", None
    
    if not cvv.isdigit() or not (3 <= len(cvv) <= 4):
        return False, "CVV inválido", None
    
    return True, None, (cc, mm, yy, cvv)

def escape_markdown(text: Optional[str]) -> str:
    """Escapa texto para Markdown de forma segura."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))

async def get_bin_info(bin_number: str) -> Dict[str, Any]:
    """Obtiene información BIN con manejo de errores."""
    try:
        bin_data = await get_bin_data_gen(bin_number)
        if bin_data:
            return {
                'country': bin_data.get('Country', {}).get('A2', 'UNKNOWN').upper(),
                'bank': bin_data.get('Issuer', 'UNKNOWN').upper(),
                'level': bin_data.get('Category', 'UNKNOWN').upper(),
                'type': bin_data.get('Type', 'UNKNOWN').upper()
            }
    except Exception as e:
        logger.error(f"Error obteniendo BIN info: {str(e)}")
    
    return {
        'country': 'UNKNOWN',
        'bank': 'UNKNOWN',
        'level': 'UNKNOWN',
        'type': 'UNKNOWN'
    }

async def process_bambora_transaction(cc: str, mm: str, yy: str, cvv: str) -> Tuple[str, str]:
    """Procesa transacción Bambora con manejo robusto de errores."""
    loop = asyncio.get_event_loop()
    
    try:
        bambora_client = BamboraClient()
        # Ejecutar llamada API síncrona en thread pool
        result = await loop.run_in_executor(
            None,
            bambora_client.authorize_card,
            BAMBORA_AMOUNT,
            cc, mm, yy, cvv
        )
        
        if result and result.get('success'):
            return "Approved", result.get('message', 'Transaction successful')
        else:
            error_msg = result.get('message', 'Declined by Network') if result else 'No response from gateway'
            return "Declined", error_msg
            
    except BamboraAPIError as e:
        logger.error(f"Bambora API error: {str(e)}")
        return "Error", f"Bambora API Error: {str(e)}"
    except asyncio.TimeoutError:
        logger.error("Bambora API timeout")
        return "Error", "Bambora API Timeout"
    except Exception as e:
        logger.error(f"Unexpected error en Bambora: {str(e)}")
        return "Error", f"Unexpected Error: {str(e)}"

@rate_limit()
async def handle_bm_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict = None):
    """Maneja el comando /bm con integración Bambora."""
    text = update.message.text
    cc_parts = text.split()[1] if len(text.split()) > 1 else None
    
    if not cc_parts:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Bambora Auth \[[/bm]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/bm cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN)
        return
    
    # Validar formato de tarjeta
    is_valid, error_msg, cc_data = validate_card_format(cc_parts)
    if not is_valid:
        await update.message.reply_text(f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Bambora Auth \[[/bm]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Error:* `{error_msg}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Use:* `/bm cc|mm|yy|cvv`
━━━━━━━━━━━━
""", parse_mode=ParseMode.MARKDOWN)
        return
    
    # Iniciar mensaje de procesamiento
    wait_msg = await update.message.reply_text(
        "⏳ `Establishing secure session...`",
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Pasos de procesamiento
    processing_steps = [
        "Validating payment details...",
        "Authenticating with card network...",
        "Processing transaction..."
    ]
    
    for step in processing_steps:
        await asyncio.sleep(0.8)
        try:
            await wait_msg.edit_text(f"⏳ `{step}`", parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logger.warning(f"Error editando mensaje: {str(e)}")
    
    # Obtener datos de tarjeta
    cc, mm, yy, cvv = cc_data
    cc_display = f"{cc}|{mm}|{yy[-2:]}|{cvv}"
    
    # Obtener información BIN
    bin_info = await get_bin_info(cc[:6])
    
    # Procesar transacción Bambora
    start_time = time.time()
    sim_status, sim_response = await process_bambora_transaction(cc, mm, yy, cvv)
    processing_time = round(time.time() - start_time, 2)
    
    # Determinar emoji según estado
    status_emoji = {
        "Approved": "🍒",
        "Declined": "👻",
        "Error": "⚠️"
    }.get(sim_status, "❓")
    
    # Formatear respuesta
    username = update.effective_user.username if update.effective_user.username else update.effective_user.first_name
    username_escaped = escape_markdown(username)
    
    response = f"""
\\[[👾]({LINK_ONYKAFREE})\\]
*{BOT_NAME}* \\| *Bambora Auth \[[/bm]\]*
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Card:* `{cc_display}`
\\[[👾]({LINK_ONYKAFREE})\\]
*Bank Info:* `{bin_info['bank']} - {bin_info['level']} {bin_info['type']} ({bin_info['country']})`
\\[[👾]({LINK_ONYKAFREE})\\]
*Status:* {sim_status}! {status_emoji}
\\[[👾]({LINK_ONYKAFREE})\\]
*Response:* `{sim_response}`
━━━━━━━━━━━━
\\[[👾]({LINK_ONYKAFREE})\\]
*Checked by:* @{username_escaped}
\\[[👾]({LINK_ONYKAFREE})\\]
*Time:* `{processing_time}s`
━━━━━━━━━━━━
"""
    await wait_msg.edit_text(response, parse_mode=ParseMode.MARKDOWN)