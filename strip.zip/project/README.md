# Noxus API Backend

## Descripción

Este proyecto implementa un bot de Telegram que gestiona autenticaciones de pago a través de **PayPal**, **Stripe** (con fallback) y **Braintree/Payflow**. Incluye logging estructurado y soporte para webhook HTTPS.

---

## Variables de entorno

| Variable               | Descripción                                 | Valor por defecto |
|------------------------|---------------------------------------------|-------------------|
| `PAYPAL_CLIENT_ID`     | ID del cliente PayPal (sandbox)             | – |
| `PAYPAL_CLIENT_SECRET` | Secreto del cliente PayPal (sandbox)        | – |
| `PAYPAL_ENV`           | `sandbox` o `live`                          | `sandbox` |
| `STRIPE_SECRET_KEY`    | (Opcional) Clave secreta de Stripe. Si no está definida, el bot usará el **fallback** basado en Luhn y heurísticas de BIN. | **No necesario** |
| `WEBHOOK_URL`          | URL pública donde Telegram enviará updates. | – |
| `WEBHOOK_CERT`         | Ruta al certificado TLS (pem) para HTTPS.  | – |
| `PORT`                 | Puerto de escucha del bot (default 8443).   | `8443` |
| `LOG_LEVEL`            | Nivel de logs (`DEBUG`, `INFO`, `WARNING`). | `INFO` |

---

## Instalación

```bash
# Clonar el repositorio
git clone <repo_url>
cd Noxus_API_Backend

# Instalar dependencias
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

---

## Configuración

1. **Crear un archivo `.env`** en la raíz del proyecto con las variables necesarias:
   ```env
   PAYPAL_CLIENT_ID=tu_client_id
   PAYPAL_CLIENT_SECRET=tu_secret
   PAYPAL_ENV=sandbox
   # STRIPE_SECRET_KEY=sk_test_...   (opcional)
   WEBHOOK_URL=https://<tu-dominio>/webhook
   WEBHOOK_CERT=path/to/cert.pem
   PORT=8443
   LOG_LEVEL=INFO
   ```
2. **Generar certificado TLS** (si usas tu propio dominio):
   ```bash
   openssl req -newkey rsa:2048 -nodes -keyout cert.key -x509 -days 365 -out cert.pem
   ```
   - Coloca `cert.pem` en una ruta accesible y apunta `WEBHOOK_CERT` a ella.
3. **Exponer la URL pública** (ejemplo con ngrok):
   ```bash
   ngrok http 8443
   ```
   Copia la URL HTTPS que ngrok genera y asigna a `WEBHOOK_URL`.

---

## Ejecución en modo webhook

```bash
# Cargar variables de entorno (en Windows PowerShell)
$env:PAYPAL_CLIENT_ID="<id>"
$env:PAYPAL_CLIENT_SECRET="<secret>"
$env:PAYPAL_ENV="sandbox"
$env:WEBHOOK_URL="https://<tu-dominio>/webhook"
$env:WEBHOOK_CERT="C:\path\to\cert.pem"
$env:PORT="8443"

python -m bot.bot
```
El módulo `bot.bot` detectará `WEBHOOK_URL` y configurará automáticamente el webhook con `ApplicationBuilder().webhook_url(...).webhook_cert(...).listen(port=PORT)`.

---

## Tests

Ejecuta la suite de pruebas con:

```bash
pytest -q
```
Los tests cubren:
- Fallback de Stripe (validación Luhn y BIN).
- Cliente PayPal (simulación de token y creación de orden usando `requests-mock`).
- Handlers de comandos (`/st`, `/pc`, etc.) con `AsyncMock`.
- Verificación de que el logger se configura según `LOG_LEVEL`.

---

## Despliegue en producción

1. **Configura un servidor** (Docker, systemd, etc.) que exponga el puerto configurado (ejemplo Dockerfile incluido en `docker/`).
2. **Define variables de entorno** en el entorno de producción (Docker Compose, Kubernetes ConfigMap, etc.).
3. **Ejecuta** el contenedor o el proceso de Python.
4. **Monitorea** los logs (stdout) o redirígelos a un sistema de logging centralizado.

---

## License

MIT License.
