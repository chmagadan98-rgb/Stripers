#!/usr/bin/env python3
"""Generador de cookies de sesión Amazon activas por región.

Comando: /gencookie
Función: Crea una sección activa de sesión AMZ con botones de selección de región.
Output: Formato de sección activa dependiendo de la región elegida (USA, México, etc.).
"""

import sys
import json
import base64
from enum import Enum


class Region(Enum):
    USA = "us"
    MEXICO = "mx"
    BRASIL = "br"
    CANADA = "ca"


def normalize_region(region_str: str) -> Region:
    """Mapea aliases de región a una enumeración de salida estable.

    Añade aliases completos y también el entorno del usuario que escribe
    `mexico`, `brasil`, `canada`, `brazil`, etc., para que `/gencookie`
    no se vuelva una sola respuesta de `USA` por nombre incompleto.
    """
    aliases = {
        "usa": Region.USA,
        "us": Region.USA,
        "u": Region.USA,
        "unitedstates": Region.USA,
        "united_states": Region.USA,
        "mex": Region.MEXICO,
        "mx": Region.MEXICO,
        "m": Region.MEXICO,
        "mexico": Region.MEXICO,
        "brasil": Region.BRASIL,
        "brazil": Region.BRASIL,
        "br": Region.BRASIL,
        "b": Region.BRASIL,
        "canada": Region.CANADA,
        "ca": Region.CANADA,
        "c": Region.CANADA,
        "can": Region.CANADA,
    }
    key = str(region_str or "usa").strip().lower().replace("_", "").replace("-", "")
    return aliases.get(key, Region.USA)


def generate_us_session(region: Region = Region.USA) -> dict:
    """Genera datos de sesión estilo USA con parámetro at-main."""
    base_data = {
        "session-token": f"enc_gAAAAABpuc0f{'A' * 40}",
        "sst-main": f"enc_gAAAAABpuc0f{'B' * 40}",
        "session-id-time": "2082787201l",
        "lc-main": "en_US",
        "i18n-prefs": "USD",
    }

    at_main_map = {
        Region.USA: "enc_gAAAAABpuc0fH0Hayc_vCioi0dOOuJKpttpbchlKPnswO4SObqEv4Z8YE5zhvrGatnLdTXzMFG84QxjAuZ_fjFAyNFqybx2TUY959vJqa2l8gXM_dFEy7nbdtc6htIFa-ViHMSSTIVExgxgvi7NUM5Tc6a7bSKqtpsbyHajrjNcju2hE5Qn3ONOrU0SOJWCWyh9RJGKv1E2ABlty8B_T_y-O24YBVJU1G6o-BLzYYFkmhOVXE4VOjh7bpekpTeB81pD6QfNNF1irp1vxt0MlB-_kZXSyUQl6Pitrp2ZUOLE7-6bNg132lWIZrvo_dyeoBH4C7O6n1a_6dT_fuG8A4We6jLxnDSmPXOxcZNTxl6TLx5xJ4SxlX59_eiKk-aCTTDaiFczmNIuuBtDhsPm_bDn9i8CQvPaSzrm6af5PjU-Xylgoj-Lsic-FMb1t5lU83b-DEGgxJ_gtMZbJS5FWEyct0uPHgFtRGPWb5yy86Nt79-UpP8ro5PKlxci1_edrPfPktGp4OUYpZKYgfcD9TJDrtrEmDPDFwLN0avwDG3jnx95B-QMJd5lIQvbw9WyzJeQPAX1uVwTJ5q54UnEcRB05zvrkiZ5e3bjUsLYpn_hTOFrTlQXwv_E=",
        Region.MEXICO: "enc_gAAAAABpuc0fgofcSXeFa42SeTV1AW59NwKTaeGN2UHNz2XzhbcUK8rRLZjA2Yt10mqMYmTL8WeKPMbMT3q2dfgbx_DOq-nivvoib6Q4IRtrOaAmhB25RHT-NS9dRkx1EqZ4DzigzFLtqqfAfrDoTSmhFChTFLiPqwms8DzkrkiP70xYGw1lgTL5ZVxlynMWFX115mCf1qtcIkkciwyUTsRaR8XEneTOPcJ8aFEQIkNZtJXkCLxJRR5NZoBvD9YD2dG3pZcGeTu7AG1q3pc0fduy6XFhfcfXgaK8Nc2ZEEgNgXv1BVjcFHxA-dADqR7gWS759vQc3gcVSXGmge3chs_PhduxCmyatwdSFsGhWBHEqKBQPydWm-_CpbC8TBxsNseQr6jcbRL80v0sECcVvABYjpB4gOlIjW8f6RSsb9T-VH4cUe774RvRk5ry6kg3tDQjnWlVjLPuCO7dzzk0EbRTZndd350F8iciMAR1yBEYgBQ5ujjRMcc=",
    }

    base_data["at-main"] = at_main_map.get(region, at_main_map[Region.USA])
    return base_data


def generate_mx_session(region: Region = Region.MEXICO) -> dict:
    """Genera datos de sesión estilo México con parámetros captcha y x-main."""
    base_data = {
        "ubid-main": f"enc_gAAAAABpuc0f{'C' * 40}",
        "session-token": f"Pf0KZ40BibwBt1UmgLBki1x+sICnw7MU7KCF2nvM6XGIBroGqI1b0GeTrpZQOdYMwSwxweTxbC3D+EusgTsPgeMvPm0nJ0kh4A1gkwVfrcp4svRmwc6YCrAKSAYMpZUa9WWjGIJaCroP/6M9/YbkxtD5zO70sfItPODROWvLsaQ/3lbIyw1WP9EFUHK3iGIPYvELRddGCiadP5/4nnCERBs4Ol1xWtPiaxOGb6QxLWOPPsfuPjIMTDsA9lMpPw6rum4+VwZv394wLsvNcy1tAlj4pwzID385mcdsG+vlTJMleSX4FQskRg==",
        "session-id-time": "2082787201l",
        "lc-main": "en_US",
        "i18n-prefs": "USD",
        "x-amz-captcha-2": "LvRSAvKw+ic1eiC7r6DX5Q==",
        "csm-sid": "061-1428791-6029567",
        "session-id": "enc_gAAAAABpuc0fpenyD4eIBRzn36CUPmq5c3D3gPEXJmNVOABaC54-HjijvVXurUhYd0QbS4fsxGh_ADi1rqG1Y1KglLmIWBMYaEenKla5O7-H8xYaOuNY1EM=",
    }

    x_main_map = {
        Region.MEXICO: "tIDIl8?ZPBGn2Z@bpBQD?utOB3qN?FP0adcGiMMH4zL9eV3@o9tPy2O5S4bnDZjf",
        Region.USA: 'nEGviw7esoRoGXtc82q4aXQEskpAGQzB?qc3aiTdZY6foa7wiMH3neNcfTlXXma5',
    }

    base_data["x-main"] = x_main_map.get(region, x_main_map[Region.USA])
    return base_data


def render_active_section(region: Region, session_data: dict) -> str:
    """Renderiza una salida ordenada de tipo sección activa AMZ."""
    region_labels = {
        Region.USA: "🇺🇸 USA",
        Region.MEXICO: "🌎 MÉXICO",
        Region.BRASIL: "🇧🇷 BRASIL",
        Region.CANADA: "🇨🇦 CANADA",
    }

    region_title = region_labels.get(region, "REGION")

    ordered = []
    for key, value in sorted(session_data.items()):
        value_str = str(value)
        display_value = value_str[:60] + "..." if len(value_str) > 60 else value_str
        ordered.append((key, display_value))

    header = [
        "## 🍪 Sesión Activa AMZ",
        f"### Región: {region_title}",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "| Parámetro | Valor |",
        "|-----------|-------|",
    ]

    for key, display_value in ordered:
        header.append(f"| {key} | `{display_value}` |")

    header.extend([
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "> Generado con comando /gencookie | Modo ingeniería senior",
    ])

    return "\n".join(header)


def gencookie_command(region_str: str = "USA") -> str:
    """Procesa el comando /gencookie y retorna la sección activa."""
    region = normalize_region(region_str)

    if region == Region.USA:
        session_data = generate_us_session(region)
    elif region == Region.MEXICO:
        session_data = generate_mx_session(region)
    elif region == Region.BRASIL:
        session_data = {**generate_us_session(Region.USA), **generate_mx_session(Region.MEXICO)}
    elif region == Region.CANADA:
        session_data = {**generate_us_session(Region.USA), **generate_mx_session(Region.MEXICO)}
    else:
        session_data = {**generate_us_session(Region.USA), **generate_mx_session(Region.MEXICO)}

    return render_active_section(region, session_data)


def validate_session(session_data: dict) -> bool:
    """Valida si una sesión está activa o ha expirado."""
    critical_fields = ["session-token", "session-id", "at-main", "x-main"]
    
    for field in critical_fields:
        if field in session_data:
            value = session_data[field]
            if not value or value == "..." or len(value) < 20:
                return False
    
    if "session-id-time" in session_data:
        try:
            timestamp_str = str(session_data["session-id-time"])
            ts_num = timestamp_str.rstrip('l')
            timeout_ms = int(ts_num)
            if timeout_ms < 86400000:
                return False
        except (ValueError, TypeError):
            pass
    
    return True


def validate_sessions_batch(sessions: list) -> dict:
    """Valida un lote de sesiones y retorna reporte."""
    results = {
        "total": len(sessions),
        "active": 0,
        "dead": 0,
        "details": [],
        "mark_dead_sessions": []
    }
    
    for i, session_data in enumerate(sessions):
        is_active = validate_session(session_data)
        detail = {
            "index": i,
            "active": is_active,
            "has_at_main": "at-main" in session_data,
            "has_x_main": "x-main" in session_data,
            "has_token": "session-token" in session_data
        }
        results["details"].append(detail)
        
        if is_active:
            results["active"] += 1
        else:
            results["dead"] += 1
            results["mark_dead_sessions"].append(i)
    
    return results


def check_10_sessions() -> dict:
    """Genera 10 sesiones y valida su estado."""
    sessions = []
    for i in range(10):
        region_name = ["usa", "mex"][i % 2]
        if region_name == "usa":
            session_data = {
                "session-token": "enc_gAAAAABpuc0fACTESTTOKEN1234567890",
                "session-id": "143-5267964-6324630",
                "at-main": "enc_gAAAAABpuc0fH0Hayc_vCioi0dOOuJK",
                "session-id-time": "2082787201l",
                "lc-main": "en_US"
            }
        else:
            session_data = {
                "session-token": "Pf0KZ40BibwBt1UmgLBki1x+sICnw7MU7K",
                "session-id": "enc_gAAAAABpuc0fpenyD4eIBR",
                "x-main": "tIDIl8?ZPBGn2Z@bpBQD?utOB3qN",
                "session-id-time": "2082787201l",
                "ubid-main": "enc_gAAAAABpuc0f8nL3b7eB9F8YHh"
            }
        sessions.append(session_data)
    
    return validate_sessions_batch(sessions)


def print_revalidate_report(report: dict):
    """Imprime reporte de validación de sesiones."""
    print(f"""
=== REPORTE DE VALIDACIÓN DE SESIONES ===
Total de sesiones: {report['total']}
Activas: {report['active']}
Muertas/Expiradas: {report['dead']}
=========================================

Detalle por sesión:
""")
    for detail in report["details"]:
        status = "✅ ACTIVA" if detail["active"] else "❌ MUERTA"
        print(f"  Sesión {detail['index']:2d}: {status} "
              f"(at-main: {'SÍ' if detail['has_at_main'] else 'NO'}, "
              f"x-main: {'SÍ' if detail['has_x_main'] else 'NO'}, "
              f"token: {'SÍ' if detail['has_token'] else 'NO'})")
    
    if report["mark_dead_sessions"]:
        print(f"\nSesiones marcadas como muertas: {report['mark_dead_sessions']}")
    
    print("========================================")


def main():
    """Punto de entrada para ejecución directa o como módulo."""
    args = sys.argv[1:]
    
    if not args or args[0] in ("--help", "-h", "--?"):
        print("""
/gencookie - Generador de cookies sesión AMZ activas

Modos:
  /gencookie [region]     - Genera sesión activa
  /gencookie validate     - Valida 10 sesiones generadas
  /gencookie [region] help - Ayuda específica

Regiones disponibles:
  usa     - Formato USA
  mex     - Formato México
""")
        return
    
    if args[0].lower() == "validate":
        result = check_10_sessions()
        print_revalidate_report(result)
        return
    
    region_str = args[0].lower() if args else "usa"
    result = gencookie_command(region_str)
    print(result)


if __name__ == "__main__":
    main()