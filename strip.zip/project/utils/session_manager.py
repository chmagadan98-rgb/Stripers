import os
import sqlite3
import json
import base64
import random
import logging
from datetime import datetime
from cryptography.fernet import Fernet
from fake_useragent import UserAgent

logger = logging.getLogger(__name__)

class SessionVault:
    def __init__(self, db_path="cookies_vault.db", key_path="vault.key", proxies_path="proxies.txt"):
        self.db_path = db_path
        self.key_path = key_path
        self.proxies_path = proxies_path
        self.ua = UserAgent()
        
        self.cipher = self._load_or_generate_key()
        self._init_db()

    def _load_or_generate_key(self) -> Fernet:
        if not os.path.exists(self.key_path):
            key = Fernet.generate_key()
            with open(self.key_path, "wb") as f:
                f.write(key)
        else:
            with open(self.key_path, "rb") as f:
                key = f.read()
        return Fernet(key)

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS sessions (
                        session_id TEXT PRIMARY KEY,
                        user_id INTEGER,
                        target_domain TEXT,
                        encrypted_cookie TEXT,
                        user_agent TEXT,
                        proxy TEXT,
                        created_at TIMESTAMP
                    )
                ''')
                conn.commit()
        except Exception as e:
            logger.error(f"Error initializing SessionVault DB: {e}")

    def _get_random_proxy(self) -> str:
        if not os.path.exists(self.proxies_path):
            return ""
        try:
            with open(self.proxies_path, "r", encoding="utf-8") as f:
                proxies = [line.strip() for line in f if line.strip() and not line.startswith("#")]
            return random.choice(proxies) if proxies else ""
        except Exception:
            return ""

    def encrypt_data(self, data: dict) -> str:
        json_data = json.dumps(data)
        return self.cipher.encrypt(json_data.encode()).decode()

    def decrypt_data(self, encrypted_data: str) -> dict:
        decrypted = self.cipher.decrypt(encrypted_data.encode()).decode()
        return json.loads(decrypted)

    def generate_session(self, user_id: int, target_domain: str, cookie_data: dict) -> dict:
        session_id = base64.urlsafe_b64encode(os.urandom(12)).decode('utf-8').rstrip('=')
        user_agent = self.ua.random
        proxy = self._get_random_proxy()
        
        # Prepare internal payload
        cookie_data['user_agent'] = user_agent
        cookie_data['proxy'] = proxy
        
        encrypted_cookie = self.encrypt_data(cookie_data)
        
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO sessions (session_id, user_id, target_domain, encrypted_cookie, user_agent, proxy, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (session_id, user_id, target_domain, encrypted_cookie, user_agent, proxy, datetime.now().isoformat()))
                conn.commit()
        except Exception as e:
            logger.error(f"Error storing session in Vault: {e}")
            raise

        return {
            "session_id": session_id,
            "target_domain": target_domain,
            "user_agent": user_agent,
            "proxy": proxy
        }

    def get_session(self, session_id: str, user_id: int) -> dict:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT encrypted_cookie, target_domain FROM sessions WHERE session_id = ? AND user_id = ?', (session_id, user_id))
                row = cursor.fetchone()
                if row:
                    encrypted_cookie, target_domain = row
                    cookie_data = self.decrypt_data(encrypted_cookie)
                    cookie_data['target_domain'] = target_domain
                    return cookie_data
        except Exception as e:
            logger.error(f"Error retrieving session from Vault: {e}")
        return {}

    def get_all_user_sessions(self, user_id: int) -> list:
        sessions = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT session_id, target_domain, created_at, encrypted_cookie FROM sessions WHERE user_id = ?', (user_id,))
                rows = cursor.fetchall()
                for row in rows:
                    session_id, target_domain, created_at, encrypted_cookie = row
                    decrypted = self.decrypt_data(encrypted_cookie)
                    sessions.append({
                        "session_id": session_id,
                        "target_domain": target_domain,
                        "created_at": created_at,
                        "cookie_data": decrypted
                    })
        except Exception as e:
            logger.error(f"Error retrieving user sessions from Vault: {e}")
        return sessions

    def export_sessions_txt(self, user_id: int, file_path: str):
        sessions = self.get_all_user_sessions(user_id)
        with open(file_path, "w", encoding="utf-8") as f:
            for s in sessions:
                f.write(f"--- SESSION ID: {s['session_id']} ---\n")
                f.write(f"Target: {s['target_domain']}\n")
                f.write(f"Created: {s['created_at']}\n")
                f.write(f"Payload: {json.dumps(s['cookie_data'], indent=2)}\n\n")

    def export_sessions_json(self, user_id: int, file_path: str):
        sessions = self.get_all_user_sessions(user_id)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(sessions, f, indent=4)

# Global vault instance for the bot
vault = SessionVault(
    db_path=os.path.join(os.path.dirname(__file__), "..", "cookies_vault.db"),
    key_path=os.path.join(os.path.dirname(__file__), "..", "vault.key"),
    proxies_path=os.path.join(os.path.dirname(__file__), "..", "proxies.txt")
)
