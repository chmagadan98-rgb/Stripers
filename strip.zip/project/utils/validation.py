# utils/validation.py
"""Utility helpers for the Noxus Telegram bot, converted from the original JavaScript version.
Provides timezone handling, premium checks, DB access, markdown escaping, and safe message sending.
"""
import os
import re
import pytz
import datetime
import logging
import mysql.connector
from mysql.connector import pooling
from typing import Tuple, Optional, Any

# Configure logger (mirroring winston setup)
logger = logging.getLogger('noxus_validation')
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
logger.addHandler(handler)

# MySQL connection pool – reuse the pool defined in utils/db_pool.py
from .db_pool import get_connection

# ----------------------------------------------------------------------
# Timezone handling (Mexico City)
# ----------------------------------------------------------------------
MEXICO_TZ = pytz.timezone('America/Mexico_City')

def get_mexico_time() -> datetime.datetime:
    """Return the current datetime in Mexico City timezone."""
    return datetime.datetime.now(MEXICO_TZ)

def parse_datetime_mexico(dt_input: Any) -> Optional[datetime.datetime]:
    """Parse a string or datetime into Mexico City timezone.
    Returns ``None`` if parsing fails.
    """
    if not dt_input:
        return None
    if isinstance(dt_input, datetime.datetime):
        # Ensure timezone awareness
        if dt_input.tzinfo is None:
            dt_input = MEXICO_TZ.localize(dt_input)
        return dt_input.astimezone(MEXICO_TZ)
    try:
        # Attempt ISO parsing; fallback to generic parsing
        parsed = datetime.datetime.fromisoformat(str(dt_input))
    except Exception:
        try:
            parsed = datetime.datetime.strptime(str(dt_input), '%Y-%m-%d %H:%M:%S')
        except Exception:
            return None
    if parsed.tzinfo is None:
        parsed = MEXICO_TZ.localize(parsed)
    return parsed.astimezone(MEXICO_TZ)

# ----------------------------------------------------------------------
# DB helpers (using the shared pool)
# ----------------------------------------------------------------------
def fetch_one(query: str, params: Tuple[Any, ...]) -> Optional[dict]:
    conn = get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        row = cursor.fetchone()
        return row
    except Exception as e:
        logger.error(f"DB query error: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def get_user_data(user_id: int) -> Optional[dict]:
    sql = "SELECT telegram_id, username, role, plan, credits, expiration_plan, antispam, antispam_mass, last_check FROM users WHERE telegram_id = %s"
    return fetch_one(sql, (user_id,))

def get_group_data(group_id: int) -> Optional[dict]:
    sql = "SELECT group_id, plan FROM groups WHERE group_id = %s"
    return fetch_one(sql, (group_id,))

# ----------------------------------------------------------------------
# Premium / VIP checks
# ----------------------------------------------------------------------
PERMANENT_ROLES = {'owner', 'co owner', 'dev', 'seller'}

# Legacy aliases retained for older callers.
get_colombia_time = get_mexico_time
parse_datetime_colombia = parse_datetime_mexico

async def is_user_premium(user_id: int) -> Tuple[bool, str]:
    return True, "Rol premium permanente (DEV BYPASS)"

async def is_group_premium(group_id: int) -> Tuple[bool, str]:
    return True, "Grupo PREMIUM (DEV BYPASS)"

async def has_access_to_premium_features(user_id: int, chat_id: int) -> Tuple[bool, str]:
    return True, "Acceso concedido (DEV BYPASS)"

# ----------------------------------------------------------------------
# Antispam / rate limiting (simplified placeholder)
# ----------------------------------------------------------------------
async def can_user_check(user_id: int, check_type: str = 'normal') -> Tuple[bool, str, int]:
    # Placeholder implementation – always allow
    return True, 'Puede realizar el check', 0

# ----------------------------------------------------------------------
# MarkdownV2 utilities
# ----------------------------------------------------------------------
def escape_markdown_v2(text: Any) -> str:
    if text is None:
        return 'N/A'
    escape_chars = r'([_\*\[\]\(\)~`>#+\-=|{}.!])'
    return re.sub(escape_chars, r'\\\1', str(text))

# ----------------------------------------------------------------------
# Safe message sending (using python-telegram-bot)
# ----------------------------------------------------------------------
async def send_message_safe(bot, chat_id: int, text: str, **kwargs):
    try:
        await bot.send_message(chat_id=chat_id, text=text, **kwargs)
    except Exception as e:
        logger.error(f"Failed to send message: {e}")
        # Fallback plain text
        fallback = text.replace('_', '').replace('*', '').replace('`', '')
        await bot.send_message(chat_id=chat_id, text=fallback, **kwargs)

__all__ = [
    'get_colombia_time',
    'parse_datetime_colombia',
    'is_user_premium',
    'has_access_to_premium_features',
    'can_user_check',
    'escape_markdown_v2',
    'send_message_safe',
    'get_connection',
]
