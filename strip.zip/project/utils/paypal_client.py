import os
import base64
import json
import time
import logging
from typing import Dict, Any, Optional
import requests
from utils.logging_setup import get_logger

class PayPalAPIError(Exception):
    """Custom exception for PayPal API errors."""
    def __init__(self, message: str, status_code: int = None, error_details: Dict[str, Any] = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_details = error_details if error_details is not None else {}
        
        # Extract specific PayPal error fields for easier access
        self.name = self.error_details.get('name')
        self.paypal_message = self.error_details.get('message') # Renamed to avoid conflict with Exception's message
        self.debug_id = self.error_details.get('debug_id')

    def __str__(self):
        # Enhance the string representation of the exception
        base_str = super().__str__()
        details = []
        if self.name: details.append(f"Name: {self.name}")
        if self.paypal_message and self.paypal_message != base_str: details.append(f"PayPal Message: {self.paypal_message}")
        if self.debug_id: details.append(f"Debug ID: {self.debug_id}")
        if self.status_code: details.append(f"Status Code: {self.status_code}")
        return f"{base_str} ({', '.join(details)})" if details else base_str

class PayPalClient:
    """Simple PayPal REST client supporting OAuth2 token retrieval, order creation and capture.
    Uses the PayPal sandbox by default. All credentials are read from environment variables.
    """

    def __init__(self, env: str = None):
        self.client_id = os.getenv('PAYPAL_CLIENT_ID')
        self.client_secret = os.getenv('PAYPAL_CLIENT_SECRET')
        self.env = env or os.getenv('PAYPAL_ENV', 'sandbox')
        if self.env == 'live':
            self.base_url = "https://api-m.paypal.com"
        else:
            self.base_url = f"https://api-m.{self.env}.paypal.com"
        self.logger = get_logger(__name__)
        self.access_token = None
        self.expires_in_seconds = 0
        self.token_obtained_at = 0
        
        # Add retry configuration for network resilience
        self.max_retries = 3
        self.retry_delay_seconds = 2 # seconds
        self._get_access_token()

    def _get_access_token(self) -> str:
        """Obtain an OAuth2 access token via client‑credentials flow.
        Stores the token in ``self.access_token`` and returns it.
        """
        token_url = f"{self.base_url}/v1/oauth2/token"
        auth = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode()).decode()
        headers = {
            "Authorization": f"Basic {auth}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {"grant_type": "client_credentials"}
        
        for attempt in range(self.max_retries):
            self.logger.info(f"Requesting PayPal access token (attempt {attempt + 1}/{self.max_retries})")
            try:
                response = requests.post(token_url, headers=headers, data=data, timeout=10)
                if response.status_code == 200:
                    token_info = response.json()
                    self.access_token = token_info.get('access_token')
                    self.expires_in_seconds = token_info.get('expires_in', 0)
                    self.token_obtained_at = time.time()
                    self.logger.info("PayPal access token obtained")
                    return self.access_token
                else:
                    self.logger.error(f"PayPal token request failed with status {response.status_code}: {response.text}")
                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay_seconds)
                    else:
                        raise PayPalAPIError(
                            f"Failed to obtain PayPal access token after {self.max_retries} attempts: {response.status_code}",
                            response.status_code,
                            response.json()
                        )
            except (requests.ConnectionError, requests.Timeout) as e:
                self.logger.warning(f"Network error during PayPal token request (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay_seconds)
                else:
                    raise PayPalAPIError(f"Network error obtaining PayPal access token after {self.max_retries} attempts: {e}")
        return self.access_token

    def _is_token_expired(self) -> bool:
        """Check if the current access token is expired or about to expire (e.g., within 60 seconds)."""
        return not self.access_token or (time.time() > (self.token_obtained_at + self.expires_in_seconds - 60))

    def _request(self, method: str, endpoint: str, json_body: Dict[str, Any] = None, idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        """
        Makes a request to the PayPal API, handling token refresh and retries.
        :param method: HTTP method (e.g., 'get', 'post').
        :param endpoint: API endpoint (e.g., '/v2/checkout/orders').
        :param json_body: JSON payload for the request.
        :param idempotency_key: Optional unique key for idempotent requests.
        :return: JSON response from the API.
        :raises PayPalAPIError: If the API request fails after retries.
        """
        if self._is_token_expired():
            self._get_access_token() # Refresh token if expired

        url = f"{self.base_url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }
        if idempotency_key:
            headers["PayPal-Request-Id"] = idempotency_key

        for attempt in range(self.max_retries):
            self.logger.info(f"PayPal {method.upper()} {endpoint} (attempt {attempt + 1}/{self.max_retries})")
            try:
                response = requests.request(method, url, headers=headers, json=json_body, timeout=15)
                if response.ok:
                    return response.json()
                else:
                    self.logger.error(f"PayPal API error {response.status_code} for {endpoint}: {response.text}")
                    # For 4xx errors (client errors), don't retry unless specifically configured
                    if 400 <= response.status_code < 500 and response.status_code not in [429]: # 429 could be retried
                        try:
                            error_details = response.json()
                        except Exception:
                            error_details = {}
                        raise PayPalAPIError(f"PayPal API request failed: {response.status_code}", response.status_code, error_details)

                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay_seconds)
                    else:
                        try:
                            error_details = response.json()
                        except Exception:
                            error_details = {}
                        raise PayPalAPIError(f"PayPal API request failed after {self.max_retries} attempts: {response.status_code}", response.status_code, error_details)
            except (requests.ConnectionError, requests.Timeout) as e:
                self.logger.warning(f"Network error during PayPal API request to {endpoint} (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay_seconds)
                else:
                    raise PayPalAPIError(f"Network error during PayPal API request after {self.max_retries} attempts: {e}")

    def create_order(self, amount: str, currency: str = "USD", return_url: str = "https://example.com/return", cancel_url: str = "https://example.com/cancel", idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        """Create a PayPal order and return the full JSON response.
        ``amount`` must be a string representation of the amount (e.g. "10.00").
        """
        payload = {
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": currency,
                    "value": amount,
                }
            }],
            "application_context": {
                "brand_name": "Noxus Bot",
                "landing_page": "LOGIN",
                "user_action": "PAY_NOW",
                "return_url": return_url,
                "cancel_url": cancel_url,
            },
        }
        return self._request('post', '/v2/checkout/orders', payload, idempotency_key=idempotency_key)

    def capture_order(self, order_id: str) -> Dict[str, Any]:
        """Capture a previously created order."""
        return self._request('post', f'/v2/checkout/orders/{order_id}/capture')

    def create_order_with_card(self, amount: str, currency: str, card_details: Dict[str, str], idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        """
        Hypothetical method to create a PayPal order directly with card details as payment source.
        This is for direct card validation/transaction without user redirection.
        
        :param amount: The transaction amount (e.g., "0.10").
        :param currency: The currency code (e.g., "USD").
        :param card_details: Dictionary containing 'number', 'expiry_month', 'expiry_year' (4-digit), 'cvv'.
        :param idempotency_key: Optional unique key for idempotent requests.
        :return: The created order object from PayPal.
        :raises PayPalAPIError: If the API request fails or card is declined.
        """
        payload = {
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": currency,
                    "value": amount,
                },
                "payment_source": {
                    "card": {
                        "number": card_details['number'],
                        "expiry": f"{card_details['expiry_month']}{card_details['expiry_year']}", # MMYYYY format
                        "security_code": card_details['cvv'],
                        # Additional card details like billing_address can be added here if needed
                    }
                }
            }],
            "application_context": {
                "brand_name": "Noxus Bot",
                "landing_page": "NO_PREFERENCE", # Or BILLING_AGREEMENT
                "user_action": "PAY_NOW",
            },
        }
        return self._request('post', '/v2/checkout/orders', payload, idempotency_key=idempotency_key)
