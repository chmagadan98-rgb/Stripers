# utils/mass_checker_framework.py
import asyncio
import io
import time
from typing import Callable, Tuple, Any, Coroutine
from aiogram import Router, types
from aiogram.filters import Command
from aiogram.exceptions import TelegramBadRequest
from aiomysql.pool import Pool

from utils.response_utils import categorize_response

def renderizar_panel_masivo(gateway_name: str, vivas: int, muertas: int, procesadas: int, total: int, estado: str = "Iniciando...", etr_seconds: float = 0.0):
    """
    Construye la interfaz visual del panel masivo.
    """
    porcentaje = (procesadas / total * 100) if total > 0 else 0
    barra_len = 20
    progreso_len = int(barra_len * porcentaje / 100)
    barra = "█" * progreso_len + "─" * (barra_len - progreso_len)

    # Formatear ETR a minutos y segundos
    if etr_seconds > 0:
        minutos, segundos = divmod(int(etr_seconds), 60)
        etr_str = f"{minutos:02d}m {segundos:02d}s"
    else:
        etr_str = "Calculando..."

    texto_consola = (
        f"<pre>"
        f"╔══════════════════════════════╗\n"
        f"║  NOXUS MASS CHECKER ({gateway_name.upper()})  ║\n"
        f"╚══════════════════════════════╝\n"
        f" 🟢 VIVAS     :: {vivas}\n"
        f" 🔴 MUERTAS   :: {muertas}\n"
        f" 🔄 PROCESADAS :: {procesadas} / {total}\n"
        f"────────────────────────────────\n"
        f" ⏳ ETR        :: {etr_str}\n"
        f"  [{barra}] {porcentaje:.2f}%\n"
        f"────────────────────────────────\n"
        f" LOG: {estado}\n"
        f"</pre>"
    )
    return texto_consola

def create_mass_checker_handler(command: str, gateway_name: str, checker_function: Coroutine, required_plan: list, concurrency_limit: int = 10):
    """
    Fábrica que crea un router y un manejador de comando masivo para aiogram.
    """
    router = Router()
    semaphore = asyncio.Semaphore(concurrency_limit)

    @router.message(Command(command))
    async def handler(message: types.Message, db_pool: Pool):
        user_id = message.from_user.id
        
        # user_data = await get_user_data_from_db_async(db_pool, user_id)
        user_data = {"role": "OWNER"} # Placeholder
        if not user_data or user_data.get('role', 'user').upper() not in required_plan:
            await message.reply(f"👾 Acceso denegado. Requiere plan {required_plan[0]} o superior.")
            return

        if not message.document or not message.document.file_name.endswith('.txt'):
            await message.reply(f"⚠️ Por favor, envía un archivo `.txt` con el comando `/{command}`.")
            return

        msg_inicial = await message.reply("<i>Leyendo archivo...</i>")
        
        try:
            file_io = io.BytesIO()
            await message.bot.download(message.document, destination=file_io)
            file_content_bytes = file_io.getvalue()
            lineas = [line.strip() for line in file_content_bytes.decode('utf-8', errors='ignore').splitlines() if line.strip()]
        except Exception as e:
            await msg_inicial.edit_text(f"❌ Error al leer el archivo: {e}")
            return

        if not lineas:
            await msg_inicial.edit_text("❌ El archivo está vacío.")
            return

        vivas, muertas, procesadas, lineas_totales = 0, 0, 0, len(lineas)
        resultados_vivos, resultados_muertos = [], []
        start_time = time.time()
        
        texto_panel = renderizar_panel_masivo(gateway_name, vivas, muertas, 0, lineas_totales)
        panel_mensaje = await msg_inicial.edit_text(text=texto_panel)

        is_coro = asyncio.iscoroutinefunction(checker_function)
        last_update_time = time.time()

        async def process_line(linea: str):
            """Función wrapper para procesar una línea con el semáforo."""
            async with semaphore:
                status, response_msg, estado_actual = "Error", "Unknown", "Procesando..."
                try:
                    if is_coro:
                        status, response_msg, _ = await checker_function(linea)
                    else:  # Si la función es síncrona
                        loop = asyncio.get_event_loop()
                        status, response_msg, _ = await loop.run_in_executor(None, checker_function, linea)
                    
                    return linea, status, response_msg
                except Exception as e:
                    return linea, "Error", f"ERROR: {linea[:12]}... ({type(e).__name__})"

        tasks = [process_line(linea) for linea in lineas]

        for future in asyncio.as_completed(tasks):
            linea, status, response_msg = await future
            procesadas += 1

            if status in ['Approved', 'APPROVED', 'LIVE', 'CCN LIVE', 'SPECIAL', 'CHARGED']:
                vivas += 1
                resultados_vivos.append(f"{linea} -> {response_msg}")
                estado_actual = f"VÁLIDO: {linea[:12]}..."
            else:
                muertas += 1
                resultados_muertos.append(f"{linea} -> {response_msg}")
                estado_actual = f"RECHAZADO: {linea[:12]}..."

            # Actualizar el panel cada 2 segundos o en el último item
            current_time = time.time()
            if current_time - last_update_time > 2.0 or procesadas == lineas_totales:
                elapsed_time = current_time - start_time
                etr_seconds = (elapsed_time / procesadas) * (lineas_totales - procesadas) if procesadas > 0 else 0

                nuevo_texto = renderizar_panel_masivo(
                    gateway_name, vivas, muertas, procesadas, lineas_totales, estado_actual, etr_seconds
                )

                try:
                    # Solo editar si el texto ha cambiado para evitar errores de "Message is not modified"
                    if panel_mensaje.text != nuevo_texto:
                        await panel_mensaje.edit_text(text=nuevo_texto)
                        last_update_time = current_time
                except TelegramBadRequest as e:
                    if "Message is not modified" not in str(e):
                        print(f"Error al editar mensaje: {e}")

        texto_final = renderizar_panel_masivo(gateway_name, vivas, muertas, lineas_totales, lineas_totales, "¡Proceso completado!")
        await panel_mensaje.edit_text(text=texto_final)

        if resultados_vivos:
            archivo_en_memoria = io.BytesIO("\n".join(resultados_vivos).encode('utf-8'))
            documento = types.BufferedInputFile(archivo_en_memoria.getvalue(), filename=f"vivas_{gateway_name}_{user_id}.txt")
            await message.reply_document(
                document=documento,
                caption=f"✅ ¡Aquí tienes tu lista de {vivas} resultados VIVOS de {gateway_name.upper()}!"
            )
        else:
            await message.reply(f"ℹ️ No se encontraron resultados vivos para {gateway_name.upper()}.")

        if resultados_muertos:
            archivo_muertas = io.BytesIO("\n".join(resultados_muertos).encode('utf-8'))
            documento_muertas = types.BufferedInputFile(archivo_muertas.getvalue(), filename=f"muertas_{gateway_name}_{user_id}.txt")
            await message.reply_document(
                document=documento_muertas,
                caption=f"👻 Aquí tienes tu lista de {muertas} resultados RECHAZADOS de {gateway_name.upper()}."
            )

    return router