import os
import logging
import random
import string
import json
import httpx
import base64
from typing import Dict, Any

logger = logging.getLogger(__name__)

class BamboraAPIError(Exception):
    """Custom exception for Bambora API errors."""
    def __init__(self, message: str, status_code: int = None, error_details: Dict[str, Any] = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_details = error_details if error_details is not None else {}

    def __str__(self):
        base_str = super().__str__()
        if self.status_code:
            base_str += f" (Status: {self.status_code})"
        if self.error_details:
            base_str += f" Details: {json.dumps(self.error_details)}"
        return base_str

class BamboraClient:
    """
    Hypothetical client for Bambora API.
    This is a simulation for demonstration purposes.
    A real implementation would use Bambora's actual API endpoints and authentication.
    """
    def __init__(self, client: httpx.AsyncClient = None):
        self.api_key = os.getenv('BAMBORA_API_KEY')
        self.merchant_id = os.getenv('BAMBORA_MERCHANT_ID')
        # Example base URL, replace with actual Bambora API endpoint
        self.base_url = os.getenv('BAMBORA_BASE_URL', 'https://api.na.bambora.com/v1')
        self.logger = logger
        self.client = client or httpx.AsyncClient(timeout=20)

        if not self.api_key or not self.merchant_id:
            self.logger.warning("Bambora API Key or Merchant ID not set. Using simulated responses.")
            # In a real scenario, you might raise an error here or have a strict check.
            # For now, we'll let the simulation handle it if credentials are missing.

    async def authorize_card(self, amount: str, cc: str, mes: str, ano: str, cvv: str) -> Dict[str, Any]:
        """
        Performs a card authorization with Bambora's API.
        This method is now asynchronous.
        """
        if not self.api_key or not self.merchant_id:
            self.logger.error("Bambora API Key or Merchant ID not configured.")
            raise BamboraAPIError("Bambora credentials not configured.", status_code=500)

        headers = {
            "Authorization": f"Passcode {base64.b64encode(f'{self.merchant_id}:{self.api_key}'.encode()).decode()}",
            "Content-Type": "application/json"
        }
        
        # Ensure year is 4 digits
        full_ano = f"20{ano}" if len(ano) == 2 else ano

        payload = {
            "amount": amount,
            "payment_method": {
                "card": {
                    "number": cc,
                    "expiry_month": mes,
                    "expiry_year": full_ano,
                    "cvv": cvv
                }
            },
            "order_number": "order_" + ''.join(random.choices(string.ascii_lowercase + string.digits, k=10)),
            "processing_options": {
                "capture": False, # Set to False for authorization only, True for sale
                "verify_cvv": True,
                "verify_avs": False # Adjust as needed
            }
        }
        
        try:
            response = await self.client.post(f"{self.base_url}/payments", headers=headers, json=payload)
            response.raise_for_status()  # Raise HTTPStatusError for bad responses (4xx or 5xx)
            response_data = response.json()

            if response_data.get('approved'):
                return {
                    'success': True,
                    'message': response_data.get('message', 'Approved'),
                    'transaction_id': response_data.get('id'),
                    'processor_response': response_data.get('message'),
                    'details': response_data
                }
            else:
                return {
                    'success': False,
                    'message': response_data.get('message', 'Declined'),
                    'processor_response': response_data.get('message'),
                    'details': response_data
                }
        except httpx.RequestError as e:
            self.logger.error(f"Bambora API request failed: {e}")
            raise BamboraAPIError(f"Network or API error: {e}", status_code=e.response.status_code if hasattr(e, 'response') and e.response else None, error_details={'exception': str(e), 'response_text': e.response.text if hasattr(e, 'response') and e.response else None})
        except Exception as e:
            self.logger.error(f"Unexpected error during Bambora API call: {e}")
            raise BamboraAPIError(f"Unexpected error: {e}", error_details={'exception': str(e)})

    async def _simulate_response(self, cc: str) -> Dict[str, Any]:
        """Simulates a Bambora API response based on card prefix."""
        self.logger.info(f"Simulating Bambora authorization for {cc[:6]}...{cc[-4:]}")

        if cc.startswith("4"): # Visa
            if random.random() < 0.8: # 80% chance of approval
                return {
                    'success': True,
                    'message': 'Approved',
                    'transaction_id': 'txn_' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=10)),
                    'processor_response': 'APPROVED',
                    'details': {'auth_code': '123456'}
                }
            else:
                return {
                    'success': False,
                    'message': 'Declined: Insufficient Funds',
                    'processor_response': 'DECLINED',
                    'details': {'reason_code': '51'}
                }
        elif cc.startswith("5"): # Mastercard
            if random.random() < 0.7:
                return {
                    'success': True,
                    'message': 'Approved',
                    'transaction_id': 'txn_' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=10)),
                    'processor_response': 'APPROVED',
                    'details': {'auth_code': '654321'}
                }
            else:
                return {
                    'success': False,
                    'message': 'Declined: Do Not Honor',
                    'processor_response': 'DECLINED',
                    'details': {'reason_code': '05'}
                }
        else:
            return {
                'success': False,
                'message': 'Declined: Card Type Not Supported',
                'processor_response': 'DECLINED',
                'details': {'reason_code': '99'}
            }