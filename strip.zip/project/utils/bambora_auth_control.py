# AUTH/bambora_auth_control.py
"""
Handler para el comando de autorización con Bambora (/bmb).
Utiliza BamboraClient para la autorización de tarjetas, con manejo de errores
detallado y una respuesta informativa.
"""
import os
import sys
import asyncio
import logging
from aiogram import Router, types
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiomysql.pool import Pool

# Añadir ruta para importaciones
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.card_parser import extract_cc_from_text_sync
from utils.bambora_client import BamboraClient, BamboraAPIError
from utils.response_classifier import classify_bambora_response
from utils.response_utils import send_response_message
# Placeholder para funciones de usuario y antispam
# from admin_actions import get_user_data_from_db, check_antispam, update_user_last_check

logger = logging.getLogger(__name__)

REQUIRED_PLAN_BMB = ['PREMIUM', 'VIP', 'OWNER', 'CO OWNER', 'DEV', 'SELLER']

router = Router()

@router.message(Command("bmb", prefix="/!."))
async def handle_bmb_command(message: types.Message, db_pool: Pool):
    """
    Handler para el comando /bmb (Bambora Auth).
    Procesa una transacción de autorización.
    """
    user_id = message.from_user.id
    start_time = asyncio.get_event_loop().time()

    # 1. Validación de usuario y antispam (usando placeholders)
    # user_data = await get_user_data_from_db(db_pool, user_id)
    user_data = {"role": "OWNER"} # Placeholder
    if not user_data or user_data.get('role', 'user').upper() not in REQUIRED_PLAN_BMB:
        await message.reply("👾 Acceso denegado. Requiere plan PREMIUM o superior.")
        return

    # can_check, wait_time = await check_antispam(db_pool, user_id, 'normal')
    can_check, wait_time = True, 0 # Placeholder
    if not can_check:
        await message.reply(f"⏳ Por favor, espera {wait_time} segundos antes de usar otro comando.")
        return

    # 2. Extracción y validación de la tarjeta
    card_data = extract_cc_from_text_sync(message.text)
    if not card_data:
        await message.reply("💳 Formato de tarjeta no válido. Proporciona los datos correctamente.")
        return

    cc, mes, ano, cvv = card_data.split('|')
    
    processing_msg = await message.reply("<i>Procesando con Bambora...</i>")

    # 3. Ejecución de la autorización asíncrona
    try:
        bambora_client = BamboraClient()
        # La función ahora es asíncrona y se puede llamar directamente
        result_details = await bambora_client.authorize_card("1.00", cc, mes, ano, cvv)
        
        # Usar el clasificador central para determinar el estado y mensaje final
        status, message = classify_bambora_response(result_details)
        result_details['status'] = status
        result_details['message'] = message
        
        await send_response_message(processing_msg, "Bambora Auth", card_data, start_time, result_details)

    except BamboraAPIError as e:
        logger.error(f"Error de API en Bambora: {e}")
        await send_response_message(processing_msg, "Bambora Auth", card_data, start_time, {'status': 'Error', 'message': str(e), **e.error_details})
    except Exception as e:
        logger.error(f"Error inesperado en handle_bmb_command: {e}", exc_info=True)
        await send_response_message(processing_msg, "Bambora Auth", card_data, start_time, {'status': 'Error', 'message': f"Error inesperado: {str(e)}"})
    
    # await update_user_last_check(db_pool, user_id) # Placeholder