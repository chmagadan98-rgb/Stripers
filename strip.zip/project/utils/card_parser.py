# utils/card_parser.py
"""Utility functions to extract credit‑card data from arbitrary text.
The regex patterns mirror those used in the original JavaScript implementation.
"""
import re
from typing import Optional

PATTERNS = [
    # 1234567890123456|12|25|123  (any separator)
    r"\b\d{13,19}[\s|:/]+\d{1,2}[\s|:/]+\d{2,4}[\s|:/]+\d{3,4}\b",
    # Only the card number (fallback)
    r"\b\d{13,19}\b",
]

def extract_cc_from_text(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in PATTERNS:
        matches = re.findall(pattern, text)
        if matches:
            cc = matches[0].strip()
            # Normalise separators to '|'
            return re.sub(r"[\s|:/]+", "|", cc)
    return None


def extract_cc_from_text_sync(text: str) -> Optional[str]:
    """Compatibility name used by the aiogram gateway handlers."""
    return extract_cc_from_text(text)
