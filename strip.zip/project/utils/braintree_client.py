import os
import logging
from typing import Dict, Any
import braintree
from utils.logging_setup import get_logger

logger = get_logger(__name__)

def get_braintree_gateway() -> braintree.BraintreeGateway:
    """Create and return a BraintreeGateway instance using env vars.
    Expected env vars:
        BRAINTREE_ENV (Sandbox or Production)
        BRAINTREE_MERCHANT_ID
        BRAINTREE_PUBLIC_KEY
        BRAINTREE_PRIVATE_KEY
    """
    env = os.getenv('BRAINTREE_ENV', 'Sandbox')
    merchant_id = os.getenv('BRAINTREE_MERCHANT_ID')
    public_key = os.getenv('BRAINTREE_PUBLIC_KEY')
    private_key = os.getenv('BRAINTREE_PRIVATE_KEY')
    if not all([merchant_id, public_key, private_key]):
        logger.warning('Braintree credentials not fully set, falling back to simulated mode.')
        return None
    configuration = braintree.Configuration(
        environment=getattr(braintree.Environment, env),
        merchant_id=merchant_id,
        public_key=public_key,
        private_key=private_key,
    )
    gateway = braintree.BraintreeGateway(configuration)
    logger.info('Braintree gateway initialized')
    return gateway

def sale_transaction_raw(amount: str, cc: str, mes: str, ano: str, cvv: str, three_d_secure_options: Dict[str, Any] = None, **kwargs) -> Dict[str, Any]:
    """Execute a sale transaction using raw credit card data.
    Returns the result dict from Braintree with actual processor responses.
    """
    gateway = get_braintree_gateway()
    
    if not gateway:
        logger.error("Braintree gateway not initialized. Check .env configuration.")
        return {'success': False, 'message': 'Gateway not configured'}

    options = {
        'submit_for_settlement': True,
    }
    if three_d_secure_options:
        options['three_d_secure'] = three_d_secure_options
    try:
        result = gateway.transaction.sale({
            'amount': amount,
            'credit_card': {
                'number': cc,
                'expiration_month': mes,
                'expiration_year': ano,
                'cvv': cvv
            },
            'options': options,
            **kwargs,
        })
        
        if result.is_success:
            logger.info(f"Braintree transaction successful: {result.transaction.id}")
            return {'success': True, 'transaction_id': result.transaction.id, 'message': 'Approved', 'details': result.transaction.__dict__}
        else:
            # Intentar extraer el mensaje real de rechazo del procesador bancario
            error_msg = result.message
            if result.transaction and result.transaction.processor_response_text:
                error_msg = f"{result.transaction.processor_response_code} - {result.transaction.processor_response_text}"
                
            logger.error(f"Braintree transaction failed: {error_msg}")
            return {'success': False, 'message': error_msg}
            
    except Exception as e:
        logger.error(f"Braintree API error: {e}")
        return {'success': False, 'message': str(e)}
