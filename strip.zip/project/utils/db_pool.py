import aiomysql
import logging
import os
import mysql.connector

logger = logging.getLogger(__name__)


def get_connection():
    """Return a synchronous MySQL connection for legacy gateway code."""
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", ""),
        database=os.getenv("DB_NAME", "noxus"),
    )

async def create_db_pool(db_config: dict):
    """
    Crea y devuelve un pool de conexiones de base de datos asíncrono.
    Se llama una vez al iniciar el bot.
    """
    try:
        # Cargar configuración desde variables de entorno como fallback
        pool = await aiomysql.create_pool(
            host=db_config.get('host') or os.getenv('DB_HOST'),
            port=db_config.get('port', 3306),
            user=db_config.get('user') or os.getenv('DB_USER'),
            password=db_config.get('password') or os.getenv('DB_PASS'),
            db=db_config.get('database') or os.getenv('DB_NAME'),
            autocommit=True,
            minsize=1,
            maxsize=10, # Ajusta el tamaño máximo del pool según la carga esperada
            loop=None # aiomysql detectará el loop de asyncio automáticamente
        )
        logger.info("✅ Pool de conexiones a la base de datos creado exitosamente.")
        return pool
    except Exception as e:
        logger.critical(f"CRITICAL: No se pudo crear el pool de conexiones a la DB: {e}", exc_info=True)
        return None

async def close_db_pool(pool):
    if pool:
        pool.close()
        await pool.wait_closed()
        logger.info("Pool de conexiones a la base de datos cerrado correctamente.")