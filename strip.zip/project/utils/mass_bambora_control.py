# MASS/mass_bambora_control.py
"""
Handler para el comando de chequeo masivo de Bambora (/mbmb).
Utiliza el mass_checker_framework para procesar un archivo de tarjetas
de forma concurrente.
"""
import os
import sys
import logging
from typing import Tuple, Dict, Any

# Añadir el directorio raíz al path para permitir importaciones absolutas
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.mass_checker_framework import create_mass_checker_handler
from utils.bambora_client import BamboraClient, BamboraAPIError
from utils.response_classifier import classify_bambora_response
from utils.card_parser import extract_cc_from_text_sync

logger = logging.getLogger(__name__)

async def check_bambora_card_async(cc_formatted: str) -> Tuple[str, str, Dict[str, Any]]:
    """
    Función de verificación asíncrona para Bambora.
    Esta corutina será ejecutada concurrentemente por el mass_checker_framework.
    """
    card_parts = cc_formatted.split('|')
    if len(card_parts) < 4:
        return "Declined", "Invalid Card Format", {}
    cc, mes, ano, cvv = card_parts

    try:
        bambora_client = BamboraClient()
        # El año debe tener 4 dígitos para la API de Bambora
        full_ano = f"20{ano}" if len(ano) == 2 else ano
        
        result = await bambora_client.authorize_card("1.00", cc, mes, full_ano, cvv)
        
        # Usar el clasificador central para determinar el estado y mensaje final
        status, message = classify_bambora_response(result)
        return status, message, result

    except BamboraAPIError as e:
        logger.warning(f"Bambora API Error en chequeo masivo: {e}")
        return "Error", f"Bambora API Error: {str(e)}", e.error_details
    except Exception as e: # pragma: no cover
        logger.error(f"Error inesperado en check_bambora_card_sync: {e}", exc_info=True)
        return "Error", f"Unexpected Error: {str(e)}", {}

REQUIRED_PLAN_MBMB = ['PREMIUM', 'VIP', 'OWNER', 'CO OWNER', 'DEV', 'SELLER']

router = create_mass_checker_handler(
    command="mbmb",
    gateway_name="Bambora",
    checker_function=check_bambora_card_async,
    required_plan=REQUIRED_PLAN_MBMB
)