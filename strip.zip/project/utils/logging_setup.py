import logging
import os

def get_logger(name: str) -> logging.Logger:
    """Return a configured logger.
    Logs are output to stdout with a simple format including timestamp, level, and name.
    The log level can be controlled via the LOG_LEVEL environment variable (default INFO).
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    log_level_str = os.getenv('LOG_LEVEL', 'INFO').upper()
    log_level = getattr(logging, log_level_str, logging.INFO)
    logger.setLevel(log_level)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(name)s | %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False
    return logger

def setup_logging(config_path='logging_config.json'):
    """Load logging configuration from a JSON file if it exists.
    If the file is missing, fall back to a basic INFO level logger.
    """
    if os.path.exists(config_path):
        try:
            import json
            import logging.config
            with open(config_path, 'rt') as f:
                config = json.load(f)
            logging.config.dictConfig(config)
        except Exception as e:
            logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
            logging.getLogger(__name__).error(f"Failed to load logging config: {e}")
    else:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

