# CCN/nmi_control.py
import os
import sys
import asyncio
import logging
from aiogram import Router, types
from aiogram.filters import Command
from aiomysql.pool import Pool

# Añadir ruta para importaciones
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.card_parser import extract_cc_from_text_sync
from utils.braintree_client import sale_transaction_raw
from utils.response_classifier import classify_braintree_response

logger = logging.getLogger(__name__)

REQUIRED_PLAN_XD = ['PREMIUM', 'VIP', 'OWNER', 'CO OWNER', 'DEV', 'SELLER']

router = Router()

@router.message(Command("xd"))
async def handle_xd_command(message: types.Message, db_pool: Pool):
    """
    Handler para el comando /xd (NMI / Braintree Direct).
    Procesa una transacción de venta directa de $1.
    """
    user_id = message.from_user.id
    start_time = asyncio.get_event_loop().time()
    
    # 1. Validación de usuario y antispam
    # user_data = await get_user_data_from_db_async(db_pool, user_id)
    user_data = {"role": "OWNER"} # Placeholder
    if not user_data or user_data.get('role', 'user').upper() not in REQUIRED_PLAN_XD:
        await message.reply("👾 Acceso denegado. Requiere plan PREMIUM o superior.")
        return

    # can_check, wait_time = await check_antispam_async(db_pool, user_id, 'normal')
    can_check, wait_time = True, 0 # Placeholder
    if not can_check:
        await message.reply(f"⏳ Por favor, espera {wait_time} segundos antes de usar otro comando.")
        return

    # 2. Extracción y validación de la tarjeta
    card_data = extract_cc_from_text_sync(message.text)
    if not card_data:
        await message.reply("💳 Formato de tarjeta no válido. Proporciona los datos correctamente.")
        return

    cc, mes, ano, cvv = card_data.split('|')
    
    processing_msg = await message.reply("<i>Procesando...</i>")

    # 3. Ejecución de la transacción (usando el cliente de Braintree como análogo de NMI)
    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(None, lambda: sale_transaction_raw("1.00", cc, mes, ano, cvv))
        status, message_text = classify_braintree_response(result)

    except Exception as e:
        logger.error(f"Error en handle_xd_command (Braintree): {e}")
        status, message_text = "Error", str(e)

    # 4. Envío de la respuesta final y actualización del antispam
    # await send_response_message_async(processing_msg, status, message_text, start_time, cc, "NMI Direct")
    # await update_user_last_check_async(db_pool, user_id)
    await processing_msg.edit_text(f"<b>Resultado:</b> {status}\n<b>Mensaje:</b> {message_text}")