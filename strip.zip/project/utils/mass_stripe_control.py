# MASS/mass_stripe_control.py
"""
Handler para el comando de chequeo masivo de Stripe (/mst).
Utiliza el framework de chequeo masivo para procesar un archivo de tarjetas.
"""
import sys
import os

# Añadir el directorio raíz al path para permitir importaciones absolutas
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.mass_checker_framework import create_mass_checker_handler
from utils.stripe_check_sync import check_stripe_card

# --- Configuración del Handler ---
# Define el plan requerido para usar este comando. Ejemplo: ['VIP', 'OWNER']
REQUIRED_PLAN_MST = ['PREMIUM', 'VIP', 'OWNER', 'CO OWNER', 'DEV', 'SELLER']

# Crea el handler para /mst usando la fábrica
router = create_mass_checker_handler(
    command="mst",
    gateway_name="Stripe",
    checker_function=check_stripe_card,
    required_plan=REQUIRED_PLAN_MST
)