import logging
import time
import re
import json
from typing import Dict, Any, Tuple, Optional, List
from aiogram import types
from aiogram.enums import ParseMode
from bot_info import LINK_ONYKAFREE, BOT_NAME
from utils.helpers import get_country_emoji

# Assuming these are available globally or via config
# from bot_info import LINK_ONYKAFREE, BOT_NAME # Already imported above
# Placeholder values as bot_info.py is not provided in context
# LINK_ONYKAFREE = "https://example.com/link"
# BOT_NAME = "Noxus Bot"

logger = logging.getLogger(__name__)


def escape_markdown_v2(text: Optional[Any]) -> str:
    """Escape characters that Telegram MarkdownV2 treats specially."""
    if text is None:
        return 'N/A'
    chars_to_escape = r'([_*[\]()~`>#+\-=|{}.!])'
    return re.sub(chars_to_escape, r'\\\1', str(text))


def format_bin_lines(bin_data: Optional[Dict[str, Any]], default_text: str = "Unknown") -> Tuple[str, str, str]:
    """Return formatted BIN lines if bin-data is available.

    If the BIN API is disconnected or the gateway does not expose a bin lookup,
    this function falls back to neutral lines instead of crashing the response.
    """
    if not bin_data:
        return (
            fr"\[👾\]({LINK_ONYKAFREE}) *Info:* Unknown \- Unknown",
            fr"\[👾\]({LINK_ONYKAFREE}) *Bank:* `Unknown`",
            fr"\[👾\]({LINK_ONYKAFREE}) *Country:* `Unknown`",
        )

    scheme = str(bin_data.get('Scheme', default_text)).strip() or default_text
    card_type = str(bin_data.get('Type', default_text)).strip().upper() or default_text.upper()
    issuer = str(bin_data.get('Issuer', default_text)).strip() or default_text
    country_data = bin_data.get('Country') or {}
    country_name = str(country_data.get('Name', default_text)).strip() or default_text
    country_code = str(country_data.get('A2', 'Unknown')).strip() or 'Unknown'
    country_emoji = get_country_emoji(country_code)

    info = fr"\[👾\]({LINK_ONYKAFREE}) *Info:* `{scheme}` \- `{card_type}`"
    bank = fr"\[👾\]({LINK_ONYKAFREE}) *Bank:* `{issuer}`"
    country = fr"\[👾\]({LINK_ONYKAFREE}) *Country:* `{country_name}` {country_emoji}"
    return info, bank, country


def get_gateway_loading_sequence(gateway_name: str) -> List[str]:
    """Return a small gateway-aware loading sequence for the user.

    This is a shared example to make the UI appear to 'charge' differently by gateway,
    while keeping all gateways compatible with a generic fallback.
    """
    normalized = gateway_name.lower()
    if 'paypal' in normalized:
        return [
            '⏳ `Connecting to PayPal gateway...`',
            '⏳ `Validating payment details...`',
            '⏳ `[+] POST /v2/checkout/orders/{id}/confirm-payment-source`',
        ]
    if 'stripe' in normalized:
        return [
            '⏳ `Connecting to payment network...`',
            '⏳ `Verifying card with issuer...`',
            '⏳ `Running security authentication...`',
        ]
    if 'braintree' in normalized:
        return [
            '⏳ `[+] POST /merchants/{id}/client_api/v1/payment_methods`',
            '⏳ `[+] POST /merchants/{id}/client_api/v1/payment_methods/{token}/three_d_secure/lookup`',
        ]
    if 'adyen' in normalized:
        return [
            '⏳ `Starting Adyen authentication...`',
            '⏳ `Submitting card checks...`',
            '⏳ `Reading issuer response...`',
        ]
    return [
        '⏳ `Contacting issuing bank...`',
        '⏳ `Checking card status...`',
    ]


def build_response_output(
    gateway_name: str,
    card_data: str,
    start_time: float,
    details: Dict[str, Any]
) -> str:
    """Build a consistent response block for Telegram output.

    This mirrors the style shown in the screenshot:
    gateway title line, card line, status line, response line,
    optional BIN metadata lines, and a processed-by/time footer.
    """
    processing_time = round(time.time() - start_time, 2)

    raw_status = details.get('status', 'Error')
    raw_message = details.get('message', 'Error desconocido')
    final_status, final_response_msg, emoji = categorize_response(raw_status, raw_message)

    other_lines = []
    if gateway_name == "Adyen Charge":
        result_code = details.get('resultCode', 'N/A')
        refusal_reason = details.get('refusalReason', 'N/A')
        psp_reference = details.get('pspReference', 'N/A')
        other_lines.extend([
            fr"\[👾\] *Result Code:* `{escape_markdown_v2(result_code)}`",
            fr"\[👾\] *Refusal Reason:* `{escape_markdown_v2(refusal_reason)}`",
            fr"\[👾\] *PSP Reference:* `{escape_markdown_v2(psp_reference)}`",
        ])
    elif gateway_name == "CyberSource Auth":
        error_info = details.get('errorInformation', {})
        reason_code = error_info.get('reason', 'N/A')
        other_lines.append(fr"\[👾\] *Reason Code:* `{escape_markdown_v2(reason_code)}`")
    elif gateway_name == "Checkout.com Auth":
        response_summary = details.get('response_summary', 'N/A')
        response_code = details.get('response_code', 'N/A')
        other_lines.extend([
            fr"\[👾\] *Summary:* `{escape_markdown_v2(response_summary)}`",
            fr"\[👾\] *Response Code:* `{escape_markdown_v2(response_code)}`",
        ])
    elif gateway_name == "Vantiv Auth":
        response_code = details.get('responseCode', 'N/A')
        other_lines.append(fr"\[👾\] *Response Code:* `{escape_markdown_v2(response_code)}`")

    bin_data = details.get('bin_data') or details.get('bin_info') or details.get('binInfo')
    if bin_data:
        info_line, bank_line, country_line = format_bin_lines(bin_data)
        other_lines.extend([info_line, bank_line, country_line])

    lines = [
        fr"\[👾\] *{BOT_NAME}* \| *{gateway_name}*",
        "━━━━━━━━━━━━",
        fr"\[👾\] *Card:* `{escape_markdown_v2(card_data)}`",
        fr"\[👾\] *Status:* `{escape_markdown_v2(final_status)}! {emoji}`",
        fr"\[👾\] *Response:* `{escape_markdown_v2(final_response_msg)}`",
    ]

    if other_lines:
        lines.append("━━━━━━━━━━━━")
        lines.extend(other_lines)

    lines.extend([
        "━━━━━━━━━━━━",
        fr"\[👾\] *Time:* `{processing_time}s`",
        "━━━━━━━━━━━━",
    ])

    return "\n".join(lines)

def categorize_response(status: str, response_msg: str) -> Tuple[str, str, str]:
    """
    Categoriza la respuesta del gateway en estados más significativos.
    Devuelve (estado_final, mensaje_final, emoji).
    """
    status_lower = status.lower()
    msg_lower = response_msg.lower()

    # 1. LIVE HITS (CVV/CCN - Tarjeta viva, datos incorrectos o riesgo)
    if status_lower == 'ccn' or 'cvv' in msg_lower or 'security code' in msg_lower or "risk" in msg_lower:
        return 'CCN LIVE', '✅ Card is LIVE (CVV/Risk Mismatch)', '✅'

    # 2. LIVE HITS (Fondos/AVS - Tarjeta viva, problemas de fondos o dirección)
    if 'insufficient' in msg_lower or 'funds' in msg_lower or 'avs' in msg_lower:
        return 'LIVE', '✅ Card is LIVE (Insufficient Funds/AVS)', '✅'

    # 3. APPROVED (Éxito total)
    if status_lower == 'approved':
        return 'APPROVED', response_msg, '🍒'

    # 4. DECLINED (Rechazo definitivo)
    return 'DECLINED', response_msg, '👻'

async def send_response_message(
    message: types.Message,
    gateway_name: str,
    card_data: str,
    start_time: float,
    details: Dict[str, Any]
):
    """
    Sends a formatted response message to the user, parsing details from a dictionary.
    The output format is consistent across all gateways.
    """
    response_output = build_response_output(gateway_name, card_data, start_time, details)

    try:
        await message.edit_text(response_output, parse_mode=ParseMode.MARKDOWN_V2)
    except Exception as e:
        logger.error(f"Failed to send formatted response message: {e}", exc_info=True)
        # Fallback to plain text if MarkdownV2 fails
        raw_status = details.get('status', 'Error')
        raw_message = details.get('message', 'Error desconocido')
        final_status, final_response_msg, _ = categorize_response(raw_status, raw_message)
        processing_time = round(time.time() - start_time, 2)
        await message.edit_text(
            f"Resultado: {final_status}\nMensaje: {final_response_msg}\n"
            f"Tiempo: {processing_time}s\n"
            f"Detalles: {json.dumps(details, indent=2)}",
            parse_mode=ParseMode.HTML
        )