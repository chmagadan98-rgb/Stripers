# MASS/mass_paypal_control.py
"""
Handler para el comando de chequeo masivo de PayPal (/mpp).
Utiliza el PayPalClient para una verificación real de la API, con manejo de errores detallado.
"""
import sys
import os
import random
from typing import Tuple, Any, Dict
import logging

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.mass_checker_framework import create_mass_checker_handler
from tools_actions import get_bin_data_sync
from utils.paypal_client import PayPalClient, PayPalAPIError # Assuming PayPalAPIError is defined
from utils.response_classifier import classify_paypal_api_error, FinalStatus
from utils.card_parser import extract_cc_from_text_sync

logger = logging.getLogger(__name__)

def check_paypal_card_sync(cc_formatted: str) -> Tuple[str, str, Dict[str, Any]]:
    """
    Función de verificación síncrona para PayPal usando PayPalClient.
    Esta es la función que se ejecutará en un hilo separado por el mass_checker_framework.
    """
    # 1. Parsear la tarjeta (aunque el framework ya la pasa, es buena práctica)
    card_parts = cc_formatted.split('|')
    if len(card_parts) < 4:
        return "Declined", "Invalid Card Format", {}
    cc, mes, ano, cvv = card_parts

    # 2. Obtener información del BIN para filtrar tarjetas no deseadas.
    bin_data = get_bin_data_sync(cc_formatted[:6])
    bin_level = bin_data.get('Category', 'UNKNOWN').upper() if bin_data else 'UNKNOWN'

    if bin_level in ['PREPAID', 'GIFT']:
        return "Declined", "Payment Method Not Accepted by Gateway", {}

    # 3. Intentar interactuar con la API de PayPal para procesar la tarjeta.
    try:
        # Instanciar el cliente. Esto valida las credenciales al obtener el token.
        paypal = PayPalClient()
        
        # --- Pre-validación de datos de tarjeta (ejemplo) ---
        # These checks can prevent unnecessary API calls for obvious errors.
        if not (1 <= int(mes) <= 12):
            return "Declined", "invalid_expiry_date: El mes de vencimiento no es válido.", {}
        # Add more pre-validation for year, etc.

        # --- Realizar la llamada a la API de PayPal para crear y capturar la orden ---
        # Refactor: Using the hypothetical create_order_with_card for direct card validation
        
        # Ensure year is in 4-digit format for PayPal API
        full_ano = f"20{ano}" if len(ano) == 2 else ano

        order = paypal.create_order_with_card(
            amount="0.10", # Small amount for validation
            currency="USD",
            card_details={
                'number': cc,
                'expiry_month': mes,
                'expiry_year': full_ano,
                'cvv': cvv
            },
            idempotency_key=f"mass_chk_{random.randint(100000, 999999)}" # Unique key for idempotency
        )
        
        # If the order is successfully created, it implies the card was accepted.
        # PayPal's Orders API typically returns 'CREATED' status for a successful order creation.
        # For a card checker, this can be interpreted as 'Approved' for validation purposes.
        if order and order.get('id') and order.get('status') in ['CREATED', 'SAVED', 'APPROVED', 'COMPLETED']:
            return FinalStatus.LIVE.value, f"Order created: {order['id']} - Status: {order['status']}", {"order_id": order['id'], "status": order['status']}
        else:
            return FinalStatus.DIE.value, f"PayPal API Error: Order not created or unexpected status: {order.get('status', 'N/A')}", {"order_details": order}

    except PayPalAPIError as e:
        # Utilizar el nuevo clasificador centralizado
        status, message = classify_paypal_api_error(e)
        logger.warning(f"PayPal API Error ({e.error_details.get('name', 'N/A')}): {message}")
        return status, message, e.error_details
    except Exception as e: # Catch any other unexpected errors
        logger.exception(f"Unexpected error in check_paypal_card_sync: {e}")
        return "Error", f"Error inesperado: {str(e)}", {}

REQUIRED_PLAN_MPP = ['OWNER', 'CO OWNER', 'DEV', 'SELLER', 'VIP']

router = create_mass_checker_handler(
    command="mpp",
    gateway_name="PayPal",
    checker_function=check_paypal_card_sync,
    required_plan=REQUIRED_PLAN_MPP
)