# utils/bin_api.py
"""Single asynchronous BIN information client used by all bot modules."""
import aiohttp
import logging
import re
from utils import proxy_rotator

logger = logging.getLogger('noxus_bin_api')

from typing import Union

async def get_bin_info(bin_number: str) -> Union[dict, None]:
    """Return BIN data from HandyAPI or ``None`` on failure.
    ``bin_number`` must be a 6‑digit string.
    """
    cleaned_bin = re.sub(r"\D", "", str(bin_number))[:6]
    if len(cleaned_bin) != 6:
        return None

    url = f"https://data.handyapi.com/bin/{cleaned_bin}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    proxy = proxy_rotator.get_next_proxy()
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url, headers=headers, proxy=proxy) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get('Status') == 'SUCCESS':
                        return data
                return None
    except Exception as e:
        logger.error(f"Error fetching BIN info: {e}")
        return None


# Legacy name used by gateway modules.
get_bin_data_gen = get_bin_info
