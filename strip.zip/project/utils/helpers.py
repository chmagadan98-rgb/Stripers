# utils/helpers.py
"""Utility helpers shared across services.
Currently provides:
- ``get_country_emoji`` – convert ISO‑A2 country code to flag emoji.
"""

def get_country_emoji(country_code: str) -> str:
    """Return the flag emoji for a two‑letter country code.
    If the code is missing or invalid, returns a white flag.
    """
    if not country_code or country_code == "N/A":
        return "🏳️"
    offset = 127397
    try:
        return "".join(chr(ord(ch) + offset) for ch in country_code.upper())
    except Exception:
        return "🏳️"
