# MASS/mass_checkout_com_control.py
"""
Handler para el comando de chequeo masivo de Checkout.com (/mcko).
Utiliza el mass_checker_framework para procesar un archivo de tarjetas
de forma concurrente.
"""
import os
import sys
import logging
from typing import Tuple, Dict, Any

# Añadir el directorio raíz al path para permitir importaciones absolutas
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.mass_checker_framework import create_mass_checker_handler
from utils.checkout_com_client import CheckoutComClient, CheckoutComAPIError
from utils.response_classifier import classify_checkout_com_response

logger = logging.getLogger(__name__)

async def check_checkout_com_card_async(cc_formatted: str) -> Tuple[str, str, Dict[str, Any]]:
    """
    Función de verificación asíncrona para Checkout.com.
    Esta corutina será ejecutada concurrentemente por el mass_checker_framework.
    """
    card_parts = cc_formatted.split('|')
    if len(card_parts) < 4:
        return "Declined", "Invalid Card Format", {}
    cc, mes, ano, cvv = card_parts

    try:
        client = CheckoutComClient()
        result = await client.authorize_card("1.00", cc, mes, ano, cvv)
        
        status, message = classify_checkout_com_response(result)
        return status, message, result

    except CheckoutComAPIError as e:
        logger.warning(f"Checkout.com API Error en chequeo masivo: {e}")
        return "Error", f"Checkout.com API Error: {str(e)}", e.error_details
    except Exception as e:
        logger.error(f"Error inesperado en check_checkout_com_card_async: {e}", exc_info=True)
        return "Error", f"Unexpected Error: {str(e)}", {}

REQUIRED_PLAN_MCKO = ['PREMIUM', 'VIP', 'OWNER', 'CO OWNER', 'DEV', 'SELLER']

router = create_mass_checker_handler(
    command="mcko",
    gateway_name="Checkout.com",
    checker_function=check_checkout_com_card_async,
    required_plan=REQUIRED_PLAN_MCKO
)