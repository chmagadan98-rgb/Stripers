"""
Proxy Rotator Utility for Noxus Elite Bot.
Provides automatic rotation of proxies for HTTP requests.
"""
import itertools
import random
from typing import Optional, Iterator

from bot_info import PROXIES

# Global proxy cycler (round-robin)
_proxy_cycler: Optional[Iterator[str]] = None
if PROXIES:
    _proxy_cycler = itertools.cycle(PROXIES)

def get_next_proxy() -> Optional[str]:
    """
    Return the next proxy in the rotation cycle.
    Returns None if no proxies are configured.
    """
    global _proxy_cycler

    if _proxy_cycler is None:
        return None
    try:
        return next(_proxy_cycler)
    except StopIteration:
        # Reset cycler if exhausted (should not happen with cycle)
        _proxy_cycler = itertools.cycle(PROXIES)
        return next(_proxy_cycler)

def get_random_proxy() -> Optional[str]:
    """
    Return a random proxy from the list.
    Returns None if no proxies are configured.
    """
    if not PROXIES:
        return None
    return random.choice(PROXIES)

def get_proxy_dict(proxy: Optional[str] = None) -> Optional[dict]:
    """
    Convert a proxy string to a dict suitable for requests library.
    If proxy is None, returns None.
    """
    if proxy is None:
        return None
    # Assume same proxy for http and https
    return {"http": proxy, "https": proxy}

def get_aiohttp_proxy(proxy: Optional[str] = None) -> Optional[str]:
    """
    Return proxy string for aiohttp (same as input).
    """
    return proxy