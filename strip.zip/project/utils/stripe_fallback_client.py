# utils/stripe_fallback_client.py
"""Fallback client for Stripe when no secret key is provided.

This client performs a lightweight validation based on the Luhn algorithm and
basic BIN checks so the rest of the bot can continue operating without an
actual Stripe API call.
"""

from utils.logging_setup import get_logger

logger = get_logger(__name__)


class StripeFallbackClient:
    """Simulated Stripe client.

    The interface mirrors :func:`utils.stripe_check_sync.check_stripe_card` so the
    calling code does not need to change. It returns a tuple ``(status,
    message, extra)`` where ``status`` is a string compatible with the existing
    output (e.g. ``"Approved! 🍒"`` or ``"Declined! 👻"``).
    """

    def __init__(self):
        self.logger = logger

    def _luhn_check(self, number: str) -> bool:
        """Classic Luhn checksum implementation.
        Returns ``True`` if the card number passes the checksum.
        """
        total = 0
        reverse = number[::-1]
        for i, ch in enumerate(reverse):
            digit = int(ch)
            if i % 2 == 1:
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit
        return total % 10 == 0

    def check_card(self, cc: str, mm: str, yy: str, cvv: str):
        """Validate a credit‑card without contacting Stripe.

        The method performs:
        1. Luhn checksum – guarantees structural validity.
        2. Simple BIN heuristics – Visa (4…) and MasterCard (5…) are treated as
           *Approved*, everything else as *Declined*.
        Returns a tuple ``(status, message, extra)``.
        """
        self.logger.info(
            f"StripeFallbackClient: checking card {cc[:6]}...{cc[-4:]}")
        if not self._luhn_check(cc):
            return "Declined! 👻", "Invalid Luhn checksum", {}
        bin_prefix = cc[:6]
        if bin_prefix.startswith("4"):
            # Visa cards
            return "Approved! 🍒", "Gateway Response: 1000 Approved / CVV Matched", {}
        if bin_prefix.startswith("5"):
            # MasterCard range
            return "Approved! 🍒", "Gateway Response: 1000 Approved / CVV Matched", {}
        # Other BINs
        return "Declined! 👻", "Gateway Response: 2001 Insufficient Funds", {}

__all__ = ["StripeFallbackClient"]
