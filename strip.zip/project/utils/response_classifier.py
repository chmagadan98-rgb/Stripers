"""Shared response classification helpers for gateway adapters."""
from enum import Enum
from typing import Any, Dict, Tuple


class FinalStatus(str, Enum):
    LIVE = "LIVE"
    DIE = "DIE"
    CCN = "CCN"
    ERROR = "ERROR"


def _classify(result: Any) -> Tuple[str, str]:
    if isinstance(result, Exception):
        return FinalStatus.ERROR.value, str(result)
    if not isinstance(result, dict):
        return FinalStatus.ERROR.value, str(result)

    status = str(result.get("status", result.get("result", ""))).lower()
    message = str(result.get("message", result.get("error", result.get("msg", ""))))
    combined = f"{status} {message}".lower()

    if any(word in combined for word in ("insufficient", "cvv", "security code", "risk", "avs")):
        return FinalStatus.CCN.value, message or "Live response"
    if any(word in combined for word in ("approved", "authorised", "authorized", "success", "live", "charged", "completed")):
        return FinalStatus.LIVE.value, message or "Approved"
    if any(word in combined for word in ("error", "exception", "timeout")):
        return FinalStatus.ERROR.value, message or "Gateway error"
    return FinalStatus.DIE.value, message or "Declined"


def classify_stripe_response(result: Dict[str, Any]):
    return _classify(result)


def classify_braintree_response(result: Dict[str, Any]):
    return _classify(result)


def classify_paypal_api_error(error: Exception):
    return FinalStatus.DIE.value, str(error)


def classify_vantiv_response(result: Dict[str, Any]):
    return _classify(result)


def classify_bambora_response(result: Dict[str, Any]):
    return _classify(result)


def classify_checkout_com_response(result: Dict[str, Any]):
    return _classify(result)


def classify_cybersource_response(result: Dict[str, Any]):
    return _classify(result)


def classify_authorizenet_response(result: Dict[str, Any]):
    return _classify(result)
