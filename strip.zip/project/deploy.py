# deploy_vps.py - Sube el proyecto completo al VPS y reinicia el bot (Cleaned & Blinded)
"""
deploy_vps.py - Sube el proyecto completo al VPS y reinicia el bot
"""
import os
import paramiko
import time

HOST = '108.174.155.207'
PORT = 22022
USER = 'root'
PWD  = 'M@gadan1998.'
PWD  = os.getenv('VPS_PASS') # 'M@gadan1998.'

LOCAL_BASE  = r'c:\Users\Adm\Documents\a\Noxus_API_Backend'
REMOTE_BASE = '/root/Noxus'

BANNERS_LOCAL  = r'c:\Users\Adm\Documents\a\Noxus_Banners'
BANNERS_REMOTE = '/root/Noxus_Banners'

SKIP_DIRS = {'.git', '__pycache__', 'venv', '.gemini', '.env', 'node_modules'}

def make_remote_dirs(sftp, remote_path):
    parts = remote_path.split('/')
    current = ''
    for part in parts:
        if not part:
            current = '/'
            continue
        current = current.rstrip('/') + '/' + part
        try:
            sftp.stat(current)
        except IOError:
            try:
                sftp.mkdir(current)
            except Exception:
                pass

def upload_tree(sftp, local_base, remote_base, extensions=None):
    for root, dirs, files in os.walk(local_base):
        # prune ignored dirs in-place
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel = os.path.relpath(root, local_base).replace('\\', '/')
        remote_dir = remote_base if rel == '.' else remote_base + '/' + rel
        make_remote_dirs(sftp, remote_dir)
        for f in files:
            if extensions and not any(f.endswith(e) for e in extensions):
                continue
            local_path  = os.path.join(root, f)
            remote_path = remote_dir + '/' + f
            sftp.put(local_path, remote_path)
            print(f'  [UP] {remote_path}')

def fix_type_hints_py39(local_base):
    """Replace Python 3.10+ union type hints with Optional[] for Python 3.9 compat."""
    import re
    pattern = re.compile(r'->\s*([\w\[\], ]+)\s*\|\s*None')
    replacement = r'-> Optional[\1]'

    for root, dirs, files in os.walk(local_base):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if not f.endswith('.py'):
                continue
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8') as fh:
                content = fh.read()

            new_content = content
            # Replace "-> Optional[X ]" with "-> Optional[X]"
            new_content = pattern.sub(replacement, new_content)
            # Also handle bare "Optional[str]", "Optional[dict]" used in annotations
            new_content = re.sub(r'\b(\w+)\s*\|\s*None\b', r'Optional[\1]', new_content)

            if new_content != content:
                # Add Optional import if not already there
                if 'from typing import' in new_content:
                    if 'Optional' not in new_content:
                        new_content = re.sub(
                            r'from typing import (.*)',
                            r'from typing import \1, Optional',
                            new_content, count=1
                        )
                elif 'import typing' not in new_content:
                    new_content = 'from typing import Optional\n' + new_content

                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(new_content)
                print(f'  [FIXED] {f}')

# ─── MAIN ────────────────────────────────────────────────────────────────────

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

print('=' * 60)
print('NOXUS DEPLOY -> VPS', HOST)
print('=' * 60)


print('\n[1/4] Fixing Python 3.9 type hints locally...')
fix_type_hints_py39(LOCAL_BASE)

print('\n[2/4] Connecting to VPS...')
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
if not PWD:
    print('[FAIL] La variable de entorno VPS_PASS no está definida.')
    sys.exit(1)

ssh.connect(HOST, port=PORT, username=USER, password=PWD, timeout=15)
print('     Connected [OK]')

print('\n[2b] Stopping noxus-bot.service before uploading...')
ssh.exec_command('systemctl stop noxus-bot.service 2>/dev/null || true')
time.sleep(1)

sftp = ssh.open_sftp()

print('\n[3/4] Uploading project files...')
upload_tree(sftp, LOCAL_BASE, REMOTE_BASE, extensions=['.py', '.txt', '.env', '.json', '.cfg'])

print('\n[3b] Uploading banners...')
if os.path.exists(BANNERS_LOCAL):
    make_remote_dirs(sftp, BANNERS_REMOTE)
    for img in os.listdir(BANNERS_LOCAL):
        if img.lower().endswith(('.jpg', '.jpeg', '.png')):
            local_img  = os.path.join(BANNERS_LOCAL, img)
            remote_img = BANNERS_REMOTE + '/' + img
            sftp.put(local_img, remote_img)
            print(f'  [UP] {img}')
sftp.close()

print('\n[4/4] Restarting bot on VPS via systemd...')
restart_cmd = (
    'systemctl daemon-reload'
    ' && systemctl restart noxus-bot.service'
    ' && sleep 3'
    ' && systemctl status noxus-bot.service --no-pager -l'
    ' && echo "--- JOURNALCTL LOGS ---"'
    ' && journalctl -u noxus-bot.service --no-pager -n 20'
)
_, stdout, stderr = ssh.exec_command(restart_cmd)
output = stdout.read().decode('utf-8', errors='ignore')
errors = stderr.read().decode('utf-8', errors='ignore')
ssh.close()

# Safe print to console (avoid encoding issues)
cleaned_output = output.replace('\u25cf', '[*]').replace('\u25cb', '[ ]')
print(cleaned_output)

if errors:
    print('STDERR:', errors)

if 'failed' in output.lower() or 'Error' in output or 'Traceback' in output:
    print('\n[ERROR] Bot failed to start under systemd -- check logs above.')
else:
    print('\n[OK] Bot is UP on the VPS under systemd! Send /cmds in Telegram to verify.')