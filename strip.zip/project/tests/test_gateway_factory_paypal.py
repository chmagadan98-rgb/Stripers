import os
os.environ.setdefault("PAYPAL_CLIENT_ID", "client")
os.environ.setdefault("PAYPAL_CLIENT_SECRET", "secret")
os.environ.setdefault("PAYPAL_ENV", "sandbox")

from bot.utils.gateway_factory import GatewayFactory


def test_get_paypal_gateway_returns_adapter_with_check_card():
    gateway = GatewayFactory.get_gateway("paypal")
    assert gateway is not None
    assert hasattr(gateway, "check_card")
