from bot.utils.gateway_factory import GatewayFactory


def test_get_braintree_gateway_returns_adapter_with_check_card():
    gateway = GatewayFactory.get_gateway("braintree")
    assert gateway is not None
    assert hasattr(gateway, "check_card")
    assert hasattr(gateway, "auth")
    assert hasattr(gateway, "charge")
