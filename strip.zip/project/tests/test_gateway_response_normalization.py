import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from bot.routers.gate_handler import normalize_gateway_response


def test_normalize_gateway_response_handles_non_dict_response():
    result = normalize_gateway_response(None)
    assert isinstance(result, dict)
    assert result['status'] == 'DECLINED'
    assert 'invalid response' in result['msg'].lower()
