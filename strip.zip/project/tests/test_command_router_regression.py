from pathlib import Path
import importlib


def test_aiogram_bot_registers_missing_amazon_routers():
    text = Path('bot/aiogram_bot.py').read_text(encoding='utf-8')
    assert '("charge", "bot.routers.charge")' in text
    assert '("amazon_lookup_handler", "bot.routers.amazon_lookup_handler")' in text


def test_tool_router_uses_gencookie_command_import():
    module = importlib.import_module('bot.routers.tools')
    assert hasattr(module, 'gencookie_command')
