import asyncio
from bot.utils.gateway_factory import GatewayFactory

gw = GatewayFactory.get_gateway('paypal')

async def main():
    try:
        result = await gw.check_card('4111111111111111', '12', '2030', '123')
        print(result)
    except Exception as exc:
        import traceback
        traceback.print_exc()

asyncio.run(main())
