import unittest
from utils.response_utils import build_response_output


class ResponseUtilsOutputTests(unittest.TestCase):
    def test_build_response_output_includes_expected_sections(self):
        details = {
            "status": "APPROVED",
            "message": "Approved",
        }

        output = build_response_output(
            gateway_name="Stripe Auth",
            card_data="4111111111111111|01|30|123",
            start_time=0,
            details=details,
        )

        self.assertIn("*Stripe Auth*", output)
        self.assertIn("*Card:*", output)
        self.assertIn("*Status:*", output)
        self.assertIn("*Response:*", output)
        self.assertIn("*Time:*", output)
        self.assertIn("approved!", output.lower())
        self.assertIn("approved", output.lower())


if __name__ == "__main__":
    unittest.main()
