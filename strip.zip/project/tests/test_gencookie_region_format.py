from gencookie import gencookie_command


def test_gencookie_mx_alias_maps_to_mexico_output():
    section = gencookie_command("mex")
    assert "MÉXICO" in section or "MEXICO" in section
    assert "x-main" in section and "x-amz-captcha-2" in section


def test_gencookie_usa_alias_maps_to_usa_output():
    section = gencookie_command("usa")
    assert "USA" in section
    assert "at-main" in section and "sst-main" in section
