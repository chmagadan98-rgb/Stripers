# patch_messages.py - Replace technical log messages in gate files (Cleaned & Blinded)
"""
patch_messages.py - Replace all technical log messages in gate files
with professional, non-revealing status messages.
"""
import os
import re

BASE = r'c:\Users\Adm\Documents\a\Noxus_API_Backend'

# Map: (file_relative_path, [(old_text, new_text), ...])
PATCHES = {

    # ── AUTH GATES ──────────────────────────────────────────────────────────

    'AUTH/stripe_control.py': [
        ('f"\\u23f3 `[+] POST /v1/setup_intents ({fake_req_id})`"',
         '"\\u23f3 `Connecting to payment network...`"'),
        ('f"\\u23f3 `[+] POST /v1/setup_intents/{fake_si_id}/confirm`"',
         '"\\u23f3 `Verifying card with issuer...`"'),
        ('"\\u23f3 `[+] POST /v1/payment_methods (Tokenizing card)`"',
         '"\\u23f3 `Running security authentication...`"'),
    ],

    'AUTH/braintree_control.py': [
        ('"⏳ `[+] POST /merchants/{id}/client_token`"',
         '"⏳ `Establishing secure session...`"'),
        ('"⏳ `[+] POST /v1/payment_methods/credit_cards`"',
         '"⏳ `Validating card information...`"'),
        ('"⏳ `[+] POST /merchants/{id}/transactions (3D Secure)`"',
         '"⏳ `Authenticating with card network...`"'),
        ('"⏳ `[+] GET /merchants/{id}/transactions/{txn_id}`"',
         'f"⏳ `Finalizing authorization...`"'),
    ],

    'AUTH/paypal_control.py': [
        ('"⏳ `[+] POST /v1/oauth2/token (200 OK)`"',
         '"⏳ `Connecting to payment processor...`"'),
        ('"⏳ `[+] POST /v2/checkout/orders (Processing)`"',
         '"⏳ `Validating payment details...`"'),
        ('"⏳ `[+] POST /v2/checkout/orders/{id}/confirm-payment-source`"',
         '"⏳ `Verifying card with issuer...`"'),
        ('"⏳ `[+] GET /v2/checkout/orders/{id} (3DS Verify)`"',
         '"⏳ `Running fraud check...`"'),
    ],

    'AUTH/stripe_premium_control.py': [
        ('"⏳ `[+] POST /v1/setup_intents`"',
         '"⏳ `Connecting to payment network...`"'),
        ('"⏳ `[+] POST /v1/setup_intents/confirm`"',
         '"⏳ `Verifying card with issuer...`"'),
        ('"⏳ `[+] 3DS: Stripe Premium Bypass`"',
         '"⏳ `Running security authentication...`"'),
    ],

    'AUTH/stripe2_auth_control.py': [
        ('"⏳ `[+] POST /v2/tokens`"',
         '"⏳ `Connecting to payment network...`"'),
        ('"⏳ `[+] POST /v2/charges`"',
         '"⏳ `Validating card information...`"'),
        ('"⏳ `[+] Stripe Token Resolving...`"',
         '"⏳ `Running security authentication...`"'),
    ],

    'AUTH/moneris_control.py': [
        ('"⏳ `[+] POST /v1/moneris_profiles`"',
         '"⏳ `Establishing secure session...`"'),
        ('"⏳ `[+] POST /v1/moneris_verify`"',
         '"⏳ `Verifying card details...`"'),
        ('"⏳ `[+] Moneris 3DS Auth...`"',
         '"⏳ `Authenticating with card network...`"'),
    ],

    'AUTH/bambora_auth_control.py': [
        ('"⏳ `[+] POST /v1/profiles`"',
         '"⏳ `Establishing secure session...`"'),
        ('"⏳ `[+] POST /v1/payments`"',
         '"⏳ `Validating payment details...`"'),
        ('"⏳ `[+] Processing Bambora Response`"',
         '"⏳ `Authenticating with card network...`"'),
    ],

    'AUTH/b3_vbv_control.py': [
        ('"⏳ `[+] POST /v1/b3_vbv_init`"',
         '"⏳ `Initializing security check...`"'),
        ('"⏳ `[+] POST /v1/b3_vbv_auth`"',
         '"⏳ `Contacting issuing bank...`"'),
        ('"⏳ `[+] 3DS: Challenge Flow...`"',
         '"⏳ `Running fraud detection...`"'),
    ],

    'AUTH/b3_premium_control.py': [
        ('"⏳ `[+] POST /v1/b3_auth`"',
         '"⏳ `Initializing security check...`"'),
        ('"⏳ `[+] POST /v1/b3_verify`"',
         '"⏳ `Contacting issuing bank...`"'),
        ('"⏳ `[+] 3DS: B3 Network Check`"',
         '"⏳ `Running fraud detection...`"'),
    ],

    # ── CHARGE GATES ────────────────────────────────────────────────────────

    'CHARGE/stripe_53_control.py': [
        ('"⏳ `[+] POST /v1/tokens (req_xxx)`"',
         '"⏳ `Connecting to payment network...`"'),
        ('"⏳ `[+] POST /v1/charges (Processing)`"',
         '"⏳ `Processing charge...`"'),
        ('"⏳ `[+] 3DS: Attempting friction-less flow`"',
         '"⏳ `Running security authentication...`"'),
    ],

    'CHARGE/stripe_1_control.py': [
        ('"⏳ `[+] POST /v1/payment_methods (req_xxx)`"',
         '"⏳ `Connecting to payment network...`"'),
        ('"⏳ `[+] POST /v1/payment_intents/{id}/confirm`"',
         '"⏳ `Verifying card with issuer...`"'),
        ('"⏳ `[+] 3DS: Attempting friction-less flow`"',
         '"⏳ `Running security authentication...`"'),
    ],

    'CHARGE/shopify_control.py': [
        ('"⏳ `[+] POST /cart/add.js (200 OK)`"',
         '"⏳ `Adding to cart...`"'),
        ('"⏳ `[+] POST /checkout.json (Processing)`"',
         '"⏳ `Processing order...`"'),
        ('"⏳ `[+] Stripe Tokenization: req_xxx...`"',
         '"⏳ `Verifying card with issuer...`"'),
        ('"⏳ `[+] 3DS: Attempting friction-less auth`"',
         '"⏳ `Running security authentication...`"'),
    ],

    'CHARGE/paypal_charge_control.py': [
        ('"⏳ `[+] POST /v2/checkout/orders`"',
         '"⏳ `Connecting to payment processor...`"'),
        ('"⏳ `[+] Resolving token...`"',
         '"⏳ `Validating payment details...`"'),
        ('"⏳ `[+] POST /v2/checkout/orders/{id}/capture`"',
         '"⏳ `Processing authorization...`"'),
    ],

    'CHARGE/blackbaund_control.py': [
        ('"⏳ `[+] POST /auth/v1/tokens`"',
         '"⏳ `Establishing secure session...`"'),
        ('"⏳ `[+] POST /payments/v1/authorize`"',
         '"⏳ `Processing charge...`"'),
        ('"⏳ `[+] Processing BB_Response`"',
         '"⏳ `Verifying authorization...`"'),
    ],

    'CHARGE/CCN/payflow_control.py': [
        ('"⏳ `[+] POST /v1/payflow/auth`"',
         '"⏳ `Connecting to payment processor...`"'),
        ('"⏳ `[+] POST /v1/payflow/capture`"',
         '"⏳ `Processing authorization...`"'),
        ('"⏳ `[+] Processing Payflow Network...`"',
         '"⏳ `Verifying card details...`"'),
    ],

    'CHARGE/CCN/nmi_control.py': [
        ('"⏳ `[+] POST /api/transact.php`"',
         '"⏳ `Connecting to payment processor...`"'),
        ('"⏳ `[+] POST /api/transact.php (Capture)`"',
         '"⏳ `Processing authorization...`"'),
        ('"⏳ `[+] NMI: Resolving Token...`"',
         '"⏳ `Verifying card details...`"'),
    ],
}


def patch_file(rel_path, replacements):
    full_path = os.path.join(BASE, rel_path.replace('/', os.sep))
    if not os.path.exists(full_path):
        print(f'  [SKIP] Not found: {rel_path}')
        return

    with open(full_path, 'r', encoding='utf-8') as f:
        content = f.read()

    original = content
    for old, new in replacements:
        content = content.replace(old, new)

    if content != original:
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'  [OK] {rel_path}')
    else:
        print(f'  [UNCHANGED] {rel_path}')


print('Patching all gate messages...')
for rel, patches in PATCHES.items():
    patch_file(rel, patches)
print('Done.')