# general_info.py - Compatibility module (Cleaned & Blinded)
"""Compatibility module required by bot/bot.py.

The VPS instance is missing `general_info.py`, which causes:
    ModuleNotFoundError: No module named 'general_info'

This file provides minimal implementations so the bot can start.

Note: These functions can be replaced with your original logic if you later
restore the real module.
"""

from __future__ import annotations

from typing import Any, Optional

from telegram import Update
from telegram.ext import ContextTypes


async def send_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handler for /start."""
    if not update.message:
        return
    await update.message.reply_text(
        "👋 Bienvenido. El bot está en línea, pero algunas funciones administrativas pueden requerir configuración adicional."
    )


async def handle_me_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: Optional[dict] = None) -> None:
    """Handler for /me (stub)."""
    if update.message:
        await update.message.reply_text("🧾 Tu perfil (stub).")


async def handle_cmds_command(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: Optional[dict] = None) -> None:
    """Handler for /cmds or /c (stub)."""
    if update.message:
        await update.message.reply_text(
            "📚 Lista de comandos (stub):\n/start\n/me\n/cmds"
        )


async def manage_user_in_db(*args: Any, **kwargs: Any) -> None:
    """Stub used by other parts of the bot (no-op)."""
    return None


async def callback_inline(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Callback query handler used by bot/bot.py (stub)."""
    # Keep safe: just answer the callback.
    cbq = update.callback_query
    if cbq is not None:
        try:
            await cbq.answer()
        except Exception:
            pass

        try:
            await cbq.edit_message_text("✅ Acción recibida (stub).")
        except Exception:
            # If editing fails, ignore.
            pass