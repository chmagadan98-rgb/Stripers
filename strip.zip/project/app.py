from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from flask import Flask, jsonify, redirect, render_template, request, url_for

from arxiv_service import (
    CATEGORY_DEFS,
    CATEGORY_GROUPS,
    ArxivRequestError,
    _format_sort_label,
    get_article_by_id,
    get_recent_by_category,
    search_arxiv,
)

app = Flask(__name__)
logger = logging.getLogger("paperatlas")

SORT_OPTIONS = {
    "relevance": "Relevancia",
    "submittedDate": "Fecha de envío",
    "lastUpdatedDate": "Fecha de actualización",
}


@app.get("/")
def index():
    examples = [
        "transformers for scientific discovery",
        "graph neural networks",
        "causal inference",
        "large language models",
    ]
    return render_template(
        "index.html",
        examples=examples,
        categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
    )


@app.get("/search")
def search_page():
    query = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    sort_by = request.args.get("sort", "relevance").strip() or "relevance"
    page = max(1, int(request.args.get("page", "1") or 1))
    max_results = 10

    if sort_by not in SORT_OPTIONS:
        sort_by = "relevance"

    try:
        data = search_arxiv(
            query=query,
            category=category or None,
            page=page,
            max_results=max_results,
            sort_by=sort_by,
        )
        total_pages = max(1, (data.get("total", 0) + max_results - 1) // max_results)
    except ValueError as exc:
        return render_template(
            "search.html",
            error_message=str(exc),
            query=query,
            category=category,
            sort_by=sort_by,
            page=page,
            items=[],
            categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
            total_pages=1,
            page_title="Búsqueda",
        ), 400
    except ArxivRequestError as exc:
        return render_template(
            "search.html",
            error_message=str(exc),
            query=query,
            category=category,
            sort_by=sort_by,
            page=page,
            items=[],
            categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
            total_pages=1,
            page_title="Búsqueda",
        ), 503

    items = data.get("items", [])
    return render_template(
        "search.html",
        items=items,
        query=query,
        category=category,
        sort_by=sort_by,
        page=page,
        total=data.get("total", len(items)),
        pages=total_pages,
        categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
        active_sort_label=_format_sort_label(sort_by),
        page_title="Resultados de búsqueda",
    )


@app.get("/category/<category_code>")
def category_page(category_code: str):
    category = category_code.strip()
    if category not in CATEGORY_DEFS:
        return redirect(url_for("index"))

    try:
        data = get_recent_by_category(category, max_results=10)
    except ValueError as exc:
        return render_template("search.html", error_message=str(exc), items=[], categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]), page_title="Categoría"), 400
    except ArxivRequestError as exc:
        return render_template("search.html", error_message=str(exc), items=[], categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]), page_title="Categoría"), 503

    return render_template(
        "search.html",
        items=data.get("items", []),
        query="",
        category=category,
        sort_by="submittedDate",
        page=1,
        total=data.get("total", len(data.get("items", []))),
        pages=1,
        categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
        page_title=f"{CATEGORY_DEFS[category]} ({category})",
        is_category_view=True,
    )


@app.get("/article/<article_id>")
def article_page(article_id: str):
    try:
        article = get_article_by_id(article_id)
    except ArxivRequestError as exc:
        return render_template("article.html", error_message=str(exc), article=None, categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0])), 503

    if not article:
        return render_template(
            "article.html",
            error_message="No se encontró ese artículo en arXiv.",
            article=None,
            categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
        ), 404

    related = []
    categories = article.get("categories", [])
    if categories:
        primary = categories[0]
        try:
            related_response = search_arxiv(query="", category=primary, page=1, max_results=3, sort_by="submittedDate")
            related = related_response.get("items", [])
        except (ArxivRequestError, ValueError):
            related = []

    return render_template(
        "article.html",
        article=article,
        categories=sorted(CATEGORY_DEFS.items(), key=lambda item: item[0]),
        related=related,
        category_groups=CATEGORY_GROUPS,
    )


@app.get("/api/search")
def api_search():
    query = request.args.get("q", "")
    category = request.args.get("category", "")
    sort_by = request.args.get("sort", "relevance")
    page = max(1, int(request.args.get("page", "1") or 1))

    try:
        payload = search_arxiv(query=query, category=category or None, page=page, max_results=10, sort_by=sort_by)
        return jsonify(payload)
    except (ArxivRequestError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 400 if isinstance(exc, ValueError) else 503


@app.get("/health")
def health_check():
    return jsonify({"status": "ok", "service": "PaperAtlas"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)