# MASS.py - Compatibility shim (Cleaned & Blinded)
"""Compatibility shim for legacy `import mass` and `from mass ...` imports.

This project uses uppercase package names in several places, while the actual source tree
contains the lowercase directory `mass`. We alias that package here so both forms resolve.
"""

import os

_module_dir = os.path.join(os.path.dirname(__file__), "mass")
if not os.path.isdir(_module_dir):
    raise ModuleNotFoundError("The legacy uppercase MASS package requires the lowercase 'mass' directory to exist.")

__path__ = [_module_dir]

# Re-export the real implementation surface from the lowercase package.
from mass import *  # noqa: F401,F403