# check_vps.py - VPS remote diagnostic and runner script (Cleaned & Blinded)
import paramiko
import sys

def main():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('108.174.155.207', port=22022, username='root', password='M@gadan1998.')
    
    # Eliminar cache de compilación vieja del VPS
    ssh.exec_command('rm -rf /root/Noxus/bot/__pycache__')
    ssh.exec_command('rm -rf /root/Noxus/bot/routers/__pycache__')
    ssh.exec_command('rm -rf /root/Noxus/bot/middlewares/__pycache__')
    ssh.exec_command('rm -rf /root/Noxus/__pycache__')
    
    # Imprimir información del entorno de ejecución de Python
    stdin, stdout, stderr = ssh.exec_command('which python3 && python3 -c "import sys; print(sys.path); print(sys.executable)"')
    print("VPS PYTHON PATHS:\n", stdout.read().decode())
    
    # Instalar requerimientos faltantes en el VPS de forma síncrona
    stdin, stdout, stderr = ssh.exec_command('python3 -m pip install -r /root/Noxus/requirements.txt')

    raw_out = stdout.read().decode('utf-8', errors='ignore')
    print("PIP INSTALL OUTPUT:")
    try:
        print(raw_out)
    except Exception:
        print(raw_out.encode('ascii', errors='ignore').decode('ascii'))
    
    # Iniciar bot de forma limpia y capturar salida
    cmd = 'cd /root/Noxus && python3 -m bot.bot 2>&1'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    
    raw_bot_out = stdout.read().decode('utf-8', errors='ignore')
    print("OUTPUT (DIRECT RUN):")
    try:
        print(raw_bot_out)
    except Exception:
        print(raw_bot_out.encode('ascii', errors='ignore').decode('ascii'))

    # Listar procesos
    stdin, stdout, stderr = ssh.exec_command('ps aux | grep python | grep -v grep')
    print("RUNNING PROCESSES:\n", stdout.read().decode())
    
    ssh.close()

if __name__ == '__main__':
    main()