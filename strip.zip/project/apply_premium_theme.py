import os
from utils.logging_setup import get_logger
logger = get_logger(__name__)
import sys
import argparse
from utils.logging_setup import get_logger
logger = get_logger(__name__)

# Mapeo de emojis del tema único de la aplicación (Pac-Man)
replacements = {
    # Prefix principal de menús y respuestas
    "[✫]": "[👾]",
    # Estados de Gateways
    "ON✅": "ON 🟡",
    "OFF❌": "OFF 👻",
    "MAINT ⚠️": "MAINT 👾",
    "ONLINE 🟢": "ONLINE 🟡",
    "OFFLINE 🔴": "OFFLINE 👻",
    # Checkers Status y Generales
    "Approved! ✅": "Approved! 🍒",
    "Declined! ❌": "Declined! 👻",
    # Emojis Sueltos (para atrapar los demás checks de procesos, etc.)
    "✅": "🍒",
    "❌": "👻",
    "⚠️": "👾",
    "🟢": "🟡",
    "🔴": "👻",
}

def apply_theme(base_dir: str):
    """Aplica el tema único a todos los archivos .py bajo ``base_dir``.
    Ignora el propio script para evitar cambios recursivos.
    """
    for root, dirs, files in os.walk(base_dir):
        # Excluir carpetas de control de versiones y caché
        if ".git" in dirs:
            dirs.remove('.git')
        if "__pycache__" in dirs:
            dirs.remove('__pycache__')
        for file in files:
            if not file.endswith('.py'):
                continue
            if file == os.path.basename(__file__):
                continue
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                new_content = content
                for old, new in replacements.items():
                    new_content = new_content.replace(old, new)
                if new_content != content:
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(new_content)
                    rel_path = os.path.relpath(file_path, base_dir)
                    logger.info(f"🍒 Modificado: {rel_path}")
            except Exception as e:
                logger.error(f"⚠️ Error procesando {file_path}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Aplicar el tema único a los archivos Python del proyecto.")
    parser.add_argument(
        "-d",
        "--dir",
        default=os.path.abspath(os.path.join(os.path.dirname(__file__), "")) ,
        help="Directorio base del proyecto (default: carpeta actual).",
    )
    args = parser.parse_args()
    logger.info("Applying unified theme...")
    apply_theme(args.dir)
    logger.info("Transformation completed successfully!")
