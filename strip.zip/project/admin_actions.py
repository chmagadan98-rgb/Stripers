"""Compatibility helpers for legacy gateway modules.

The maintained user database API lives in ``bot.utils.db``. Older gateway files
still import these names from the project root, so this module keeps that import
surface available while using the local SQLite fallback when MySQL is unavailable.
"""

from bot.utils.db import (
    add_credits,
    deduct_credit,
    get_db_connection,
    get_user_data_from_db as _get_user_data_from_db,
    has_active_premium_plan,
)
from bot.utils.local_users_db import DB_PATH, local_get_user_data
import sqlite3


async def get_user_data_from_db_async(db_config, telegram_id: int):
    return _get_user_data_from_db(db_config or {}, telegram_id)


async def get_user_data_from_db(db_config, telegram_id: int):
    return await get_user_data_from_db_async(db_config, telegram_id)


async def check_antispam(db_config, telegram_id: int, check_type: str = "normal"):
    user_data = get_user_data_from_db(db_config or {}, telegram_id)
    if not user_data:
        return False, 30
    return True, 0


async def update_user_last_check_async(db_config, telegram_id: int):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                "UPDATE users SET last_claim = datetime('now') WHERE telegram_id = ?",
                (telegram_id,),
            )
            conn.commit()
        return True
    except sqlite3.Error:
        return False


async def update_user_last_check(db_config, telegram_id: int):
    return await update_user_last_check_async(db_config, telegram_id)


__all__ = [
    "add_credits",
    "check_antispam",
    "deduct_credit",
    "get_db_connection",
    "get_user_data_from_db",
    "get_user_data_from_db_async",
    "has_active_premium_plan",
    "update_user_last_check",
    "update_user_last_check_async",
]
