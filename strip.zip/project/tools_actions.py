"""Compatibility wrappers for legacy BIN lookup imports."""
import asyncio

from utils.bin_api import get_bin_info


async def get_bin_data_gen(bin_number: str):
    return await get_bin_info(bin_number)


def get_bin_data_sync(bin_number: str):
    try:
        return asyncio.run(get_bin_info(bin_number))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(get_bin_info(bin_number))
        finally:
            loop.close()
