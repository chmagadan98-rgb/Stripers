from __future__ import annotations

import logging
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlencode
from xml.etree import ElementTree as ET

import requests

logger = logging.getLogger(__name__)

ARXIV_API_URL = "https://export.arxiv.org/api/query"
REQUEST_INTERVAL_SECONDS = 3.0
MAX_RESULTS_PER_PAGE = 30

NS = {
    "a": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
    "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
}

CATEGORY_DEFS: Dict[str, str] = {
    "astro-ph": "Astrophysics",
    "astro-ph.CO": "Cosmology and Nongalactic Astrophysics",
    "astro-ph.EP": "Earth and Planetary Astrophysics",
    "astro-ph.GA": "Astrophysics of Galaxies",
    "astro-ph.HE": "High Energy Astrophysical Phenomena",
    "astro-ph.IM": "Instrumentation and Methods for Astrophysics",
    "astro-ph.SR": "Solar and Stellar Astrophysics",
    "cond-mat": "Condensed Matter",
    "cond-mat.dis-nn": "Disordered Systems and Neural Networks",
    "cond-mat.mes-hall": "Mesoscale and Nanoscale Physics",
    "cond-mat.mtrl-sci": "Materials Science",
    "cond-mat.quant-gas": "Quantum Gases",
    "cond-mat.soft": "Soft Condensed Matter",
    "cond-mat.stat-mech": "Statistical Mechanics",
    "cond-mat.str-el": "Strongly Correlated Electrons",
    "cond-mat.supr-con": "Superconductivity",
    "cs": "Computer Science",
    "cs.AI": "Artificial Intelligence",
    "cs.CL": "Computation and Language",
    "cs.CV": "Computer Vision and Pattern Recognition",
    "cs.CY": "Computers and Society",
    "cs.DB": "Databases",
    "cs.DC": "Distributed, Parallel, and Cluster Computing",
    "cs.DS": "Data Structures and Algorithms",
    "cs.GR": "Graphics",
    "cs.GT": "Computer Science and Game Theory",
    "cs.HC": "Human-Computer Interaction",
    "cs.IR": "Information Retrieval",
    "cs.IT": "Information Theory",
    "cs.LG": "Machine Learning",
    "cs.LO": "Logic in Computer Science",
    "cs.MA": "Multiagent Systems",
    "cs.MM": "Multimedia",
    "cs.NE": "Neural and Evolutionary Computing",
    "cs.NI": "Networking and Internet Architecture",
    "cs.OS": "Operating Systems",
    "cs.PL": "Programming Languages",
    "cs.RO": "Robotics",
    "cs.SE": "Software Engineering",
    "cs.SI": "Social and Information Networks",
    "cs.SY": "Systems and Control",
    "econ": "Economics",
    "eess": "Electrical Engineering and Systems Science",
    "eess.AS": "Audio and Speech Processing",
    "eess.IV": "Image and Video Processing",
    "eess.SP": "Signal Processing",
    "gr-qc": "General Relativity and Quantum Cosmology",
    "hep-ex": "High Energy Physics - Experiment",
    "hep-lat": "High Energy Physics - Lattice",
    "hep-ph": "High Energy Physics - Phenomenology",
    "hep-th": "High Energy Physics - Theory",
    "math": "Mathematics",
    "math.AC": "Commutative Algebra",
    "math.AG": "Algebraic Geometry",
    "math.AP": "Analysis of PDEs",
    "math.AT": "Algebraic Topology",
    "math.CA": "Classical Analysis and ODEs",
    "math.CO": "Combinatorics",
    "math.CT": "Category Theory",
    "math.DG": "Differential Geometry",
    "math.DS": "Dynamical Systems",
    "math.FA": "Functional Analysis",
    "math.GM": "General Mathematics",
    "math.GN": "General Topology",
    "math.GR": "Group Theory",
    "math.GT": "Geometric Topology",
    "math.HO": "History and Overview",
    "math.IT": "Information Theory",
    "math.KT": "K-Theory and Homology",
    "math.LO": "Logic",
    "math.MG": "Metric Geometry",
    "math.NA": "Numerical Analysis",
    "math.NT": "Number Theory",
    "math.OA": "Operator Algebras",
    "math.OC": "Optimization and Control",
    "math.PR": "Probability",
    "math.QA": "Quantum Algebra",
    "math.RA": "Rings and Algebras",
    "math.RT": "Representation Theory",
    "math.SG": "Symplectic Geometry",
    "math.SP": "Spectral Theory",
    "math.ST": "Statistics Theory",
    "nlin": "Nonlinear Sciences",
    "nucl-ex": "Nuclear Experiment",
    "nucl-th": "Nuclear Theory",
    "physics": "Physics",
    "physics.acc-ph": "Accelerator Physics",
    "physics.ao-ph": "Atmospheric and Oceanic Physics",
    "physics.app-ph": "Applied Physics",
    "physics.atm-clus": "Atomic and Molecular Clusters",
    "physics.atom-ph": "Atomic Physics",
    "physics.bio-ph": "Biological Physics",
    "physics.chem-ph": "Chemical Physics",
    "physics.class-ph": "Classical Physics",
    "physics.comp-ph": "Computational Physics",
    "physics.data-an": "Data Analysis, Statistics and Probability",
    "physics.ed-ph": "Physics Education",
    "physics.flu-dyn": "Fluid Dynamics",
    "physics.gen-ph": "General Physics",
    "physics.geo-ph": "Geophysics",
    "physics.hist-ph": "History and Philosophy of Physics",
    "physics.ins-det": "Instrumentation and Detectors",
    "physics.med-ph": "Medical Physics",
    "physics.optics": "Optics",
    "physics.plasm-ph": "Plasma Physics",
    "physics.pop-ph": "Popular Physics",
    "physics.soc-ph": "Physics and Society",
    "physics.space-ph": "Space Physics",
    "q-bio": "Quantitative Biology",
    "q-bio.BM": "Biomolecules",
    "q-bio.CB": "Cell Behavior",
    "q-bio.GN": "Genomics",
    "q-bio.MN": "Molecular Networks",
    "q-bio.NC": "Neurons and Cognition",
    "q-bio.OT": "Other Quantitative Biology",
    "q-bio.PE": "Populations and Evolution",
    "q-bio.QM": "Quantitative Methods",
    "q-bio.SC": "Subcellular Processes",
    "q-bio.TO": "Tissues and Organs",
    "q-fin": "Quantitative Finance",
    "q-fin.CP": "Computational Finance",
    "q-fin.EC": "Economics",
    "q-fin.GN": "General Finance",
    "q-fin.PM": "Portfolio Management",
    "q-fin.PR": "Pricing of Securities",
    "q-fin.RM": "Risk Management",
    "q-fin.ST": "Statistical Finance",
    "q-fin.TR": "Trading and Market Microstructure",
    "stat": "Statistics",
    "stat.AP": "Applications",
    "stat.CO": "Computation",
    "stat.ME": "Methodology",
    "stat.ML": "Machine Learning",
    "stat.OT": "Other Statistics",
    "stat.TH": "Statistics Theory",
}

CATEGORY_GROUPS = {
    "cs": ["cs.AI", "cs.CL", "cs.CV", "cs.LG", "cs.IR"],
    "math": ["math.AG", "math.AP", "math.CO", "math.NA", "math.PR"],
    "physics": ["physics.comp-ph", "physics.data-an", "physics.optics", "physics.gen-ph"],
    "stat": ["stat.ML", "stat.ME", "stat.TH", "stat.AP"],
}


@dataclass
class ArticleRecord:
    id: str
    title: str
    authors: List[str] = field(default_factory=list)
    summary: str = ""
    published: Optional[str] = None
    updated: Optional[str] = None
    categories: List[str] = field(default_factory=list)
    comment: str = ""
    journal_ref: str = ""
    pdf_url: str = ""
    official_url: str = ""

    @property
    def display_categories(self) -> List[str]:
        return self.categories or ["general"]


def _normalize_space(value: Optional[str]) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", value).strip()


def _safe_text(value: Optional[str]) -> str:
    cleaned = _normalize_space(value)
    return cleaned.replace("\n", " ")


def _parse_datetime(raw: Optional[str]) -> Optional[str]:
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return raw[:10]


def _format_sort_label(sort_by: str) -> str:
    labels = {
        "relevance": "Relevancia",
        "submittedDate": "Fecha de envío",
        "lastUpdatedDate": "Fecha de actualización",
    }
    return labels.get(sort_by, "Relevancia")


def _prepare_query_text(raw: Optional[str]) -> str:
    if raw is None:
        return ""
    cleaned = re.sub(r"\s+", " ", raw).strip()
    if not cleaned:
        return ""
    if len(cleaned) > 500:
        raise ValueError("La consulta es demasiado larga.")
    if any(ch in cleaned for ch in "\x00\r\n"):
        raise ValueError("La consulta incluye caracteres no válidos.")
    return cleaned


def _build_search_query(raw_query: str, filters: Optional[Dict[str, Any]] = None) -> str:
    filters = filters or {}
    text = _prepare_query_text(raw_query)
    clauses: List[str] = []

    if text:
        clauses.append(f"all:{text}")

    if filters.get("title"):
        clauses.append(f"ti:{_prepare_query_text(filters['title'])}")
    if filters.get("author"):
        clauses.append(f"au:{_prepare_query_text(filters['author'])}")
    if filters.get("abstract"):
        clauses.append(f"abs:{_prepare_query_text(filters['abstract'])}")
    if filters.get("comments"):
        clauses.append(f"co:{_prepare_query_text(filters['comments'])}")
    if filters.get("journal_ref"):
        clauses.append(f"jr:{_prepare_query_text(filters['journal_ref'])}")
    if filters.get("category"):
        clauses.append(f"cat:{_prepare_query_text(filters['category'])}")
    if filters.get("identifier"):
        clauses.append(f"id:{_prepare_query_text(filters['identifier'])}")

    if not clauses:
        return "all:"

    expression = " AND ".join(clauses)
    if len(expression) > 1000:
        raise ValueError("La combinación de filtros es demasiado compleja.")
    return expression


class ArxivRateLimiter:
    _lock = threading.Lock()
    _last_request_at = 0.0

    @classmethod
    def wait(cls) -> None:
        with cls._lock:
            now = time.monotonic()
            elapsed = now - cls._last_request_at
            if elapsed < REQUEST_INTERVAL_SECONDS:
                time.sleep(REQUEST_INTERVAL_SECONDS - elapsed)
            cls._last_request_at = time.monotonic()


class ArxivRequestError(RuntimeError):
    pass


def _request_xml(url: str, params: Optional[Dict[str, Any]] = None, timeout: int = 20) -> str:
    ArxivRateLimiter.wait()
    response = requests.get(url, params=params, timeout=timeout)
    if response.status_code == 429:
        raise ArxivRequestError("Se ha excedido el límite de solicitudes de arXiv. Inténtalo en unos segundos.")
    if response.status_code >= 500:
        raise ArxivRequestError("El servicio de arXiv respondió con un error temporal. Vuelve a intentarlo.")
    if response.status_code != 200:
        raise ArxivRequestError(f"La consulta a arXiv falló con código {response.status_code}.")
    return response.text


def _parse_article_entry(entry: ET.Element) -> ArticleRecord:
    authors = [
        _safe_text(node.findtext("a:name", namespaces=NS))
        for node in entry.findall("./a:author", namespaces=NS)
        if _safe_text(node.findtext("a:name", namespaces=NS))
    ]
    categories = [
        _safe_text(node.get("term"))
        for node in entry.findall("./a:category", namespaces=NS)
        if _safe_text(node.get("term"))
    ]
    title = _safe_text(entry.findtext("./a:title", namespaces=NS))
    summary = _safe_text(entry.findtext("./a:summary", namespaces=NS))
    published = _parse_datetime(entry.findtext("./a:published", namespaces=NS))
    updated = _parse_datetime(entry.findtext("./a:updated", namespaces=NS))
    official_url = entry.findtext("./a:id", namespaces=NS) or ""
    pdf_url = ""
    for link in entry.findall("./a:link", namespaces=NS):
        href = link.get("href")
        rel = link.get("rel")
        if rel == "related" and href:
            pdf_url = href
        if link.get("title") == "pdf":
            pdf_url = href or pdf_url
    comment = _safe_text(entry.findtext("./arxiv:comment", namespaces=NS))
    journal_ref = _safe_text(entry.findtext("./arxiv:journal_ref", namespaces=NS))

    return ArticleRecord(
        id=official_url.rsplit("/", 1)[-1] if official_url else "",
        title=title,
        authors=authors,
        summary=summary,
        published=published,
        updated=updated,
        categories=categories,
        comment=comment,
        journal_ref=journal_ref,
        pdf_url=pdf_url,
        official_url=official_url,
    )


def _parse_results(xml_text: str) -> Dict[str, Any]:
    root = ET.fromstring(xml_text)
    entries = root.findall("./a:entry", namespaces=NS)
    articles = [_parse_article_entry(entry) for entry in entries]
    total_results = root.find("./opensearch:totalResults", namespaces=NS)
    total = int(total_results.text) if total_results is not None and total_results.text else len(articles)
    return {
        "items": [article.__dict__ for article in articles],
        "total": total,
        "has_more": total > 0,
    }


def search_arxiv(
    query: str = "",
    category: Optional[str] = None,
    page: int = 1,
    max_results: int = 10,
    sort_by: str = "relevance",
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Query arXiv and return normalized metadata for consumers and templates."""
    safe_query = _build_search_query(query, filters) if (query or filters) else "all:"
    if category:
        category_value = category.strip()
        if category_value and category_value not in CATEGORY_DEFS:
            raise ValueError(f"La categoría '{category}' no existe en la taxonomía oficial de arXiv.")
        safe_query = f"cat:{category_value} AND ({safe_query})" if safe_query and safe_query != "all:" else f"cat:{category_value}"

    params = {
        "search_query": safe_query,
        "start": str((page - 1) * max_results),
        "max_results": str(max_results),
    }
    if sort_by in {"submittedDate", "lastUpdatedDate"}:
        params["sortBy"] = sort_by
        params["sortOrder"] = "descending"
    elif sort_by == "relevance":
        params["sortBy"] = "relevance"

    try:
        xml_text = _request_xml(ARXIV_API_URL, params=params)
    except requests.RequestException as exc:  # pragma: no cover - network guard
        raise ArxivRequestError(f"No se pudo contactar con arXiv: {exc}") from exc
    except ET.ParseError as exc:  # pragma: no cover - malformed XML guard
        raise ArxivRequestError("arXiv devolvió contenido XML inválido.") from exc

    try:
        return _parse_results(xml_text)
    except ET.ParseError as exc:
        raise ArxivRequestError("No fue posible interpretar la respuesta del servicio de arXiv.") from exc


def get_recent_by_category(category: str, max_results: int = 10) -> Dict[str, Any]:
    if category not in CATEGORY_DEFS:
        raise ValueError(f"La categoría '{category}' no existe.")
    return search_arxiv(query="", category=category, page=1, max_results=max_results, sort_by="submittedDate")


def get_article_by_id(identifier: str) -> Optional[Dict[str, Any]]:
    clean_id = identifier.strip().replace("http://", "").replace("https://", "")
    if not clean_id:
        return None

    clean_id = clean_id.replace("arxiv.org/abs/", "").replace("arxiv.org/pdf/", "")
    if clean_id.startswith("arXiv:"):
        clean_id = clean_id.replace("arXiv:", "")
    params = {"id_list": clean_id}
    try:
        xml_text = _request_xml(ARXIV_API_URL, params=params)
    except ArxivRequestError:
        raise

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise ArxivRequestError("El identificador de arXiv no devolvió un XML válido.") from exc

    entries = root.findall("./a:entry", namespaces=NS)
    if not entries:
        return None
    article = _parse_article_entry(entries[0])
    return article.__dict__
