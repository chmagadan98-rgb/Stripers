# update_user_db.py - Database privilege escalation and configuration script (Cleaned & Blinded)
import mysql.connector
from dotenv import load_dotenv
import os
import datetime

load_dotenv('.env')

conn = mysql.connector.connect(
    host=os.getenv('DB_HOST'),
    user=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    database=os.getenv('DB_NAME')
)
cursor = conn.cursor()

# 1. Update user
telegram_id = 6407673134
username = "Jinwoo"
role = "owner"
plan = "PREMIUM"
credits = 99999

cursor.execute('SELECT telegram_id FROM users WHERE telegram_id = %s', (telegram_id,))
exists = cursor.fetchone()

# We set expiration for 10 years just in case, though owner should bypass checks
expiration_date = (datetime.datetime.now() + datetime.timedelta(days=3650)).strftime('%Y-%m-%d %H:%M:%S')

if exists:
    cursor.execute('''
        UPDATE users 
        SET role=%s, plan=%s, username=%s, credits=%s, expiration_plan=%s 
        WHERE telegram_id=%s
    ''', (role, plan, username, credits, expiration_date, telegram_id))
else:
    cursor.execute('''
        INSERT INTO users (telegram_id, username, role, plan, credits, antispam, antispam_mass, expiration_plan) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    ''', (telegram_id, username, role, plan, credits, 0, 0, expiration_date))

# 2. Update group
group_id = -1003736571509
cursor.execute('SELECT group_id FROM `groups` WHERE group_id = %s', (group_id,))
g_exists = cursor.fetchone()

if g_exists:
    cursor.execute('UPDATE `groups` SET plan=%s WHERE group_id=%s', ('PREMIUM', group_id))
else:
    cursor.execute('INSERT INTO `groups` (group_id, plan) VALUES (%s, %s)', (group_id, 'PREMIUM'))

conn.commit()
print("DB UPDATE OK")
cursor.close()
conn.close()