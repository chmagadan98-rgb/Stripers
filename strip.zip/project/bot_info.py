# bot_info.py - Bot configuration and environment variables (Cleaned & Blinded)
import os
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

# Bot basic configuration
BOT_NAME = os.getenv("BOT_NAME", "NoxusBot")
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", os.getenv("BOT_TOKEN", ""))
BOT_CHANNEL = os.getenv("BOT_CHANNEL", "https://t.me/+qK0pk0XZPORhYzEx")
CHANNEL_USER = os.getenv("CHANNEL_USER", "@NoxusBot")
BOT_URL = os.getenv("BOT_URL", "https://t.me/NoxusBot")
OWNER_ID = int(os.getenv("OWNER_ID", "123456789"))
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "@TuOwnerAqui")
PREMIUM_GROUP_LINK = os.getenv("PREMIUM_GROUP_LINK", "https://t.me/+qK0pk0XZPORhYzEx")

# Database configuration dictionary expected by the application
DB_CONFIG = {
    "host": os.getenv("DB_HOST", ""),
    "user": os.getenv("DB_USER", ""),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "")
}

# Premium / free link placeholders used by the theme script
BOT_FREE = os.getenv("BOT_FREE", "https://t.me/+qK0pk0XZPORhYzEx")
LINK_ONYKAFREE = BOT_FREE

# Optional proxy and Stripe domain configuration for utils modules
PROXIES = []
env_proxies = os.getenv("PROXIES", "")
if env_proxies and not env_proxies.startswith("http://p1"):
    PROXIES = [p.strip() for p in env_proxies.split(",") if p.strip()]

if not PROXIES:
    for filename in ["proxies.txt", "Noxus_API_Backend/proxies.txt", "../proxies.txt"]:
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if ":" in line and not line.startswith("http"):
                                line = f"http://{line}"
                            PROXIES.append(line)
                if PROXIES:
                    break
            except Exception:
                pass

STRIPE_DOMAINS = [d.strip() for d in os.getenv("STRIPE_DOMAINS", "stripe.com, checkout.stripe.com").split(",") if d.strip()]

__all__ = [
    "BOT_NAME",
    "BOT_TOKEN",
    "BOT_CHANNEL",
    "DB_CONFIG",
    "BOT_FREE",
    "LINK_ONYKAFREE",
    "PROXIES",
    "STRIPE_DOMAINS",
    "CHANNEL_USER",
    "BOT_URL",
    "OWNER_ID",
    "OWNER_USERNAME",
    "PREMIUM_GROUP_LINK",
]