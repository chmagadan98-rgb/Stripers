# amazon_mass.py
"""Mass‑check wrapper for Amazon Pay gateway.
Re‑exports core functions from `CHARGE.amazon_gateways` to keep a consistent API for mass checking.
"""
from CHARGE.amazon_gateways import (
    require_individual_premium_access,
    check_antispam,
    validate_cc_format,
    get_user_data_from_db,
    update_user_last_check,
)

__all__ = [
    "require_individual_premium_access",
    "check_antispam",
    "validate_cc_format",
    "get_user_data_from_db",
    "update_user_last_check",
]
