# mass/stripe_mass.py
"""Mass Stripe checker module.
Implements bulk verification of credit‑card data using Stripe's public
API (token creation) and secret key charge endpoint.
The module provides:
- `normalize_cc_format` – convert various formats to ``cc|mm|yy|cvv``
- `check_stripe_card` – perform a $1 test charge and interpret the result.

Environment variables expected:
- ``STRIPE_PUBLIC_KEY`` – publishable key (pk_…)
- ``STRIPE_SECRET_KEY`` – secret key (sk_…)
- ``PROXIES`` – optional proxy configuration from ``bot_info``
"""

import os
import re
import random
import requests
from bot_info import STRIPE_DOMAINS, PROXIES

# ----------------------------------------------------------------------
# Helper: obtain Stripe keys from environment (fallback to empty strings)
# ----------------------------------------------------------------------
PK_KEY = os.getenv("STRIPE_PUBLIC_KEY", "")  # Publishable key
SK_KEY = os.getenv("STRIPE_SECRET_KEY", "")   # Secret key

# ----------------------------------------------------------------------
# Normalise credit‑card string to ``cc|mm|yy|cvv``
# ----------------------------------------------------------------------
from typing import Union

def normalize_cc_format(cc_data: str) -> Union[str, None]:
    """Normalize different card representations to ``cc|mm|yy|cvv``.
    Returns ``None`` if the input cannot be parsed.
    """
    if not cc_data:
        return None
    # Replace any separator (space, slash, colon, etc.) with '|'
    cc_data = re.sub(r"[\s/:]+", "|", cc_data.strip())
    parts = cc_data.split("|")
    if len(parts) < 4:
        return None
    cc, month, year, cvv = parts[0], parts[1], parts[2], parts[3]
    # Basic validation
    if not re.fullmatch(r"\d{13,19}", cc):
        return None
    if not re.fullmatch(r"\d{1,2}", month) or not (1 <= int(month) <= 12):
        return None
    # Normalize year to two digits
    if len(year) == 4:
        year = year[2:]
    elif len(year) != 2:
        return None
    if not re.fullmatch(r"\d{3,4}", cvv):
        return None
    return f"{cc}|{month}|{year}|{cvv}"

# ----------------------------------------------------------------------
# Core checker – creates a token then attempts a $1 USD charge.
# ----------------------------------------------------------------------
def _create_stripe_session() -> requests.Session:
    """Create a ``requests`` session with optional proxy configuration."""
    session = requests.Session()
    # Apply proxies from ``PROXIES`` (could be list, dict, or string)
    if isinstance(PROXIES, list) and PROXIES:
        proxy = random.choice(PROXIES)
        session.proxies.update({"http": proxy, "https": proxy})
    elif isinstance(PROXIES, dict):
        session.proxies.update(PROXIES)
    elif isinstance(PROXIES, str) and PROXIES:
        session.proxies.update({"http": PROXIES, "https": PROXIES})
    return session

def check_stripe_card(cc_formatted: str) -> tuple:
    """Perform a single Stripe check.
    ``cc_formatted`` must be ``cc|mm|yy|cvv``.
    Returns ``(status, message)`` where ``status`` is one of:
    - ``"Approved! 🍒"``
    - ``"Declined! 👻"``
    - ``"Error"``
    The ``message`` contains additional info from Stripe.
    """
    try:
        parts = cc_formatted.split("|")
        if len(parts) != 4:
            return "Error", "Invalid format"
        cc, month, year, cvv = parts
        session = _create_stripe_session()
        # -------------------------------------------------------------
        # 1️⃣ Create a token using the publishable key
        # -------------------------------------------------------------
        if not PK_KEY:
            return "Error", "Missing STRIPE_PUBLIC_KEY"
        headers_token = {
            "Authorization": f"Bearer {PK_KEY}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data_token = f"card[number]={cc}&card[exp_month]={month}&card[exp_year]={year}&card[cvc]={cvv}"
        r_token = session.post(
            "https://api.stripe.com/v1/tokens",
            headers=headers_token,
            data=data_token,
            timeout=15,
        )
        token_data = r_token.json()
        if "error" in token_data:
            msg = token_data["error"].get("message", "Token error")
            return "Declined! 👻", msg
        token_id = token_data.get("id")
        if not token_id:
            return "Error", "Token ID missing"
        # -------------------------------------------------------------
        # 2️⃣ Charge $1 using the secret key
        # -------------------------------------------------------------
        if not SK_KEY:
            return "Error", "Missing STRIPE_SECRET_KEY"
        headers_charge = {
            "Authorization": f"Bearer {SK_KEY}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data_charge = f"amount=100&currency=usd&source={token_id}"
        r_charge = session.post(
            "https://api.stripe.com/v1/charges",
            headers=headers_charge,
            data=data_charge,
            timeout=15,
        )
        charge_data = r_charge.json()
        # -------------------------------------------------------------
        # Interpret Stripe response
        # -------------------------------------------------------------
        if "error" in charge_data:
            err = charge_data["error"]
            msg = err.get("message", "Charge error")
            code = err.get("decline_code", "")
            # Test‑mode cards return a specific error code – treat as declined
            if err.get("code") == "testmode_charges_only":
                return "Declined! 👻", "Test mode only accepts test cards"
            # Some CVC errors are considered *approved* by the original bot logic
            if "security code is incorrect" in msg.lower() or code == "incorrect_cvc":
                return "Approved! 🍒", f"{msg} {code}".strip()
            return "Declined! 👻", f"{msg} {code}".strip()
        if charge_data.get("status") == "succeeded":
            return "Approved! 🍒", "succeeded"
        # Fallback – treat any non‑success as declined
        return "Declined! 👻", charge_data.get("status", "Unknown")
    except requests.exceptions.Timeout:
        return "Error", "Timeout"
    except requests.exceptions.ConnectionError:
        return "Error", "Connection error"
    except Exception as e:
        return "Error", f"Unexpected: {str(e)}"

__all__ = ["normalize_cc_format", "check_stripe_card"]
