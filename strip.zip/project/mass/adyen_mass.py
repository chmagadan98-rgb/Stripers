# adyen_mass.py
"""Mass‑check wrapper for Adyen gateway.
Re‑exports core functions from `CHARGE.adyen_gateways` to keep a consistent API for mass checking.
"""
from CHARGE.adyen_gateways import (
    require_individual_premium_access,
    check_antispam,
    validate_cc_format,
    get_user_data_from_db,
    update_user_last_check,
)

__all__ = [
    "require_individual_premium_access",
    "check_antispam",
    "validate_cc_format",
    "get_user_data_from_db",
    "update_user_last_check",
]
