MASS_CONTROLLERS_CONFIG = []


def create_generic_checker_function(*args, **kwargs):
    return None


def get_all_mass_routers():
    return []
