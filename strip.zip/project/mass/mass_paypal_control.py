# mass_paypal_control.py - Mass PayPal Charge command logic
import random
from utils.mass_checker_framework import create_mass_checker_handler
from tools_actions import get_bin_data_sync # Usamos una versión síncrona para el executor

def check_paypal_card(cc_formatted: str):
    """
    Función de verificación síncrona para PayPal (simulada).
    Esta es la función que se ejecutará en un hilo separado.
    """
    bin_data = get_bin_data_sync(cc_formatted[:6])
    bin_level = bin_data.get('Category', 'UNKNOWN').upper() if bin_data else 'UNKNOWN'

    if bin_level in ['PREPAID', 'GIFT']:
        return "Declined", "Payment Method Not Accepted by Gateway", None

    if cc_formatted.startswith("4") or cc_formatted.startswith("5"):
        roll = random.random()
        if roll < 0.15:
            return "Approved", "Transaction Successful - Order Captured", None
        elif roll < 0.50:
            return "CCN", "Insufficient Funds / Gateway Rejected", None
        elif roll < 0.70:
            return "CCN", "Risk Error: High Risk Decline", None
        else:
            return "Declined", "Card Issuer Declined", None
    else:
        roll = random.random()
        if roll < 0.05:
            return "Approved", "Transaction Successful", None
        else:
            return "Declined", "Card Issuer Declined", None

# Define los roles que tienen acceso a este comando masivo
REQUIRED_ACCESS_PLAN = ['OWNER', 'CO OWNER', 'DEV', 'SELLER', 'VIP']

handle_mpp_command = create_mass_checker_handler(
    gateway_name="PayPal",
    checker_function=check_paypal_card,
    required_plan=REQUIRED_ACCESS_PLAN
)

__all__ = ['handle_mpp_command']