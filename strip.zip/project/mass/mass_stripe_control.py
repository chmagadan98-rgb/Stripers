# mass_stripe_control.py - Mass Stripe Auth command logic
from utils.stripe_check_sync import check_stripe_card
from utils.mass_checker_framework import create_mass_checker_handler

# Define los roles que tienen acceso a este comando masivo
REQUIRED_ACCESS_PLAN = ['OWNER', 'CO OWNER', 'DEV', 'SELLER', 'VIP']

# Crea el manejador de comando masivo para Stripe usando la fábrica.
handle_mst_command = create_mass_checker_handler(
    gateway_name="Stripe",
    checker_function=check_stripe_card,
    required_plan=REQUIRED_ACCESS_PLAN
)

__all__ = ['handle_mst_command']