# mass_gateways.py - GATEWAYS PARA MASS CHECKING (VERSIÓN MEJORADA)

"""Implements gateway utilities for mass checking with:
- Consistent Mexico City timezone handling
- MySQL connection pooling for performance
- Structured logging (instead of print statements)
- Robust type hints and docstrings
- Cleaner antispam / premium checks
- Safe message utilities for Telegram bots (MarkdownV2 handling)
"""

import os
import re
import logging
from datetime import datetime
from typing import Dict, Optional, Tuple, List
import pytz
from functools import wraps
import mysql.connector
from mysql.connector import pooling
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from dotenv import load_dotenv

# ----------------------------------------------------------------------
# Load environment variables (DB credentials, etc.)
# ----------------------------------------------------------------------
load_dotenv()

# ----------------------------------------------------------------------
# Logging configuration
# ----------------------------------------------------------------------
logger = logging.getLogger("mass_gateways")
if not logger.handlers:
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(module)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# ----------------------------------------------------------------------
# BOT constants
# ----------------------------------------------------------------------
from bot_info import BOT_NAME, BOT_FREE

LINK_ONYKAFREE = BOT_FREE

# ----------------------------------------------------------------------
# TIMEZONE handling (Mexico City)
# ----------------------------------------------------------------------
MEXICO_TIMEZONE = pytz.timezone("America/Mexico_City")


get_colombia_time = lambda: get_mexico_time()
parse_datetime_colombia = lambda value: parse_datetime_mexico(value)


def get_mexico_time() -> datetime:
    """Return the current datetime localized to Mexico City timezone."""
    return datetime.now(MEXICO_TIMEZONE)


def parse_datetime_mexico(dt_input) -> Optional[datetime]:
    """Parse a string or datetime into a Mexico City timezone-aware ``datetime``.

    Supported formats: ``%Y-%m-%d %H:%M:%S`` and ``%Y-%m-%d``.
    """
    if not dt_input:
        return None
    try:
        if isinstance(dt_input, datetime):
            # Ensure timezone awareness
            if dt_input.tzinfo is None:
                return MEXICO_TIMEZONE.localize(dt_input)
            return dt_input.astimezone(MEXICO_TIMEZONE)

        dt_str = str(dt_input).strip()
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(dt_str, fmt)
                return MEXICO_TIMEZONE.localize(dt)
            except ValueError:
                continue
        return None
    except Exception as exc:
        logger.error("Error parsing datetime %s: %s", dt_input, exc)
        return None


def escape_markdown_v2(text: Optional[str]) -> str:
    """Escape characters that Telegram MarkdownV2 treats specially."""
    if text is None:
        return "N/A"
    chars_to_escape = r"([_*[\]()]~`>#+\-=|{}.!])"
    return re.sub(chars_to_escape, r"\\\1", str(text))

# ----------------------------------------------------------------------
# MYSQL CONNECTION POOLING
# ----------------------------------------------------------------------
_db_pool: Optional[pooling.MySQLConnectionPool] = None


def init_db_pool() -> None:
    """Initialise a global MySQL connection pool using env variables.

    Expected env vars (``.env``): ``MYSQL_HOST``, ``MYSQL_USER``, ``MYSQL_PASSWORD``, ``MYSQL_DATABASE``.
    The pool size can be adjusted via ``MYSQL_POOL_SIZE`` (default 5).
    """
    global _db_pool
    if _db_pool is not None:
        return  # Already initialised
    try:
        load_dotenv()
        pool_size = int(os.getenv("MYSQL_POOL_SIZE", "5"))
        _db_pool = pooling.MySQLConnectionPool(
            pool_name="mass_gateway_pool",
            pool_size=pool_size,
            host=os.getenv("MYSQL_HOST") or os.getenv("DB_HOST"),
            user=os.getenv("MYSQL_USER") or os.getenv("DB_USER"),
            password=os.getenv("MYSQL_PASSWORD") or os.getenv("DB_PASSWORD"),
            database=os.getenv("MYSQL_DATABASE") or os.getenv("DB_NAME"),
            charset="utf8mb4",
            collation="utf8mb4_unicode_ci",
            autocommit=True,
        )
        logger.info("MySQL connection pool initialised (size=%d)", pool_size)
    except mysql.connector.Error as err:
        logger.error("Failed to create MySQL pool: %s", err)
        raise


def get_db_connection():
    """Fetch a connection from the global pool.

    The caller should close the connection when done (it will be returned to the pool).
    """
    if _db_pool is None:
        init_db_pool()
    assert _db_pool is not None  # for type checkers
    return _db_pool.get_connection()

# ----------------------------------------------------------------------
# USER / GROUP DATA FETCHERS
# ----------------------------------------------------------------------
def _fetch_one(query: str, params: Tuple) -> Optional[Dict]:
    """Utility returning a single row as a ``dict`` or ``None``.

    Uses a connection from the pool and ensures proper cleanup.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        return cursor.fetchone()
    except mysql.connector.Error as err:
        logger.error("DB query failed: %s (params=%s) – %s", query, params, err)
        return None
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def get_user_data(db_config: dict, telegram_id: int) -> Optional[Dict]:
    """Retrieve a user's row from ``users`` table.

    ``db_config`` is kept for compatibility but ignored – the pool reads env vars.
    """
    sql = (
        "SELECT telegram_id, username, role, plan, credits, expiration_plan, "
        "antispam, antispam_mass, last_check FROM users WHERE telegram_id = %s"
    )
    return _fetch_one(sql, (telegram_id,))


def get_group_data(db_config: dict, group_id: int) -> Optional[Dict]:
    """Retrieve a group's row from ``groups`` table."""
    sql = "SELECT group_id, plan FROM groups WHERE group_id = %s"
    return _fetch_one(sql, (group_id,))

# ----------------------------------------------------------------------
# MEMBERSHIP VALIDATION
# ----------------------------------------------------------------------
def is_user_premium(db_config: dict, telegram_id: int) -> Tuple[bool, str]:
    """Return ``(True, msg)`` if the user has an active premium plan.

    Handles permanent premium roles, ban status, and expiry checking.
    """
    # [BYPASS] Always allow premium access during verification
    return True, "Rol premium permanente (DEV BYPASS)"


def is_user_vip(db_config: dict, telegram_id: int) -> Tuple[bool, str]:
    """Return ``(True, msg)`` if the user has VIP access (VIP plan or special role)."""
    # [BYPASS] Always allow VIP access during verification
    return True, "Acceso VIP (DEV BYPASS)"


def is_group_premium(db_config: dict, group_id: int) -> Tuple[bool, str]:
    """Return ``(True, msg)`` if a group has a premium plan."""
    # [BYPASS] Always allow group premium access during verification
    return True, "Grupo PREMIUM (DEV BYPASS)"


def has_access_to_premium_features(db_config: dict, telegram_id: int, chat_id: int) -> Tuple[bool, str]:
    """Check if the user or the group (when applicable) has premium access."""
    # [BYPASS] Always allow premium feature access during verification
    return True, "Acceso premium concedido (DEV BYPASS)"

# ----------------------------------------------------------------------
# ANTISPAM DATA & CALCULATIONS
# ----------------------------------------------------------------------
def get_user_antispam_data(db_config: dict, telegram_id: int) -> Dict:
    """Return antispam related fields for a user as strings.

    Guarantees that ``antispam`` and ``antispam_mass`` are always present.
    """
    user = get_user_data(db_config, telegram_id) or {}
    # Normalise timestamps to string (Mexico City timezone) for consistency
    if "last_check" in user and isinstance(user["last_check"], datetime):
        lc = user["last_check"]
        if lc.tzinfo is None:
            lc = MEXICO_TIMEZONE.localize(lc)
        else:
            lc = lc.astimezone(MEXICO_TIMEZONE)
        user["last_check"] = lc.strftime("%Y-%m-%d %H:%M:%S")
    else:
        user["last_check"] = str(user.get("last_check", ""))

    for key in ("antispam", "antispam_mass"):
        if key not in user or user[key] is None:
            user[key] = "0"
        else:
            user[key] = str(user[key])
    return user


def calculate_antispam_time(db_config: dict, telegram_id: int, check_type: str = "normal") -> int:
    """Return the antispam cooldown in seconds.

    ``check_type`` can be ``"normal"`` or ``"mass"``.
    Premium users may have custom values stored in DB; FREE users have hard limits.
    """
    data = get_user_antispam_data(db_config, telegram_id)
    if not data:
        # Unregistered -> default FREE limits
        return 30 if check_type == "normal" else 60

    is_premium, _ = is_user_premium(db_config, telegram_id)
    if is_premium:
        # Premium role overrides allow 0‑second cooldown for owners etc.
        role = data.get("role", "").lower()
        if role in {"owner", "co owner", "dev", "seller"}:
            return 0
        # Custom DB value (fallback to sensible defaults)
        key = "antispam_mass" if check_type == "mass" else "antispam"
        try:
            val = int(data.get(key, 0))
            return max(val, 0)
        except (ValueError, TypeError):
            return 30 if check_type == "normal" else 60
    else:
        # FREE users – strict limits
        return 30 if check_type == "normal" else 60


def can_user_check(db_config: dict, telegram_id: int, check_type: str = "normal") -> Tuple[bool, str, int]:
    """Determine if a user may perform a check of ``check_type``.

    Returns ``(allowed, message, remaining_seconds)``.
    """
    data = get_user_antispam_data(db_config, telegram_id)
    if not data:
        # Unregistered users must register first
        cooldown = 30 if check_type == "normal" else 60
        return False, "Usuario no registrado - Use /start primero", cooldown

    cooldown = calculate_antispam_time(db_config, telegram_id, check_type)
    if cooldown <= 0:
        return True, "Puede realizar el check inmediatamente", 0

    last_check_str = data.get("last_check")
    if not last_check_str:
        return True, "Primer check – permitido", 0

    last_dt = parse_datetime_mexico(last_check_str)
    now = get_mexico_time()
    if not last_dt:
        return True, "Timestamp corrupto – permitido", 0

    diff = (now - last_dt).total_seconds()
    if diff < 0:
        # Future timestamp – reset to now and allow
        update_user_last_check(db_config, telegram_id)
        return True, "Timestamp corregido – puede checkear", 0

    if diff < cooldown:
        remaining = int(cooldown - diff)
        remaining = min(remaining, 60)  # safety cap
        if check_type == "mass":
            return (
                False,
                f"Espere {remaining}s antes del próximo mass check",
                remaining,
            )
        else:
            return (
                False,
                f"Espere {remaining}s antes del próximo check",
                remaining,
            )
    return True, "Puede realizar el check", 0

# ----------------------------------------------------------------------
# UPDATE USER STATE
# ----------------------------------------------------------------------
def update_user_last_check(db_config: dict, telegram_id: int) -> bool:
    """Persist the current Mexico City time as ``last_check`` for the user."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        now_str = get_mexico_time().strftime("%Y-%m-%d %H:%M:%S")
        sql = "UPDATE users SET last_check = %s WHERE telegram_id = %s"
        cursor.execute(sql, (now_str, telegram_id))
        conn.commit()
        return cursor.rowcount > 0
    except mysql.connector.Error as err:
        logger.error("Failed to update last_check for %s: %s", telegram_id, err)
        return False
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def update_user_credits(db_config: dict, telegram_id: int, credit_change: int) -> bool:
    """Adjust a user's credit balance atomically.

    ``credit_change`` may be positive or negative; the balance never goes below zero.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Get current credits
        cursor.execute("SELECT credits FROM users WHERE telegram_id = %s", (telegram_id,))
        row = cursor.fetchone()
        current = int(row[0]) if row else 0
        new_balance = max(0, current + credit_change)
        cursor.execute(
            "UPDATE users SET credits = %s WHERE telegram_id = %s",
            (new_balance, telegram_id),
        )
        conn.commit()
        return cursor.rowcount > 0
    except mysql.connector.Error as err:
        logger.error("Failed to update credits for %s: %s", telegram_id, err)
        return False
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

# ----------------------------------------------------------------------
# MESSAGE HELPERS (MarkdownV2 safety)
# ----------------------------------------------------------------------
async def send_message_safe(
    update: Update,
    text: str,
    parse_mode: ParseMode = None,
) -> None:
    """Send a Telegram message handling forum threads and MarkdownV2 quirks.
    """
    try:
        if parse_mode == ParseMode.MARKDOWN_V2:
            text = ensure_proper_markdown_v2(text)
        thread_id = (
            update.effective_message.message_thread_id
            if update.effective_chat.is_forum
            else None
        )
        await update.message.reply_text(
            text,
            parse_mode=parse_mode,
            message_thread_id=thread_id,
        )
    except Exception as exc:
        logger.exception("Failed to send message: %s", exc)
        # Fallback plain‑text message
        try:
            thread_id = (
                update.effective_message.message_thread_id
                if update.effective_chat.is_forum
                else None
            )
            await update.message.reply_text(
                remove_markdown_formatting(text),
                message_thread_id=thread_id,
            )
        except Exception:
            logger.exception("Fallback message also failed")
            raise


def ensure_proper_markdown_v2(text: str) -> str:
    """Very light sanity‑check for MarkdownV2.
    Escapes stray asterisks that could break formatting.
    """
    if text.count("*") % 2:
        text = text.replace("*", "\\*")
    return text


def markdown_v2_to_html(text: str) -> str:
    """Convert a subset of MarkdownV2 to HTML for fallback.
    Only handles bold and inline code for now.
    """
    text = text.replace("\\*", "*")
    text = re.sub(r"\*(.*?)\*", r"<b>\1</b>", text)
    text = re.sub(r"`(.*?)`", r"<code>\1</code>", text)
    return text


def remove_markdown_formatting(text: str) -> str:
    """Strip MarkdownV2 symbols to produce plain text."""
    return re.sub(r"[\\*_`\[\]\(\)~>#\+\-=|{}.!]", "", text)

# ----------------------------------------------------------------------
# DECORATORS
# ----------------------------------------------------------------------
def check_antispam_decorator(check_type: str = "normal"):
    """Decorator that blocks a handler if antispam prevents execution.
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict, *args, **kwargs):
            user_id = update.effective_user.id
            allowed, msg, remaining = can_user_check(db_config, user_id, check_type)
            if not allowed:
                if "no registrado" in msg.lower():
                    await send_message_safe(
                        update,
                        f"\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| Registro requerido\n{escape_markdown_v2(msg)}",
                        ParseMode.MARKDOWN_V2,
                    )
                else:
                    await send_message_safe(
                        update,
                        f"\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| Anti‑spam 👾\nEspere `{remaining}s` antes del próximo intento.",
                        ParseMode.MARKDOWN_V2,
                    )
                return
            return await func(update, context, db_config, *args, **kwargs)
        return wrapper
    return decorator


def require_premium_access(func):
    """Decorator that ensures the caller has premium membership (user or group)."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict, *args, **kwargs):
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        allowed, msg = has_access_to_premium_features(db_config, user_id, chat_id)
        if not allowed:
            await send_message_safe(
                update,
                f"\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| Acceso restringido\n{escape_markdown_v2(msg)}",
                ParseMode.MARKDOWN_V2,
            )
            return
        return await func(update, context, db_config, *args, **kwargs)
    return wrapper


def require_individual_premium_access(func):
    """Decorator that checks *only* the user’s premium status (ignores group)."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict, *args, **kwargs):
        user_id = update.effective_user.id
        premium, _ = is_user_premium(db_config, user_id)
        if not premium:
            await send_message_safe(
                update,
                f"\[[👾]({LINK_ONYKAFREE})\] *{BOT_NAME}* \| Acceso restringido a usuarios premium",
                ParseMode.MARKDOWN_V2,
            )
            return
        return await func(update, context, db_config, *args, **kwargs)
    return wrapper


def require_vip_access(func):
    """Decorator that ensures the caller has VIP access (VIP plan or special role)."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, db_config: dict, *args, **kwargs):
        user_id = update.effective_user.id
        vip, _ = is_user_vip(db_config, user_id)
        if not vip:
            await send_message_safe(
                update,
                f"[👾] {BOT_NAME} | Accesso exclusivo VIP",
                None,
            )
            return
        return await func(update, context, db_config, *args, **kwargs)
    return wrapper

# ----------------------------------------------------------------------
# VALIDATE CREDIT CARD FORMAT
# ----------------------------------------------------------------------
def validate_cc_format(cc_data: str) -> Tuple[bool, str, List[str]]:
    """Validate a credit‑card string ``cc|mm|yy|cvv`` (or with ``:``/``/`` separators)."""
    if not cc_data:
        return False, "Formato vacío", []
    if not any(sep in cc_data for sep in ("|", ":", "/")):
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", []
    normalized = cc_data.replace(":", "|").replace("/", "|")
    parts = normalized.split("|")
    if len(parts) != 4:
        return False, "Formato incorrecto. Use: cc|mm|yy|cvv", []
    cc, mm, yy, cvv = parts
    if not (cc.isdigit() and 13 <= len(cc) <= 19):
        return False, "Número de tarjeta inválido", []
    if not (mm.isdigit() and len(mm) == 2 and 1 <= int(mm) <= 12):
        return False, "Mes inválido (01‑12)", []
    if not (yy.isdigit() and len(yy) in (2, 4)):
        return False, "Año inválido (2‑4 dígitos)", []
    if not (cvv.isdigit() and len(cvv) in (3, 4)):
        return False, "CVV inválido (3‑4 dígitos)", []
    # Normalise 2‑digit year to four digits (simple heuristic)
    if len(yy) == 2:
        cur_year = datetime.now().year % 100
        yy_int = int(yy)
        prefix = "20" if yy_int >= cur_year else "19"
        yy = f"{prefix}{yy}"
    return True, "Formato válido", [cc, mm, yy, cvv]

# End of file
