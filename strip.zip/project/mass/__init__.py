"""Compatibility package exposing the legacy uppercase `MASS` import path.

The project still imports modules such as `from MASS.mass_checker_factory import ...`.
The actual implementation lives under the lowercase package `mass`, so we re-export it
here to keep runtime imports stable across environments.
"""

from mass import *  # noqa: F401,F403

try:
	from mass import __all__ as _mass_all
	__all__ = list(_mass_all) if isinstance(_mass_all, list) else []
except Exception:  # pragma: no cover - defensive fallback
	__all__ = []
