function buildSearchUrl(category, query, sort, page) {
  const params = new URLSearchParams();
  if (query) params.set('q', query);
  if (category) params.set('category', category);
  if (sort) params.set('sort', sort);
  if (page) params.set('page', String(page));
  return `${window.location.origin}${window.location.pathname}?${params.toString()}`;
}

function copySearchUrl() {
  const url = new URL(window.location.href);
  const text = url.toString();
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.querySelector('.secondary-button');
    if (btn) {
      const previous = btn.textContent;
      btn.textContent = 'Enlace copiado';
      setTimeout(() => { btn.textContent = previous; }, 1200);
    }
  }).catch(() => {
    window.prompt('Copia la URL de la búsqueda:', text);
  });
}

function toggleFavorite(id) {
  const key = 'paperatlas:favorites';
  const current = JSON.parse(localStorage.getItem(key) || '[]');
  const next = current.includes(id)
    ? current.filter(item => item !== id)
    : [...current, id];

  localStorage.setItem(key, JSON.stringify(next));
  const button = document.querySelector(`[data-id="${CSS.escape(id)}"]`);
  if (button) {
    button.classList.toggle('is-favorite', next.includes(id));
  }
}

function refreshFavorites() {
  const key = 'paperatlas:favorites';
  const favorites = new Set(JSON.parse(localStorage.getItem(key) || '[]'));
  document.querySelectorAll('.favorite-toggle').forEach((button) => {
    const id = button.getAttribute('data-id');
    const isFavorite = favorites.has(id);
    button.classList.toggle('is-favorite', isFavorite);
    button.title = isFavorite ? 'Quitar de favoritos' : 'Guardar en favoritos';
  });
}

function bindFavoriteButtons() {
  document.querySelectorAll('.favorite-toggle').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');
      if (id) toggleFavorite(id);
    });
  });
  refreshFavorites();
}

window.addEventListener('DOMContentLoaded', () => {
  bindFavoriteButtons();
});
